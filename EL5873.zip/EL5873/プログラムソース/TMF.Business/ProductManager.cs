﻿#region File Header
// ---------------------------------------------------------------------------------------
// Copyright (C) Hitachi High-Tech Corporation, 2019-2021. All rights reserved.
// File Name    : ProductManager.cs
// Description  : Manager class for Product management 
// Date         |   Author              |       Description
// ---------------------------------------------------------------------------------------
// 2019/01/30   |   Sujith A            |       Created as part of product management PO VJP12
// 2019/02/21   |   Sharon Thankachan   |       VJP192_Modification for Deleted Product items
// 2019/05/21   |   Sujith A		    |       WJ3736_Bug fix
// 2020/05/15   |   Vinoth N            |       C51165_Modification for product creation wizard
// 2020/10/23   |   Vinoth N            |       CRC207_Modification for mapping TAS Script
// 2021/02/17   |   Vinoth N            |       DMG213_Modification for email enhancement
// 2021/06/11   |   Vinoth N            |       EL5873_Modification for build and path settings
// --------------------------------------------------------------------------------------- 
#endregion

#region Using
using Meyn.TestLink;
using Redmine.Net.Api;
using Redmine.Net.Api.Types;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using TMF.Common;
using TMF.DAL;
using TMF.Logger;
using TMF.ViewModels;
using File = System.IO.File;
#endregion

#region Namespace
namespace TMF.Business
{
    /// <summary>
    /// Class used to handle product management functionalities
    /// </summary>
    public class ProductManager : IProductManager
    {
        #region Public Methods

        /// <summary>
        /// Method to retrieve all products 
        /// </summary>
        /// <param name="token">Logged in user token</param>
        /// <param name="isDeletePermission">is user has delete permission</param>
        /// <returns>Returns products</returns>
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        public List<ProductModel> GetAllProducts(string token, bool isDeletePermission = false)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            if (!watch.IsRunning)
                watch.Start(); 
            List<ProductModel> products = new List<ProductModel>();
            string apiKey = "";
            var proxy = ConnectTestLink(token, out apiKey);
            RMRepository repo = new RMRepository();
            string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
            var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
            var parameters = new NameValueCollection { { RedmineKeys.PROJECT, RedmineKeys.ALL } };
            var pjts = repo.GetAllProjects();
            var pjtIds = repo.GetProjectsofUser(token);
            RMUserRepository userRepo = new RMUserRepository();
            string login = userRepo.GetLogin(token);
            foreach (var pjt in pjts)
            {
                /*VJP192_Modification for Deleted Product items START*/
                if (pjt.Status != (int)ProjectStatus.Active && !isDeletePermission)
                {
                    continue;
                }
                if (pjt.Parent == 0)
                {
                    ProductModel pdt = new ProductModel
                    {
                        Id = pjt.Id,
                        ProductName = pjt.Name,
                        Description = pjt.Description,
                        IsMember = pjtIds.Contains(pjt.Id),
                        IsActive = pjt.Status == (int)ProjectStatus.Active ? true : false
                    };
                    products.Add(pdt);
                    pdt.MembersCount = repo.GetMembers(pjt.Id).Count;
                    continue;
                }
                foreach (var pdt in products)
                {
                    if (DoGetVersion(pdt, pjt, pjtIds))
                    {
                        break;
                    }
                    /*VJP192_Modification for Deleted Product items END*/
                }
            }
            products.RemoveAll(m => !m.IsMember && !m.IsSubMember);
            products.ForEach(m => m.Versions.RemoveAll(n => !m.IsMember && !n.IsSubMember && !n.IsMember));
            products.ForEach(m => m.VersionCount = m.Versions.Count);
            watch.Stop();
            System.Diagnostics.Debug.WriteLine($"Total Execution Time: {watch.ElapsedMilliseconds} ms");
            return products;
        }

        /// <summary>
        /// Method to retrieve details of a product
        /// </summary>
        /// <param name="productId">Unique id of the product</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isDeletePermission">is user has delete permission</param>
        /// <returns>Returns product details</returns>
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        public ProductModel GetProductDetails(int productId, string token, bool isDeletePermission = false)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            if (!watch.IsRunning) 
                watch.Start(); 
            ProductModel pdt = new ProductModel();
            string apiKey = "";
            RMRepository repo = new RMRepository();
            var proxy = ConnectTestLink(token, out apiKey);
            string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
            var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
            NameValueCollection parameters = new NameValueCollection { { RedmineKeys.PROJECTS, RedmineKeys.ALL } };
            Project pjt1 = manager.GetObject<Project>(productId.ToString(),
                new NameValueCollection { { RedmineKeys.QUERY, RedmineKeys.ALL } });
            List<CustomProjectModel> pjts = repo.GetAllProjects();
            var pjtIds = repo.GetProjectsofUser(token);
            foreach (var pjt in pjts)
            {
                if (pjt.Status != (int)ProjectStatus.Active && !isDeletePermission)
                {
                    continue;
                }
                if (pjt.Id == productId)
                {
                    pdt.Id = pjt.Id;
                    pdt.ProductName = pjt.Name;
                    pdt.Description = pjt.Description;
                    pdt.IsMember = pjtIds.Contains(pjt.Id);
                    pdt.IsActive = pjt.Status == (int)ProjectStatus.Active ? true : false;
                    var members = ConvertToModel(repo.GetMembers(pjt.Id));
                    members = members.Where(p => p.Name != repo.GetDefaultUser().Name).ToList();
                    pdt.Members = members;
                    pdt.MembersCount = pdt.Members.Count;
                    continue;
                }
                else if (pjt.Parent == 0)
                    continue;
                else
                {
                    if (DoGetVersion(pdt, pjt, pjtIds))
                    {
                        continue;
                    }
                }
            }
            pdt.Versions.RemoveAll(n => !pdt.IsMember && !n.IsSubMember && !n.IsMember);
            if (!pdt.IsActive)
            {
                pdt.Versions.ForEach(x => x.IsActive = false);
            }
            if (pdt.Versions != null && pdt.Versions.Count > 1)
                pdt.Versions = pdt.Versions.OrderByDescending(x => x.IsActive).ToList();
            watch.Stop();
            System.Diagnostics.Debug.WriteLine($"Total Execution Time: {watch.ElapsedMilliseconds} ms");
            return pdt;
        }

        /// <summary>
        /// Method to add product
        /// </summary>
        /// <param name="product">Product details</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isSingle">flag</param>
        /// <returns>Returns add product status</returns>
        /// 2019/01/30, Sujith A, VJP12_Initial version
        /// 2021/02/17, Vinoth N, DMG213_Modification for send mail 
        public GeneralResultModel AddProduct(ProductModel product, string token, bool isSingle = false)
        {
            GeneralResultModel result = new GeneralResultModel();
            result.message = Resources.Resource.CreateProductFaild;
            string apiKey = string.Empty;
            try
            {
                var tLink = ConnectTestLink(token, out apiKey);
                product.Description = string.IsNullOrEmpty(product.Description) ? "" : product.Description;
                int testProjectId = 0;
                try
                {
                    product.ProductName = product.ProductName.Trim();
                    TestProject tProject = tLink.GetProject(product.ProductName);
                    testProjectId = tProject.id;
                    NameValueCollection parameters = new NameValueCollection { { RedmineKeys.PROJECTS, RedmineKeys.ALL } };
                    string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                    var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                    List<Project> pjts = manager.GetObjects<Project>(parameters);
                    var pdt = pjts.Find(m => m.Name.ToLower() == product.ProductName.ToLower() && m.Parent == null);
                    int pdtId = pdt == null ? 0 : pdt.Id;
                    RMRepository repo = new RMRepository();
                    var pjtIds = repo.GetProjectsofUser(token);
                    if (pjtIds.Contains(pdtId))
                        result.message = Resources.Resource.ProductExist;
                    else
                        result.message = Resources.Resource.ProductAutherization;
                    return result;
                }
                catch (TestLinkException ex)
                {
                    TMFLogger.LogInformation("THIS EXCEPTION IS EXPECTED! - MEANS THE PROJECT NOT EXIST. SO WE NEED TO CREATE IT");
                    TMFLogger.LogException(ex);
                }
                if (testProjectId <= 0)
                {
                    var tlResult = tLink.CreateProject(product.ProductName, product.ProductName, product.Description);
                    testProjectId = tlResult.id;
                    TLRepository tLProjectRepository = new TLRepository();
                    tLProjectRepository.AddProjectRelations(testProjectId);
                }
                try
                {
                    int id = -1;
                    Project project = new Project();
                    project.Name = product.ProductName;
                    project.Description = product.Description;
                    project.IsPublic = true;
                    project.Identifier = Guid.NewGuid().ToString();
                    string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                    var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                    project = manager.CreateObject<Project>(project);
                    id = project.Id;
                    if (product.Members == null)
                    {
                        RMRepository rmuserRepo = new RMRepository();
                        var data = rmuserRepo.GetDefaultUser();
                        if(data != null)
                        {
                            List<UserModel> defaultUser = new List<UserModel>
                            {
                                new UserModel { Id = data.Id, Name = data.Name, Role = data.Role }
                            };
                            product.Members = defaultUser;
                        }
                    }
                    UpdateMembers(project.Id, product.Members);
                    result.status = true;
                    result.id = project.Id;
                    result.message = Resources.Resource.ProductCreationSuccess;
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                    TLRepository tLProjectRepository = new TLRepository();
                    tLProjectRepository.DeleteProject(testProjectId, true, false);
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            /* DMG213 mod START Modification for send mail*/
            if (result.status && isSingle)
            {
                var ids = (from a in product.Members select a.Id.ToString()).ToList();
                System.Threading.Tasks.Task.Run(() => SendProductNotification(1, ids, product.ProductName));
            }
            /* DMG213 mod END Modification for send mail*/
            return result;
        }

        /// <summary>
        /// Method to update product details
        /// </summary>
        /// <param name="product">Product details</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isSingle">Logged in user token</param>
        /// <returns>Returns update product status</returns>
        /// 2019/01/30, Sujith A, VJP12_Initial version
        /// 2021/02/17, Vinoth N, DMG213_Modification for send mail 
        public GeneralResultModel UpdateProduct(ProductModel product, string token, bool isSingle = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            resultModel.message = Resources.Resource.ProductUpdateFaild;
            string apiKey = string.Empty;
            try
            {
                var tLink = ConnectTestLink(token, out apiKey);
                int id = -1;
                product.ProductName = product.ProductName.Trim();
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var parameters = new NameValueCollection { { RedmineKeys.PARENT, null } };
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var projects = manager.GetObjects<Project>(parameters);
                var pjt = projects.Find(m => m.Name.ToLower() == product.ProductName.ToLower());
                RMRepository repo = new RMRepository();
                var users = repo.GetMembers(product.Id).Select(p => p.Id).ToList();
                if (pjt != null && pjt.Id != product.Id && pjt.Parent == null)
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.ProductNameExist;
                    return resultModel;
                }
                else
                {
                    pjt = projects.Find(m => m.Id == product.Id);
                    if (pjt == null)
                    {
                        resultModel.status = false;
                        resultModel.message = Resources.Resource.ProductNotFound;
                        return resultModel;
                    }
                    string oldPjtName = pjt.Name;
                    var oldDescription = pjt.Description;
                    pjt.Name = product.ProductName;
                    pjt.Description = string.IsNullOrEmpty(product.Description) ? "" : product.Description;
                    manager.UpdateObject<Project>(product.Id.ToString(), pjt);
                    int testProjectId = 0;
                    try
                    {
                        TestProject tProject = tLink.GetProject(oldPjtName);
                        testProjectId = tProject.id;
                        TLRepository tlRepository = new TLRepository();
                        tlRepository.UpdateNodeHeirarchy(testProjectId, product.ProductName);
                        tlRepository.UpdatePrefix(testProjectId, product.ProductName);
                        if (product.Members == null)
                        {
                            RMRepository rmuserRepo = new RMRepository();
                            var data = rmuserRepo.GetDefaultUser();
                            if (data != null)
                            {
                                List<UserModel> defaultUser = new List<UserModel>
                                {
                                    new UserModel { Id = data.Id, Name = data.Name, Role = data.Role }
                                };
                                product.Members = defaultUser;
                            }
                        }
                        UpdateMembers(pjt.Id, product.Members);
                        resultModel.status = true;
                        resultModel.message = Resources.Resource.ProductUpdateSuccess;
                        /* DMG213 mod START Modification for send mail*/
                        if (resultModel.status && isSingle)
                        {
                            var needToUser = product.Members.Select(p => p.Id).Except(users);
                            if (needToUser.Count() > 0)
                                System.Threading.Tasks.Task.Run(() => SendProductNotification(1, needToUser.Select(p => p.ToString()).ToList(), product.ProductName));
                        }
                        /* DMG213 mod END Modification for send mail*/
                    }
                    catch (Exception ex)
                    {
                        TMFLogger.LogInformation("THIS EXCEPTION IS EXPECTED!");
                        TMFLogger.LogException(ex);
                        pjt.Name = oldPjtName;
                        pjt.Description = string.IsNullOrEmpty(oldDescription) ? "" : oldDescription; ;
                        manager.UpdateObject<Project>(product.Id.ToString(), pjt);
                        TMFLogger.LogException(ex);
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return resultModel;
        }

        /// <summary>
        /// Method to delete product
        /// </summary>
        /// <param name="productId">Unique id of the product</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isDeletePermission">is user has delete permisison</param>
        /// <returns>Returns delete status</returns>
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        /// 2020/07/26, Vinoth N, C51165_Modification for remove f2t folder
        public GeneralResultModel DeleteProduct(int productId, string token, bool isPermanentDelete = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            string apiKey = string.Empty;
            try
            {
                var tLink = ConnectTestLink(token, out apiKey);
                Project project = new Project();
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.ID, productId.ToString() } };
                var projects = manager.GetObjects<Project>(parameters);
                var pjt = projects.Find(m => m.Id == productId);
                resultModel.operation = pjt.Name;
                if (pjt == null || (pjt.Status != ProjectStatus.Active && !isPermanentDelete))
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.ProductNotFound;
                    return resultModel;
                }
                TLRepository tlRepository = new TLRepository();
                int testProjectId = 0;
                var listProj = tLink.GetProjects();
                try
                {
                    TestProject tProject = tLink.GetProject(pjt.Name);
                    testProjectId = tProject.id;
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                    TMFLogger.LogInformation("Project not found in TestLink");
                }
                if (isPermanentDelete && pjt.Status != ProjectStatus.Active)
                {
                    /* C51165 mod START Modification for remove f2t folder */
                    var dirPath = ConfigurationManager.AppSettings["F2TDocPath"].ToString();
                    if (DeleteF2TFolder(Path.Combine(dirPath, pjt.Name)))
                    {
                        manager.DeleteObject<Project>(productId.ToString(), null);
                        resultModel.status = true;
                        if (testProjectId > 0)
                            resultModel.status = tlRepository.DeleteProject(testProjectId, isPermanentDelete, false);
                    }
                    else
                    {
                        resultModel.status = false;
                        resultModel.message = Resources.Resource.ProductDeleteFaild;
                    }
                    /* C51165 mod END Modification for remove f2t folder*/
                }
                else
                {
                    RMRepository rmRepo = new RMRepository();
                    resultModel.status = rmRepo.DeleteProject(productId);
                }
            }
            catch (Exception ex)
            {
                resultModel.status = false;
                resultModel.message = Resources.Resource.ProductDeleteFaild;
                TMFLogger.LogException(ex);
            }

            return resultModel;
        }

        /// <summary>
        /// Method to retrieve version details.
        /// </summary>
        /// <param name="versionId">Unique id of the version.</param>
        /// <param name="token">Logged in user token.</param>
        /// <param name="isDeletePermission">Is user has delete permisison.</param>
        /// <returns>Returns version details.</returns>
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items.
        /// 2021/06/16, Vinoth N, EL5873_Modification for get TAS mahines.
        public VersionModel GetVersionDetails(int versionId, string token, bool isDeletePermission = false)
        {
            VersionModel version = new VersionModel();
            try
            {
                string apiKey = "";
                var proxy = ConnectTestLink(token, out apiKey);
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.PROJECTS, RedmineKeys.ALL } };
                RMRepository repo = new RMRepository();
                var pjts = repo.GetAllProjects();
                var pjtIds = repo.GetProjectsofUser(token);
                ProductModel pdt = new ProductModel();
                bool isParentActive = true;
                /* EL5873 mod START Modification for get TAS mahines*/
                List<SelectListItemHelper> item = new List<SelectListItemHelper> {
                    new SelectListItemHelper { Text = Resources.Resource.Select, Value = "0"}};
                version.MachineList = item;
                /* EL5873 mod END Modification for get TAS mahines*/
                foreach (var pjt in pjts)
                {
                    if (pjt.Status != (int)ProjectStatus.Active && !isDeletePermission)
                    {
                        continue;
                    }
                    if (pjt.Parent == 0)
                    {
                        isParentActive = pjt.Status == (int)ProjectStatus.Active ? true : false;
                        continue;
                    }
                    else if (pjt.Id == versionId)
                    {
                        version.Id = pjt.Id;
                        version.VersionName = pjt.Name;
                        version.Description = pjt.Description;
                        version.Members = ConvertToModel(repo.GetMembers(pjt.Id));
                        version.MembersCount = version.Members.Count;
                        version.IsActive = pjt.Status == (int)ProjectStatus.Active ? isParentActive : false;
                        pdt.Id = version.ProductId = pjt.Parent;
                        pdt.IsMember = pjtIds.Contains(pjt.Parent);
                        version.IsMember = pjtIds.Contains(version.Id) || pdt.IsMember;
                        continue;
                    }
                    else
                    {
                        if (DoGetModule(pdt, version, pjt, pjtIds))
                            continue;
                    }
                }
                if (!version.IsActive)
                    version.Modules.ForEach(x => x.IsActive = false);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            if (version.Modules != null && version.Modules.Count > 1)
                version.Modules = version.Modules.OrderByDescending(x => x.IsActive).ToList();
            return version;
        }

        /// <summary>
        /// Method to add version
        /// </summary>
        /// <param name="version">Version details</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isSingle">Logged in user token</param>
        /// <returns>Returns add status</returns>
        /// 2019/01/30, Sujith A, VJP12_Initial version
        /// 2021/02/17, Vinoth N, DMG213_Modification for send mail 
        public GeneralResultModel AddVersion(VersionModel version, string token, bool isSingle = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            resultModel.message = Resources.Resource.VersionCreateFaild;
            string productName = String.Empty;
            string apiKey = string.Empty;
            try
            {
                version.VersionName = version.VersionName.Trim();
                var tLink = ConnectTestLink(token, out apiKey);
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var parameters = new NameValueCollection { { RedmineKeys.PARENT, null } };
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var projects = manager.GetObjects<Project>(parameters);
                if (!ValidateVersion(projects, version.Id, version.VersionName, version.ProductId, token, ref resultModel.message))
                {
                    return resultModel;
                }
                var pjt = projects.Find(m => m.Id == version.ProductId);
                Project project = new Project();
                project.Name = version.VersionName;
                project.Description = version.Description;
                project.IsPublic = true;
                project.Identifier = Guid.NewGuid().ToString();
                project.Parent = new IdentifiableName();
                project.Parent.Id = pjt.Id;
                project.Parent.Name = pjt.Name;
                productName = pjt.Name;
                project = manager.CreateObject<Project>(project);
                int testProjectId = 0;
                try
                {
                    TestProject tProject = tLink.GetProject(pjt.Name);
                    testProjectId = tProject.id;
                    version.Description = string.IsNullOrEmpty(version.Description) ? "" : version.Description;
                    var res = tLink.CreateTestSuite(testProjectId, version.VersionName, version.Description);
                    UpdateMembers(project.Id, version.Members);
                    resultModel.status = true;
                    resultModel.id = project.Id;
                    resultModel.message = Resources.Resource.VersionAddSuccess;
                }
                catch (Exception ex)
                {
                    TMFLogger.LogInformation("THIS EXCEPTION IS EXPECTED! - MEANS THE PROJECT NOT EXIST. SO WE NEED TO CREATE IT");
                    TMFLogger.LogException(ex);
                    resultModel.status = false;
                    manager.DeleteObject<Project>(project.Id.ToString());
                    resultModel.message = Resources.Resource.VersionCreateFaild;
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                resultModel.message = Resources.Resource.VersionCreateFaild;
            }
            /* DMG213 mod START Modification for send mail*/
            if (resultModel.status && isSingle)
            {
                var ids = (from a in version.Members select a.Id.ToString()).ToList();
                System.Threading.Tasks.Task.Run(() => SendProductNotification(2, ids, productName + " &gt; " + version.VersionName));
            }
            /* DMG213 mod END Modification for send mail*/
            return resultModel;
        }

        /// <summary>
        /// Method to update version details
        /// </summary>
        /// <param name="version">Version details</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isSingle">Logged in user token</param>
        /// <returns>Returns update status</returns>
        /// 2019/01/30, Sujith A, VJP12_Initial version
        /// 2019/07/09, Sujith, WG3736_Modification for update test plan name
        /// 2021/02/18, Vinoth N, DMG213_Modification for send mail 
        public GeneralResultModel UpdateVersion(VersionModel version, string token, bool isSingle = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            string productName = String.Empty;
            resultModel.message = Resources.Resource.VersionUpdateFaild;
            string apiKey = string.Empty;
            try
            {
                version.VersionName = version.VersionName.Trim();
                var tLink = ConnectTestLink(token, out apiKey);
                int id = -1;
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.PARENT, null } };
                var projects = manager.GetObjects<Project>(parameters);
                RMRepository repo = new RMRepository();
                var users = repo.GetMembers(version.Id).Select(p => p.Id).ToList();
                if (!ValidateVersion(projects, version.Id, version.VersionName, version.ProductId, token, ref resultModel.message))
                {
                    return resultModel;
                }
                else
                {
                    Project project = projects.Find(m => m.Id == version.Id);
                    var oldPjtName = project.Name;
                    var oldDescription = project.Description;
                    RMRepository rmRepo = new RMRepository();
                    rmRepo.UpdateProject(project.Id, version.VersionName, version.Description);
                    int testProjectId = 0;
                    try
                    {
                        var product = projects.Find(m => m.Id == version.ProductId);
                        productName = product.Name;
                        TestProject tProject = tLink.GetProject(product.Name);
                        testProjectId = tProject.id;
                        var ts = tLink.GetFirstLevelTestSuitesForTestProject(testProjectId);
                        var versionTs = ts.Find(m => m.name.ToLower() == oldPjtName.ToLower());
                        TLRepository tlRepository = new TLRepository();
                        resultModel.status = tlRepository.UpdateNodeHeirarchy(versionTs.id, version.VersionName);
                        UpdateMembers(project.Id, version.Members);
                        /* WG3736 mod START Modification for test plan name update*/
                        tlRepository.UpdateTestPlanName(testProjectId, oldPjtName + "_", version.VersionName + "_");
                        /* WG3736 mod END Modification for test plan name update*/
                        resultModel.message = Resources.Resource.VersionUpdateSuccess;
                        /* DMG213 mod START Modification for send mail*/
                        if (resultModel.status && isSingle)
                        {
                            var needToUser = version.Members.Select(p => p.Id).Except(users);
                            if (needToUser.Count() > 0)
                                System.Threading.Tasks.Task.Run(() => SendProductNotification(2, needToUser.Select(p => p.ToString()).ToList(), productName + " &gt; " + version.VersionName));
                        }
                        /* DMG213 mod END Modification for send mail*/
                    }
                    catch (Exception ex)
                    {
                        TMFLogger.LogException(ex);
                        oldDescription = string.IsNullOrEmpty(oldDescription) ? "" : oldDescription;
                        rmRepo.UpdateProject(project.Id, oldPjtName, oldDescription);
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return resultModel;
        }

        /// <summary>
        /// Method to delete version
        /// </summary>
        /// <param name="versionId">Unique id of the version</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isPermanentDelete">flag for tDelete</param>
        /// <returns>Returns delete status</returns>
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        /// 2020/07/26, Vinoth N, C51165_Modification for remove f2t folder
        public GeneralResultModel DeleteVersion(int versionId, string token, bool isPermanentDelete = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            resultModel.message = Resources.Resource.VersionDeleteFaild;
            resultModel.status = false;
            string apiKey = string.Empty;
            try
            {
                var tLink = ConnectTestLink(token, out apiKey);
                Project project = new Project();
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.ID, versionId.ToString() } };
                var projects = manager.GetObjects<Project>(parameters);
                var pjt = projects.Find(m => m.Id == versionId);
                resultModel.operation = pjt.Name;
                if (pjt == null || (pjt.Status != ProjectStatus.Active && !isPermanentDelete))
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.VersionNotFound;
                    return resultModel;
                }
                bool parentActive = projects.Find(m => m.Id == pjt.Parent.Id).Status == ProjectStatus.Active;
                if (isPermanentDelete && (pjt.Status != ProjectStatus.Active || !parentActive))
                {
                    /* C51165 mod START Modification for remove f2t folder */
                    var dirPath = ConfigurationManager.AppSettings["F2TDocPath"].ToString();
                    if (DeleteF2TFolder(Path.Combine(dirPath, pjt.Parent.Name, pjt.Name)))
                    {
                        TestProject tProject = tLink.GetProject(pjt.Parent.Name);
                        int testProjectId = tProject.id;
                        var ts = tLink.GetFirstLevelTestSuitesForTestProject(testProjectId);
                        var versionTs = ts.Find(m => m.name == pjt.Name);
                        TLRepository tlRepository = new TLRepository();
                        if (versionTs != null)
                            resultModel.status = tlRepository.DeleteVersion(versionTs.id.ToString());
                        if (resultModel.status)
                        {
                            manager.DeleteObject<Project>(versionId.ToString(), null);
                            resultModel.message = Resources.Resource.VersionDeleteSuccess;
                            RMUserRepository rmuserRepo = new RMUserRepository();
                            rmuserRepo.DeleteMembers(versionId);
                        }
                    }
                    else
                    {
                        resultModel.status = false;
                        resultModel.message = Resources.Resource.VersionDeleteFaild;
                    }
                    /* C51165 mod END Modification for remove f2t folder*/
                }
                else
                {
                    RMRepository rmRepo = new RMRepository();
                    resultModel.status = rmRepo.DeleteProject(versionId);
                }
            }
            catch (Exception ex)
            {
                resultModel.status = false;
                resultModel.message = Resources.Resource.VersionDeleteFaild;
                TMFLogger.LogException(ex);
            }

            return resultModel;
        }

        /// <summary>
        /// Method to restore deleted version
        /// </summary>
        /// <param name="versionId">Unique id of the version</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isPermanentDelete">is Permanent Delete permission</param>
        /// <returns>Returns restore status</returns>
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        public GeneralResultModel RestoreVersion(int versionId, string token, bool isPermanentDelete = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            resultModel.message = Resources.Resource.VersionCreateFaild;
            string apiKey = string.Empty;
            try
            {
                var tLink = ConnectTestLink(token, out apiKey);
                Project project = new Project();
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.ID, versionId.ToString() } };
                var projects = manager.GetObjects<Project>(parameters);
                var pjt = projects.Find(m => m.Id == versionId);
                if (pjt == null || !isPermanentDelete)
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.VersionNotFound;
                    return resultModel;
                }
                RMRepository rmRepo = new RMRepository();
                resultModel.status = rmRepo.RestoreProject(versionId);
            }
            catch (Exception ex)
            {
                resultModel.status = false;
                TMFLogger.LogException(ex);
            }

            return resultModel;
        }

        /// <summary>
        /// Method to retrieve module details
        /// </summary>
        /// <param name="moduleId">Unique id of the module</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isDeletePermission">is user has delete permisison</param>
        /// <returns>Returns module details</returns>
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        /// 2020/10/23, Vinoth N, CRC207_Modification for mapping TAS Script
        public ModuleModel GetModuleDetails(int moduleId, string token, bool isDeletePermission = false)
        {
            ModuleModel module = new ModuleModel();
            try
            {
                string apiKey = "";
                var proxy = ConnectTestLink(token, out apiKey);
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.PROJECTS, RedmineKeys.ALL } };
                var pjts = manager.GetObjects<Project>(parameters);
                bool isParentActive = true;
                RMRepository repo = new RMRepository();
                var pjtIds = repo.GetProjectsofUser(token);
                foreach (var pjt in pjts)
                {
                    if (pjt.Status != ProjectStatus.Active && !isDeletePermission)
                    {
                        continue;
                    }
                    if (pjt.Parent == null)
                    {
                        isParentActive = pjt.Status == ProjectStatus.Active ? true : false;
                        continue;
                    }
                    else if (pjt.Id == moduleId)
                    {
                        var version = pjts.Find(m => m.Id == pjt.Parent.Id);
                        bool verActive = version.Status == ProjectStatus.Active ? true : false;
                        module.Id = pjt.Id;
                        module.ModuleName = pjt.Name;
                        module.Description = pjt.Description;
                        module.IsActive = pjt.Status == ProjectStatus.Active ? isParentActive ? verActive : isParentActive : false;
                        module.IsMember = pjtIds.Contains(module.Id) || pjtIds.Contains(version.Id) || pjtIds.Contains(version.Parent.Id);
                        module.Members = ConvertToModel(repo.GetMembers(pjt.Id));
                        module.MembersCount = module.Members.Count;
                        continue;
                    }
                    else
                    {
                        if (pjt.Parent.Id == module.Id)
                        {
                            DocumentModel docModel = new DocumentModel();
                            docModel.Id = pjt.Id;
                            docModel.Name = pjt.Name;
                            docModel.DocumentPath = pjt.Description;
                            docModel.IsActive = pjt.Status == ProjectStatus.Active ? module.IsActive : false;
                            module.DocModels.Add(docModel);
                            module.DocCount++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            if (module.DocModels != null && module.DocModels.Count > 1)
                module.DocModels = module.DocModels.OrderByDescending(x => x.IsActive).ToList();
            /* CRC207 mod START Modification for mapping TAS Script  */
            List<SelectListItemHelper> item = new List<SelectListItemHelper> {
                    new SelectListItemHelper { Text = Resources.Resource.Select, Value = "0"}};
            module.MachineList = item;
            /* CRC207 mod END Modification for mapping TAS Script  */
            return module;
        }

        /// <summary>
        /// Method to add module
        /// </summary>
        /// <param name="module">Module details</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isSingle">flag</param>
        /// <returns>Returns add status</returns>
        /// 2019/01/30, Sujith A, VJP12_Initial version
        /// 2021/02/18, Vinoth N, DMG213_Modification for send mail 
        public GeneralResultModel AddModule(ModuleModel module, string token, bool isSingle = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            string apiKey = string.Empty;
            string productName = String.Empty;
            string versionName = String.Empty;
            resultModel.message = Resources.Resource.ModuleAddError;
            try
            {
                module.ModuleName = module.ModuleName.Trim();
                var tLink = ConnectTestLink(token, out apiKey);
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var parameters = new NameValueCollection { { RedmineKeys.PARENT, null } };
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var projects = manager.GetObjects<Project>(parameters);
                if (!ValidateModule(projects, 0, module.ModuleName, module.VersionId, module.ProductId, token, ref resultModel.message))
                {
                    return resultModel;
                }
                var product = projects.Find(m => m.Id == module.ProductId && m.Status == ProjectStatus.Active);
                var version = projects.Find(m => m.Id == module.VersionId && m.Status == ProjectStatus.Active);
                Project project = new Project();
                project.Name = module.ModuleName;
                project.Description = module.Description;
                project.IsPublic = true;
                project.Identifier = Guid.NewGuid().ToString();
                project.Parent = new IdentifiableName();
                project.Parent.Id = version.Id;
                project.Parent.Name = version.Name;
                project = manager.CreateObject<Project>(project);
                int testProjectId = 0;
                try
                {
                    productName = product.Name;
                    versionName = version.Name;
                    TestProject tProject = tLink.GetProject(productName);
                    testProjectId = tProject.id;
                    var ts = tLink.GetFirstLevelTestSuitesForTestProject(testProjectId);
                    int versionTSId = ts.Find(m => m.name == versionName).id;
                    module.Description = string.IsNullOrEmpty(module.Description) ? "" : module.Description;
                    var res = tLink.CreateTestSuite(testProjectId, module.ModuleName, module.Description, versionTSId);
                    UpdateMembers(project.Id, module.Members);
                    resultModel.status = true;
                    resultModel.id = project.Id;
                    resultModel.message = Resources.Resource.ModuleAddSuccess;
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                    resultModel.status = false;
                    manager.DeleteObject<Project>(project.Id.ToString());
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            /* DMG213 mod START Modification for send mail*/
            if (resultModel.status && isSingle)
            {
                var ids = (from a in module.Members select a.Id.ToString()).ToList();
                System.Threading.Tasks.Task.Run(() => SendProductNotification(3, ids, productName + " &gt; " + versionName + " &gt; " + module.ModuleName));
            }
            /* DMG213 mod END Modification for send mail*/
            return resultModel;
        }

        /// <summary>
        /// Method to update module details
        /// </summary>
        /// <param name="module">Module details</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isSingle">flag</param>
        /// <returns>Returns update status</returns>
        /// 2019/01/30, Sujith A, VJP12_Initial version
        /// 2019/07/09, Sujith, WG3736_Modification for update test plan name
        /// 2021/02/19, Vinoth N, DMG213_Modification for send mail 
        public GeneralResultModel UpdateModule(ModuleModel module, string token, bool isSingle = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            resultModel.message = Resources.Resource.ModuleUpdateError;
            string productName = String.Empty;
            string versionName = String.Empty;
            string apiKey = string.Empty;
            try
            {
                module.ModuleName = module.ModuleName.Trim();
                var tLink = ConnectTestLink(token, out apiKey);
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.PARENT, null } };
                var projects = manager.GetObjects<Project>(parameters);
                RMRepository repo = new RMRepository();
                var users = repo.GetMembers(module.Id).Select(p => p.Id).ToList();
                if (!ValidateModule(projects, module.Id, module.ModuleName, module.VersionId, module.ProductId, token, ref resultModel.message))
                {
                    return resultModel;
                }
                else
                {
                    var product = projects.Find(m => m.Id == module.ProductId && m.Status == ProjectStatus.Active);
                    var version = projects.Find(m => m.Id == module.VersionId && m.Status == ProjectStatus.Active);
                    Project project = projects.Find(m => m.Id == module.Id);
                    var oldPjtName = project.Name;
                    var oldDesciption = project.Description;
                    RMRepository rmRepo = new RMRepository();
                    rmRepo.UpdateProject(project.Id, module.ModuleName, module.Description);
                    try
                    {
                        productName = product.Name;
                        versionName = version.Name;
                        int testProjectId = 0;
                        TestProject tProject = tLink.GetProject(productName);
                        testProjectId = tProject.id;
                        var ts = tLink.GetFirstLevelTestSuitesForTestProject(testProjectId);
                        var versionTs = ts.Find(m => m.name == versionName);
                        var moduleTsList = tLink.GetTestSuitesForTestSuiteNew(versionTs.id);
                        var moduleTS = moduleTsList.Find(m => m.Name == oldPjtName);
                        TLRepository tlRepository = new TLRepository();
                        resultModel.status = tlRepository.UpdateNodeHeirarchy(moduleTS.Id, module.ModuleName);
                        UpdateMembers(project.Id, module.Members);
                        /* WG3736 mod START Modification for test plan name update*/
                        tlRepository.UpdateTestPlanName(testProjectId, "_" + oldPjtName + "_", "_" + module.ModuleName + "_");
                        /* WG3736 mod END Modification for test plan name update*/
                        resultModel.message = Resources.Resource.ModuleUpdateSuccess;
                        /* DMG213 mod START Modification for send mail*/
                        if (resultModel.status && isSingle)
                        {
                            var needToUser = module.Members.Select(p => p.Id).Except(users);
                            if (needToUser.Count() > 0)
                                System.Threading.Tasks.Task.Run(() => SendProductNotification(3, needToUser.Select(p => p.ToString()).ToList(), productName + " &gt; " + versionName + " &gt; " + module.ModuleName));
                        }
                        /* DMG213 mod END Modification for send mail*/
                    }
                    catch (Exception ex)
                    {
                        TMFLogger.LogException(ex);
                        oldDesciption = string.IsNullOrEmpty(oldDesciption) ? "" : oldDesciption;
                        rmRepo.UpdateProject(project.Id, oldPjtName, oldDesciption);
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return resultModel;
        }

        /// <summary>
        /// Method to delete module
        /// </summary>
        /// <param name="moduleId">Unique id of the module</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isPermDelete">flag for isPermanentDelete</param>
        /// <returns>Returns delete status</returns>
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        /// 2020/07/26, Vinoth N, C51165_Modification for remove f2t folder
        public GeneralResultModel DeleteModule(int moduleId, string token, bool isPermDelete)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            string apiKey = string.Empty;
            try
            {
                var tLink = ConnectTestLink(token, out apiKey);
                Project project = new Project();
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.ID, moduleId.ToString() } };
                var projects = manager.GetObjects<Project>(parameters);
                var pjt = projects.Find(m => m.Id == moduleId);
                resultModel.operation = pjt.Name;
                if (pjt == null || (pjt.Status != ProjectStatus.Active && !isPermDelete))
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.ModuleNotFound;
                    return resultModel;
                }
                bool parentActive = projects.Find(m => m.Id == pjt.Parent.Id).Status == ProjectStatus.Active;
                var grandParent = projects.Find(m => m.Id == pjt.Parent.Id).Parent.Id;
                bool grandParentActive = projects.Find(m => m.Id == grandParent).Status == ProjectStatus.Active;
                if (isPermDelete && (pjt.Status != ProjectStatus.Active || !parentActive || !grandParentActive))
                {
                    int testProjectId = 0;
                    var version = projects.Find(m => m.Id == pjt.Parent.Id);
                    var product = projects.Find(m => m.Id == version.Parent.Id);
                    /* C51165 mod START Modification for remove f2t folder */
                    var dirPath = ConfigurationManager.AppSettings["F2TDocPath"].ToString();
                    if (DeleteF2TFolder(Path.Combine(dirPath, product.Name, version.Name, pjt.Name)))
                    {
                        TestProject tProject = tLink.GetProject(product.Name);
                        testProjectId = tProject.id;
                        var ts = tLink.GetFirstLevelTestSuitesForTestProject(testProjectId);
                        var versionTs = ts.Find(m => m.name == version.Name);
                        if (versionTs != null)
                        {
                            var moduleTsList = tLink.GetTestSuitesForTestSuiteNew(versionTs.id);
                            if (moduleTsList != null)
                            {
                                var moduleTS = moduleTsList.Find(m => m.Name == pjt.Name);
                                if (moduleTS != null)
                                {
                                    TLRepository tlRepository = new TLRepository();
                                    resultModel.status = tlRepository.DeleteModule(moduleTS.Id.ToString());
                                    if (resultModel.status)
                                    {
                                        manager.DeleteObject<Project>(pjt.Id.ToString());
                                        resultModel.message = Resources.Resource.ModuleDeleteSuccess;
                                        RMUserRepository rmuserRepo = new RMUserRepository();
                                        rmuserRepo.DeleteMembers(moduleId);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        resultModel.status = false;
                        resultModel.message = Resources.Resource.ModuleDeleteFaild;
                    }
                    /* C51165 mod END Modification for remove f2t folder*/
                }
                else
                {
                    RMRepository rmRepo = new RMRepository();
                    resultModel.status = rmRepo.DeleteProject(moduleId);
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                resultModel.message = Resources.Resource.ModuleDeleteFaild;
            }

            return resultModel;
        }

        /// <summary>
        /// Method to restore deleted module
        /// </summary>
        /// <param name="moduleId">Unique id of the module</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isPermanentDelete">flag for isPermanentDelete</param>
        /// <returns>Returns restore status</returns>
        /// 2019/03/12, Sharon Thankachan, VJP192_Modification for Deleted Product items
        public GeneralResultModel RestoreModule(int moduleId, string token, bool isPermanentDelete = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            string apiKey = string.Empty;
            try
            {
                var tLink = ConnectTestLink(token, out apiKey);
                Project project = new Project();
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.ID, moduleId.ToString() } };
                var projects = manager.GetObjects<Project>(parameters);
                var pjt = projects.Find(m => m.Id == moduleId);
                if (pjt == null || !isPermanentDelete)
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.ModuleNotFound;
                    return resultModel;
                }
                RMRepository rmRepo = new RMRepository();
                resultModel.status = rmRepo.RestoreProject(moduleId);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                resultModel.message = Resources.Resource.ModuleDeleteFaild;
            }

            return resultModel;
        }

        /// <summary>
        /// Method to map document to module
        /// </summary>
        /// <param name="moduleId">Unique id of the module</param>
        /// <param name="documentPath">Document path to map</param>
        /// <param name="token">Logged in user token</param>
        /// <returns>Returns mapping status</returns>
        public GeneralResultModel MapDocument(int moduleId, string documentPath, string token)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            var docs = documentPath.Split('|');
            resultModel.message = Resources.Resource.MapDocFaild;
            string apiKey = string.Empty;
            try
            {
                var tLink = ConnectTestLink(token, out apiKey);
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var parameters = new NameValueCollection { { RedmineKeys.PARENT, null } };
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var projects = manager.GetObjects<Project>(parameters);
                var module = projects.Find(m => m.Id == moduleId && m.Status == ProjectStatus.Active);
                if (module == null)
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.ModuleNotExist;
                    return resultModel;
                }
                var version = projects.Find(m => module.Parent != null && m.Id == module.Parent.Id && m.Status == ProjectStatus.Active);
                if (version == null)
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.VersionNotExist;
                    return resultModel;
                }
                var product = projects.Find(m => version.Parent != null && version.Parent.Id == m.Id);
                if (product == null)
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.ProductNotExist;
                    return resultModel;
                }
                foreach (var doc in docs)
                {
                    if (string.IsNullOrEmpty(doc)) { continue; }
                    var docName = doc.Substring(doc.LastIndexOf("\\") + 1);
                    docName = docName.Remove(docName.LastIndexOf('.'));
                    var docProject = projects.Find(m => m.Parent != null && m.Parent.Id == module.Id && m.Name.ToLower() == docName.ToLower());
                    if (docProject != null)
                    {
                        resultModel.status = false;
                        RMRepository repo = new RMRepository();
                        var pjtIds = repo.GetProjectsofUser(token);
                        if (pjtIds.Contains(module.Id))
                            resultModel.message = Resources.Resource.DocumentAlreadyMapped;
                        else
                            resultModel.message = Resources.Resource.MappingPermission;
                    }
                    else
                    {
                        Project project = new Project();
                        project.Name = docName;
                        project.Description = doc;
                        project.IsPublic = true;
                        project.Identifier = Guid.NewGuid().ToString();
                        project.Parent = new IdentifiableName();
                        project.Parent.Id = module.Id;
                        project.Parent.Name = module.Name;
                        project = manager.CreateObject<Project>(project);
                        int testProjectId = 0;
                        try
                        {
                            TestProject tProject = tLink.GetProject(product.Name);
                            testProjectId = tProject.id;
                            var ts = tLink.GetFirstLevelTestSuitesForTestProject(testProjectId);
                            if (ts.Find(m => m.name == version.Name) == null)
                            {
                                throw new Exception("Version not exist in testlink");
                            }
                            int versionTSId = ts.Find(m => m.name == version.Name).id;
                            var moduleTSlist = tLink.GetTestSuitesForTestSuiteNew(versionTSId);
                            var moduleTS = moduleTSlist.Find(m => m.Name == module.Name);
                            if (moduleTS == null)
                            {
                                throw new Exception("Module not exist in testlink");
                            }
                            var res = tLink.CreateTestSuite(testProjectId, docName, doc, moduleTS.Id);
                            resultModel.status = true;
                            var testPlanName = version.Name + "_" + module.Name + "_" + docName;
                            int tPlanId = 0;
                            try
                            {
                                var tPlan = tLink.getTestPlanByName(tProject.name, testPlanName.Replace("&", "&amp;"));
                                tPlanId = tPlan != null ? tPlan.id : 0;
                            }
                            catch (Exception ex)
                            {
                                TMFLogger.LogInformation("THIS EXCEPTION IS EXPECTED!");
                                TMFLogger.LogException(ex);
                            }
                            if (tPlanId == 0)
                            {
                                var tplanResult = tLink.CreateTestPlan(testPlanName, product.Name);
                                tPlanId = tplanResult.id;
                            }
                            int bid = 0;
                            try
                            {
                                var tPlan = tLink.GetBuildsForTestPlan(tPlanId);
                                if (tPlan != null)
                                {
                                    var build = tPlan.Find(m => m.name == "B1");
                                    if (build != null) { bid = build.id; }
                                }
                            }
                            catch (Exception ex)
                            {
                                TMFLogger.LogInformation("THIS EXCEPTION IS EXPECTED!");
                                TMFLogger.LogException(ex);
                            }
                            if (bid == 0)
                            {
                                var bResult = tLink.CreateBuild(tPlanId, "B1", "");
                            }
                            resultModel.message = Resources.Resource.MapDocumentSuccess;
                        }
                        catch (Exception ex)
                        {
                            TMFLogger.LogException(ex);
                            resultModel.status = false;
                            manager.DeleteObject<Project>(project.Id.ToString());
                            resultModel.message = Resources.Resource.MapDocFaild;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                resultModel.message = Resources.Resource.MapDocFaild;
            }

            return resultModel;

        }

        /// <summary>
        /// Method to update document to module
        /// </summary>
        /// <param name="moduleId">Unique id of the module</param>
        /// <param name="document">Document detail to update</param>
        /// <param name="documentPath">Document path to update</param>
        /// <param name="token">Logged in user token</param>
        /// <returns>Returns update status</returns>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        public GeneralResultModel UpdateDocument(int moduleId, DocumentModel document, string documentPath, string token)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            string apiKey = string.Empty;
            var tLink = ConnectTestLink(token, out apiKey);
            string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
            var parameters = new NameValueCollection { { RedmineKeys.PARENT, null } };
            var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
            var projects = manager.GetObjects<Project>(parameters);
            var docProject = projects.Find(m => m.Parent != null && m.Parent.Id == moduleId && m.Name.ToLower() == document.Name.ToLower());
            if (docProject != null)
            {
                RMRepository rmRepo = new RMRepository();
                rmRepo.UpdateProject(docProject.Id, docProject.Name, documentPath);
            }
            return resultModel;
        }

        /// <summary>
        /// Method to remove mapping between document and module
        /// </summary>
        /// <param name="documentId">Unique id of the document</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="ispermDelete">flag for isPermanentDelete</param>
        /// <returns>Returns the remove status</returns>
        /// 2019/02/22, Sharon Thankachan, VJP192_Modification for Deleted Product items
        public GeneralResultModel RemoveDocument(int documentId, string token, bool ispermDelete)
        {
            TMFLogger.LogMethodEntry();
            GeneralResultModel resultModel = new GeneralResultModel();
            string apiKey = string.Empty;
            try
            {
                var tLink = ConnectTestLink(token, out apiKey);
                Project project = new Project();
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.ID, documentId.ToString() } };
                var projects = manager.GetObjects<Project>(parameters);
                var pjt = projects.Find(m => m.Id == documentId);
                resultModel.operation = pjt.Name;
                if (pjt == null)
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.DocumentNotFound;
                    return resultModel;
                }
                bool parentActive = projects.Find(m => m.Id == pjt.Parent.Id).Status == ProjectStatus.Active;
                var grandParent = projects.Find(m => m.Id == pjt.Parent.Id).Parent.Id;
                bool grandParentActive = projects.Find(m => m.Id == grandParent).Status == ProjectStatus.Active;
                var rootParent = projects.Find(m => m.Id == grandParent).Parent.Id;
                bool rootParentActive = projects.Find(m => m.Id == rootParent).Status == ProjectStatus.Active;
                if (ispermDelete && (pjt.Status != ProjectStatus.Active || !parentActive || !grandParentActive || !rootParentActive))
                {
                    TMFLogger.LogInformation("PERMANENT DELETE:");
                    int testProjectId = 0;
                    try
                    {
                        var module = projects.Find(m => m.Id == pjt.Parent.Id);
                        var version = projects.Find(m => m.Id == module.Parent.Id);
                        var product = projects.Find(m => m.Id == version.Parent.Id);
                        TMFLogger.LogInformation("PRODUCT: " + product + " VERSION: " + version + " MODULE: " + module);

                        TestProject tProject = tLink.GetProject(product.Name);
                        testProjectId = tProject.id;
                        var ts = tLink.GetFirstLevelTestSuitesForTestProject(testProjectId);
                        int versionTSId = ts.Find(m => m.name == version.Name).id;
                        var moduleTSlist = tLink.GetTestSuitesForTestSuiteNew(versionTSId);
                        var moduleTS = moduleTSlist.Find(m => m.Name == module.Name);
                        var docList = tLink.GetTestSuitesForTestSuiteNew(moduleTS.Id);
                        var docTL = docList.Find(m => m.Name == pjt.Name);
                        if (docTL != null)
                        {
                            TLRepository tlrepo = new TLRepository();
                            TMFLogger.LogInformation("TO DELETE: " + pjt.Description);
                            DeleteF2TBackups(pjt.Description);
                            TMFLogger.LogInformation("F2T FILES DELETED");
                            var res = tlrepo.DeleteDocument(docTL.Id.ToString());
                            if (res)
                            {
                                manager.DeleteObject<Project>(documentId.ToString());
                                resultModel.status = true;
                                resultModel.message = Resources.Resource.RemoveDocumentSuccess;
                            }
                        }
                        else
                        {
                            resultModel.status = false;
                            resultModel.message = "Document not found.";
                        }
                    }
                    catch (Exception ex)
                    {
                        TMFLogger.LogException(ex);
                    }
                }
                else
                {
                    RMRepository rmRepo = new RMRepository();
                    resultModel.status = rmRepo.DeleteProject(documentId);
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            TMFLogger.LogMethodExit();

            return resultModel;
        }

        /// <summary>
        /// Method to restore mapping between document and module
        /// </summary>
        /// <param name="documentId">Unique id of the document</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isPermanentDelete">flag for isPermanentDelete</param>
        /// <returns>Returns the restore status</returns>
        /// 2019/03/12, Sharon Thankachan, VJP192_Modification for restore doc
        public GeneralResultModel RestoreDocument(int documentId, string token, bool isPermanentDelete = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            string apiKey = string.Empty;
            try
            {
                Project project = new Project();
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.ID, documentId.ToString() } };
                var projects = manager.GetObjects<Project>(parameters);
                var pjt = projects.Find(m => m.Id == documentId);
                if (pjt == null)
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.DocumentNotFound;
                    return resultModel;
                }
                RMRepository rmRepo = new RMRepository();
                resultModel.status = rmRepo.RestoreProject(documentId);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return resultModel;
        }

        /// <summary>
        /// Method to replace document
        /// </summary>
        /// <param name="moduleId">Unique id of the module</param>
        /// <param name="docPath">Document path to map</param>
        /// <param name="productName"></param>
        /// <param name="versionName"></param>
        /// <param name="moduleName"></param>
        /// <param name="file">replace document</param>
        /// <returns>Returns the document mapping status</returns>
        /// 2019/08/06, Vinoth N, WG3736_Initial version
        public GeneralResultModel ReplaceDocument(string productName, string versionName, string moduleName, int moduleId, string docPath, HttpPostedFileBase file)
        {
            GeneralResultModel result = new GeneralResultModel();
            result.message = Resources.Resource.ReplaceDocumentFaild;
            var dirPath = ConfigurationManager.AppSettings["F2TDocPath"].ToString();
            if (!Directory.Exists(Path.Combine(dirPath, productName)))
            {
                Directory.CreateDirectory(Path.Combine(dirPath, productName));
            }
            if (!Directory.Exists(Path.Combine(dirPath, productName, versionName)))
            {
                Directory.CreateDirectory(Path.Combine(dirPath, productName, versionName));
            }
            if (!Directory.Exists(Path.Combine(dirPath, productName, versionName, moduleName)))
            {
                Directory.CreateDirectory(Path.Combine(dirPath, productName, versionName, moduleName));
            }
            var docName = file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1);
            docPath = Path.Combine(dirPath, productName, versionName, moduleName, docName);
            if (System.IO.File.Exists(docPath))
            {
                try
                {
                    string fileName = docPath.Trim();
                    var documentPath = fileName.Substring(fileName.LastIndexOf('\\') + 1);
                    documentPath = documentPath.Remove(documentPath.LastIndexOf('.'));
                    string backupFileName = fileName.Remove(fileName.LastIndexOf('.')) + "_Backup" + DateTime.Now.ToString("yyyyMMddHHmmssFFF") + fileName.Substring(fileName.LastIndexOf('.'));
                    System.IO.File.Copy(docPath, backupFileName, true);
                    System.IO.File.Delete(docPath);
                    file.SaveAs(docPath);
                    result.status = true;
                    result.message = Resources.Resource.ReplaceDocumentSuccess;
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                    result.status = false;
                    result.message = Resources.Resource.DocumentBusy;
                }
            }
            return result;
        }

        /// <summary>
        /// Method to add members to product/version/module
        /// </summary>
        /// <param name="id">Unique id</param>
        /// <param name="members">Members to be added</param>
        /// <param name="token">Logged in user token</param>
        /// <returns>Returns add member status</returns>
        /// 2019/01/30, Sujith A, VJP12_Initial version
        /// 2021/02/19, Vinoth N, DMG213_Modification for send mail 
        public GeneralResultModel AddMembers(int id, List<UserModel> members, string type, string token)
        {
            GeneralResultModel model = new GeneralResultModel();
            try
            {
                /* DMG213 mod START Modification for send mail*/
                RMRepository rmRepo = new RMRepository();
                var existingMembers = rmRepo.GetMembers(id);
                RMUserRepository rmuserRepo = new RMUserRepository();
                rmuserRepo.DeleteMembers(id);
                if (members != null)
                {
                    members = members.Distinct().ToList();
                    List<string> userIDs = new List<string>();
                    foreach (var user in members)
                    {
                        if (!string.IsNullOrEmpty(user.Role))
                        {
                            rmuserRepo.AddMemberToProject(user.Id, id, user.Role);
                            if (!existingMembers.Exists(x => x.Id == user.Id))
                                userIDs.Add(user.Id.ToString());
                        }
                    }
                    if (userIDs.Count > 0)
                    { 
                        int typeID = 0;
                        var result = rmRepo.GetAncestorByProjectID(id);
                        switch (type)
                        {
                            case "product":
                                typeID = 1;
                                break;
                            case "version":
                                typeID = 2;
                                break;
                            case "module":
                                typeID = 3;
                                break;
                            default:
                                typeID = 0;
                                break;
                        }
                        SendProductNotification(typeID, userIDs, result["CHILD"]);
                    }
                }
                else
                {
                    if(type == "product")
                    {
                        var usr = rmRepo.GetDefaultUser();
                        rmuserRepo.AddMemberToProject(usr.Id, id, usr.Role);
                    }
                }
                /* DMG213 mod END Modification for send mail*/
                model.status = true;
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                model.message = Resources.Resource.UpdateMemberFaild;
            }

            return model;
        }

        /// <summary>
        /// Method to retrieve all members in the project
        /// </summary>
        /// <param name="id">Unique id of the project</param>
        /// <param name="token">User token</param>
        /// <param name="isTCId">Is test case id</param>
        /// <returns>Returns users</returns>
        /// 2019/02/26, Sujith, VJP192_Initial Version
        public List<UserModel> GetAllProjectMembers(int projectId, string token, bool isTCId = false)
        {
            List<UserModel> users = new List<UserModel>();
            string apiKey = "";
            RMRepository repo = new RMRepository();
            var proxy = ConnectTestLink(token, out apiKey);
            string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
            var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
            var parameters = new NameValueCollection { { RedmineKeys.PROJECT, RedmineKeys.ALL } };
            TLRepository tlRepo = new TLRepository();
            string productName = "";
            string versionName = "";
            string moduleName = "";
            tlRepo.GetParents(projectId, isTCId, ref productName, ref versionName, ref moduleName);
            var pjts = repo.GetAllProjects();
            var pjt = pjts.Find(m => m.Name.ToLower() == productName.ToLower() && m.Status == (int)ProjectStatus.Active && m.Parent == 0);
            if (pjt != null)
            {
                users = ConvertToModel(repo.GetMembers(pjt.Id));
                var version = pjts.Find(m => m.Name.ToLower() == versionName.ToLower() && m.Status == (int)ProjectStatus.Active
                                            && m.Parent > 0 && m.Parent == pjt.Id);
                if (version != null)
                {
                    users = users.Union(ConvertToModel(repo.GetMembers(version.Id))).ToList();
                    var module = pjts.Find(m => m.Name.ToLower() == moduleName.ToLower() && m.Status == (int)ProjectStatus.Active
                                            && m.Parent > 0 && m.Parent == version.Id);
                    if (module != null)
                    {
                        users = users.Union(ConvertToModel(repo.GetMembers(module.Id))).ToList();
                    }
                }

            }

            return users;
        }

        /// <summary>
        /// Method to retrieve all members in the project
        /// </summary>
        /// <param name="id">Unique id of the project</param>
        /// <param name="token">User token</param>
        /// <param name="isBugId">Is bug id</param>
        /// <returns>Returns users</returns>
        /// 2019/02/26, Sujith, VJP192_Initial Version
        public List<UserModel> GetAllBugProjectMembers(int id, string token, bool isBugId = false)
        {
            List<UserModel> users = new List<UserModel>();
            string apiKey = "";
            var proxy = ConnectTestLink(token, out apiKey);
            string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
            var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
            var parameters = new NameValueCollection { { RedmineKeys.PROJECT, RedmineKeys.ALL } };
            var pjts = manager.GetObjects<Project>(parameters);
            if (isBugId)
            {
                Issue issue = manager.GetObject<Issue>(id.ToString(), new NameValueCollection { });
                if (issue.Project != null)
                {
                    var doc = pjts.Find(m => m.Id == issue.Project.Id);
                    if (doc != null && doc.Parent != null)
                    {
                        var module = pjts.Find(m => m.Id == doc.Parent.Id);
                        id = module != null ? module.Id : 0;
                        /* 2019/05/21_WJ3736_bug fix starts */
                        if (module != null && module.Parent != null)
                        {
                            var version = pjts.Find(m => m.Id == module.Parent.Id);
                            int verId = version != null ? version.Id : 0;
                            if (version != null && version.Parent == null)
                            {
                                id = issue.Project.Id;
                            }
                        }
                        /* 2019/05/21_WJ3736_bug fix ends*/
                    }
                }
            }
            var pjt = pjts.Find(m => m.Id == id && m.Status == ProjectStatus.Active);
            if (pjt != null)
            {
                RMRepository repo = new RMRepository();
                users = ConvertToModel(repo.GetMembers(pjt.Id));
                if (pjt.Parent != null)
                {
                    var version = pjts.Find(m => m.Id == pjt.Parent.Id && m.Status == ProjectStatus.Active);
                    if (version != null)
                    {
                        users = users.Union(ConvertToModel(repo.GetMembers(version.Id))).ToList();
                        if (version.Parent != null)
                        {
                            var product = pjts.Find(m => m.Id == version.Parent.Id && m.Status == ProjectStatus.Active);
                            if (product != null)
                            {
                                users = users.Union(ConvertToModel(repo.GetMembers(product.Id))).ToList();
                            }
                        }
                    }
                }
            }

            return users;
        }

        /// <summary>
        /// Method to retrieve members in the project
        /// </summary>
        /// <param name="token">User token</param>
        /// <param name="productName">Name of the product</param>
        /// <param name="versionName">Name of the version</param>
        /// <param name="userName">user Name</param>
        /// <returns>Returns member names</returns>
        /// 2019/02/21, Sujith, VJP192-Initial version
        public List<ModuleModel> GetMemberProjectList(string token, string productName, string versionName, string userName)
        {
            List<ModuleModel> modules = new List<ModuleModel>();
            RMRepository repo = new RMRepository();
            DataTable pjtList = repo.GetMemberProjectList(productName, versionName, userName);
            var result = pjtList.AsEnumerable()
                           .GroupBy(row => new
                           {
                               ID = row.Field<int>("id"),
                               ModuleName = row.Field<string>("modName")
                           });
            foreach (var group in result)
            {
                List<DocumentModel> docList = new List<DocumentModel>();
                foreach (DataRow dr in group)
                {
                    if (dr["docName"] != DBNull.Value)
                    {
                        docList.Add(new DocumentModel() { Name = dr["docName"].ToString() });
                    }
                }
                modules.Add(new ModuleModel() { Id = group.Key.ID, ModuleName = group.Key.ModuleName, DocModels = docList });
            }
            return modules;
        }

        /// <summary>
        /// Method to restore deleted product
        /// </summary>
        /// <param name="productId">Unique id of the product</param>
        /// <param name="token">Logged in user token</param>
        /// <param name="isPermanentDelete">is Permanent Delete permission</param>
        /// <returns>Returns restore status</returns>
        /// 2019/03/12, Sharon Thankachan, VJP192_Modification for restore pdt
        public GeneralResultModel RestoreProduct(int productId, string token, bool isPermanentDelete = false)
        {
            GeneralResultModel resultModel = new GeneralResultModel();
            string apiKey = string.Empty;
            try
            {
                var tLink = ConnectTestLink(token, out apiKey);
                Project project = new Project();
                string rmAPIPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_REDMINE_API_PATH];
                var manager = new Redmine.Net.Api.RedmineManager(rmAPIPath, apiKey);
                var parameters = new NameValueCollection { { RedmineKeys.ID, productId.ToString() } };
                var projects = manager.GetObjects<Project>(parameters);
                var pjt = projects.Find(m => m.Id == productId);
                if (pjt == null || !isPermanentDelete)
                {
                    resultModel.status = false;
                    resultModel.message = Resources.Resource.ProductNotFound;
                    return resultModel;
                }
                RMRepository rmRepo = new RMRepository();
                resultModel.status = rmRepo.RestoreProject(productId);
            }
            catch (Exception ex)
            {
                resultModel.status = false;
                resultModel.message = Resources.Resource.RestoreProductFaild;
                TMFLogger.LogException(ex);
            }

            return resultModel;
        }

        /// <summary>
        /// Method to save Map Script
        /// </summary>
        /// <param name="projectId">Unique id of project</param>
        /// <param name="mapScript">Map Script Json</param>
        /// <returns>Return update status</returns>
        /// 2020/10/23, Vinoth N, CRC207_Initial version
        public GeneralResultModel SaveTasScriptDetail(StringBuilder mapScript, int projectId)
        {
            GeneralResultModel generalResult = new GeneralResultModel();
            TLRepository repo = new TLRepository();
            var status = repo.UpdateMapScript(projectId, mapScript);
            generalResult.status = status;
            if (status)
                generalResult.message = Resources.Resource.SavedSuccessfully;
            else
                generalResult.message = Resources.Resource.Failed;

            return generalResult;
        }

        /// <summary>
        /// Method to get MapScript
        /// </summary>
        /// <param name="projectId">Unique id of project</param>
        /// <returns>Return map script</returns>
        /// 2020/10/23, Vinoth N, CRC207_Initial version
        public StringBuilder GetTasScriptDetail(int projectId)
        {
            TLRepository repo = new TLRepository();
            StringBuilder result = new StringBuilder();
            result = repo.GetMapScript(projectId);
            return result;
        }

        /// <summary>
        /// Get all modules.
        /// </summary>
        /// <param name="productName"></param>
        /// <param name="versionName"></param>
        /// <returns></returns>
        public List<BaseData> GetModuleFromProductVersionName(string productName, string versionName)
        {
            TLRepository tlRepo = new TLRepository();
            return tlRepo.GetModuleFromProductVersionName(productName, versionName);
        }

        /// <summary>
        /// Sends mail to the assigned user
        /// </summary>
        /// <param name="userIds">User id of assigned user</param>
        /// <param name="typeId">typeId</param
        /// <param name="productName">name</param
        /// 2021/02/17, Vinoth N, DMG213_Initial Version
        public void SendProductNotification(int typeId, List<string> userIds, string productName)
        {
            var subject = "TMF - Product Assigned";
            try
            {
                AccountManager manager = new AccountManager();
                IAdministrationManager adminManager = new AdministrationManager();
                ConfigurationModel configModel = new ConfigurationModel();
                configModel = adminManager.GetConfigurationData();
                EmailManager emailManager = new EmailManager();
                if (configModel.EmailConfiguration.UseSMTP)
                {
                    foreach (var id in userIds)
                    {
                        string mailAddress = manager.GetUserProfile(id, out string userName, out string language);
                        if (mailAddress != string.Empty)
                        {
                            emailManager.SendMail(mailAddress, subject, GenerateMailContent(typeId, productName, userName, language), String.Empty, true, false);
                        }
                    }
                }
                else
                {
                    string mailAddress = string.Empty;
                    foreach (var id in userIds)
                    {
                        mailAddress += manager.GetUserProfile(id, out string userName, out string language) + ";";
                    }
                    emailManager.SendMailWithPowerAutomate(mailAddress, EmailCategory.ProductAssigned, GenerateMailContent(typeId, productName, "User", "en"));
                }
            }
            catch (Exception ex)
            {
                TMF.Logger.TMFLogger.LogError(ex.ToString());
            }
        }

        /// <summary>
        /// Generate mail content
        /// </summary>
        /// <param name="inputMail">product details</param>
        /// 2021/02/18, Vinoth N, DMG213_Initial Version
        public void SendGroupNotification(MailGroupModel inputMail)
        {
            var subject = "TMF - Product Assigned";
            var body = String.Empty;
            var mailId = inputMail.UserId;
            var tdContent = @"<td style='border: 1px solid black;'>{0}</td>";
            var bgContent = @"<td style='border: 1px solid black;background: yellow;'>{0}</td>";
            try
            {
                if (inputMail.ProductData.Count > 0)
                {
                    var products = inputMail.ProductData.Select(p => p.ProductName).ToList();
                    products = products.Distinct().ToList();
                    foreach (var product in products)
                    {
                        var productDetail = inputMail.ProductData.Where(q => q.ProductName == product).ToList();
                        foreach (var data in productDetail)
                        {
                            var initialTR = @"<tr>{product}{version}{module}</tr>";
                            var Content = tdContent;
                            if (String.IsNullOrEmpty(data.ProductName))
                                Content = Content.Replace("{0}", "");
                            else
                            {
                                if (String.IsNullOrEmpty(data.VersionName))
                                    Content = bgContent;
                                Content = Content.Replace("{0}", data.ProductName);
                            }
                            initialTR = initialTR.Replace("{product}", Content);

                            Content = tdContent;
                            if (String.IsNullOrEmpty(data.VersionName))
                                Content = Content.Replace("{0}", "");
                            else
                            {
                                if (String.IsNullOrEmpty(data.ModuleName))
                                    Content = bgContent;
                                Content = Content.Replace("{0}", data.VersionName);
                            }
                            initialTR = initialTR.Replace("{version}", Content);

                            Content = tdContent;
                            if (String.IsNullOrEmpty(data.ModuleName))
                                Content = Content.Replace("{0}", "");
                            else
                            {
                                Content = bgContent;
                                Content = Content.Replace("{0}", data.ModuleName);
                            }
                            initialTR = initialTR.Replace("{module}", Content);

                            body += initialTR;
                        }
                    }
                }
                AccountManager manager = new AccountManager();
                string mailAddress = manager.GetUserProfile(inputMail.UserId, out string userName, out string language);
                if (mailAddress != string.Empty)
                {
                    IAdministrationManager adminManager = new AdministrationManager();
                    ConfigurationModel configModel = new ConfigurationModel();
                    configModel = adminManager.GetConfigurationData();
                    EmailManager emailManager = new EmailManager();
                    if (configModel.EmailConfiguration.UseSMTP)
                    {
                        emailManager.SendMail(mailAddress, subject, GenerateGroupContent(body, userName, language), String.Empty, true, false);
                    }
                    else
                    {
                        emailManager.SendMailWithPowerAutomate(mailAddress, EmailCategory.ProductAssigned, GenerateGroupContent(body, "User", "en"));
                    }
                }
            }
            catch (Exception ex)
            {
                TMF.Logger.TMFLogger.LogError(ex.ToString());
            }
        }

        /// <summary>
        /// Sends mail to the assigned user
        /// </summary>
        /// <param name="userIds">User id of assigned user</param>
        /// <param name="path">location</param
        /// <param name="typeId">type Id</param
        /// 2021/02/18, Vinoth N, DMG213_Initial Version
        public void SendMailReport(string userId, string path, int typeId)
        {
            var subject = "TMF - Report and Charts";
            var body = @"{product}{version}{module}";
            try
            {
                AccountManager manager = new AccountManager();
                string mailAddress = manager.GetUserProfile(userId, out string userName, out string language);
                if (mailAddress != string.Empty)
                {
                    IAdministrationManager adminManager = new AdministrationManager();
                    ConfigurationModel configModel = new ConfigurationModel();
                    configModel = adminManager.GetConfigurationData();
                    EmailManager emailManager = new EmailManager();
                    if (configModel.EmailConfiguration.UseSMTP)
                    {
                        emailManager.SendMail(mailAddress, subject, GenerateChartContent(body, userName, language, typeId), path, true, true);
                    }
                    else
                    {
                        emailManager.SendMailWithPowerAutomate(mailAddress, EmailCategory.ReportsAndCharts, path, true);
                    }
                }
            }
            catch (Exception ex)
            {
                TMF.Logger.TMFLogger.LogError(ex.ToString());
            }
        }

        /// <summary>
        /// Method to save build settings
        /// </summary>
        /// <param name="buildSettings">Build settings input.</param
        /// <param name="token">Token.</param>
        /// <returns>Returns status</returns>
        /// 2021/06/16, Vinoth N, EL5873_Initial Version
        public GeneralResultModel SaveBuildSettings(BuildSettingsModel buildSettings, string token)
        {
            bool status;
            GeneralResultModel generalResult = new GeneralResultModel();
            RMRepository repo = new RMRepository();
            if(buildSettings.Id > 0)
                status = repo.UpdateBuildSettings(ModelMapper.Map(buildSettings));
            else
                status = repo.CreateBuildSettings(ModelMapper.Map(buildSettings));
            generalResult.status = status;
            if (status)
            {
                if (buildSettings.IsBuildable)
                    generalResult = BuildTASProject(buildSettings, token);
                if (generalResult.status)
                    generalResult.message = Resources.Resource.SavedSuccessfully;
                else
                    generalResult.message = "Failed.";
            }
            else
                generalResult.message = Resources.Resource.Failed;
            return generalResult;
        }

        /// <summary>
        /// Method to get build settings
        /// </summary>
        /// <param name="productId">Product Id.</param>
        /// <param name="versionId">Version Id.</param>
        /// <returns>Returns build settings.</returns>
        /// 2021/06/17, Vinoth N, EL5873_Initial Version
        public BuildSettingsModel GetBuildSettings(int productId, int versionId)
        {
            RMRepository repo = new RMRepository();
            ITestCaseManager testCase = new TestCaseManager();
            BuildSettingsModel settings = new BuildSettingsModel();
            var output = repo.GetBuildSettings(productId, versionId);
            if (output != null)
            {
                settings = ModelMapper.Map(output);
                settings.Modules = GetVersionModules(productId, versionId);
                settings.Machines = testCase.GetAllMachines();
            }
            return settings;
        }

        /// <summary>
        /// Method to save path settings
        /// </summary>
        /// <param name="pathSettings">Path settings input.</param>
        /// <returns>Returns status</returns>
        /// 2021/06/18, Vinoth N, EL5873_Initial Version
        public GeneralResultModel SavePathConfiguration(PathSettingsModel pathSettings)
        {
            bool status;
            GeneralResultModel generalResult = new GeneralResultModel();
            RMRepository repo = new RMRepository();
            if (pathSettings.Id > 0)
                status = repo.UpdatePathSettings(ModelMapper.Map(pathSettings));
            else
                status = repo.CreatePathSettings(ModelMapper.Map(pathSettings));
            generalResult.status = status;
            if (status)
                generalResult.message = Resources.Resource.SavedSuccessfully;
            else
                generalResult.message = Resources.Resource.Failed;
            return generalResult;
        }

        /// <summary>
        /// Method to get path settings
        /// </summary>
        /// <param name="Id">Settings Id.</param>
        /// <returns>Returns path settings.</returns>
        /// 2021/06/18, Vinoth N, EL5873_Initial Version
        public PathSettingsModel GetPathConfiguration(int Id)
        {
            RMRepository repo = new RMRepository();
            PathSettingsModel settings = new PathSettingsModel();
            var output = repo.GetPathSettings(Id);
            if (output != null)
                settings = ModelMapper.Map(output);
            return settings;
        }

        /// <summary>
        /// Method to get version path settings
        /// </summary>
        /// <param name="versionId">Version Id.</param>
        /// <returns>Returns path settings.</returns>
        /// 2021/06/18, Vinoth N, EL5873_Initial Version
        public List<PathSettingsModel> GetVersionPathSettings(int versionId)
        {
            bool status;
            GeneralResultModel generalResult = new GeneralResultModel();
            RMRepository repo = new RMRepository();
            return new List<PathSettingsModel>();
        }

        /// <summary>
        /// Method to bild TAS project
        /// </summary>
        /// <param name="buildSettings">Build settings input.</param>
        /// <param name="token">Token.</param>
        /// <returns>Returns status.</returns>
        /// 2021/06/18, Vinoth N, EL5873_Initial Version
        private GeneralResultModel BuildTASProject(BuildSettingsModel buildSettings, string token)
        {
            ITestCaseManager manager = new TestCaseManager();
            bool status;
            GeneralResultModel generalResult = new GeneralResultModel();
            RMRepository repo = new RMRepository();
            if (pathSettings.Id > 0)
                status = repo.UpdatePathSettings(ModelMapper.Map(pathSettings));
            else
                status = repo.CreatePathSettings(ModelMapper.Map(pathSettings));
            generalResult.status = status;
            if (status)
                generalResult.message = Resources.Resource.SavedSuccessfully;
            else
                generalResult.message = Resources.Resource.Failed;
            GeneralResultModel result = manager.BuildTASProject(buildSettings, token);
            return result;
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Creates content of the email
        /// </summary>
        /// <param name="typeId">Ids of the bug</param>
        /// <param name="productName">name of the bug</param>
        /// <param name="name">User Fullname</param>
        /// <param name="language">User Name</param>
        /// <returns>Mail content</returns>
        /// 2021/02/18, Vinoth N, DMG213_Initial Version
        private string GenerateMailContent(int typeId, string productName, string name, string language)
        {
            string message = AdministrationManager.CustomResource(language, "MailProductCreation");
            switch (typeId)
            {
                case 1:
                    message = message.Replace("{type}", AdministrationManager.CustomResource(language, "Product"));
                    break;
                case 2:
                    message = message.Replace("{type}", AdministrationManager.CustomResource(language, "Version"));
                    break;
                case 3:
                    message = message.Replace("{type}", AdministrationManager.CustomResource(language, "Module"));
                    break;
                default:
                    break;
            }
            StringBuilder content = new StringBuilder();
            message = message.Replace("{fullName}", name);
            message = message.Replace("{signature}", AdministrationManager.CustomResource(language, "MailSignature"));
            message = message.Replace("{content}", @"<span><b>" + productName + "</b></span>");
            return message;
        }

        /// <summary>
        /// Creates mail group content 
        /// </summary>
        /// <param name="body">content body</param>
        /// <param name="name">User Fullname</param>
        /// <param name="language">User Name</param>
        /// <returns>Mail content</returns>
        /// 2021/02/18, Vinoth N, DMG213_Initial Version
        private string GenerateGroupContent(string body, string name, string language)
        {
            string message = AdministrationManager.CustomResource(language, "MailGroupCreation");
            StringBuilder content = new StringBuilder();
            message = message.Replace("{fullName}", name);
            message = message.Replace("{signature}", AdministrationManager.CustomResource(language, "MailSignature"));
            message = message.Replace("{content}", body);
            return message;
        }

        /// <summary>
        /// Creates charts and report content 
        /// </summary>
        /// <param name="body">content body</param>
        /// <param name="name">User Fullname</param>
        /// <param name="language">User Name</param>
        /// <param name="type">report type id</param>
        /// <returns>Mail content</returns>
        /// 2021/02/19, Vinoth N, DMG213_Initial Version
        private string GenerateChartContent(string body, string name, string language, int type)
        {
            string message = type == 1 ? AdministrationManager.CustomResource(language, "MailReportEXCEL") : AdministrationManager.CustomResource(language, "MailReportPDF");
            StringBuilder content = new StringBuilder();
            message = message.Replace("{fullName}", name);
            message = message.Replace("{signature}", AdministrationManager.CustomResource(language, "MailSignature"));
            return message;
        }

        /// <summary>
        /// Method to connect to testlink
        /// </summary>
        /// <param name="token">Logged in user token</param>
        /// <param name="apikey">Api key of the logged in user</param>
        /// <returns>Returns testlink object</returns>
        private TestLink ConnectTestLink(string token, out string apikey)
        {
            RMUserRepository repo = new RMUserRepository();
            string login = repo.GetLogin(token);
            string apiPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_TESTLINK_API_PATH];
            TLUserRepository tlrepo = new TLUserRepository();
            apikey = tlrepo.GetApiKey(login);
            if (string.IsNullOrEmpty(apikey))
            {
                apikey = tlrepo.GenerateAPIKey(login);
            }
            TestLink proxy = new TestLink(apikey, apiPath);

            return proxy;
        }

        /// <summary>
        /// Method to convert  user to model
        /// </summary>
        /// <param name="users">user object</param>
        /// <returns>Returns users</returns>
        private List<UserModel> ConvertToModel(List<TMF.DAL.Objects.User> users)
        {
            List<UserModel> userModels = new List<UserModel>();
            foreach (var user in users)
            {
                UserModel userModel = new UserModel
                {
                    Name = user.Login,
                    Id = user.Id,
                    ProfileURL = String.Empty
                };

                userModels.Add(userModel);
            }
            return userModels;
        }

        /// <summary>
        /// Method to retrieve version details
        /// </summary>
        /// <param name="pdt">Product details</param>
        /// <param name="pjt">Project details</param>
        /// <param name="pjtIds">List of project ids</param>
        /// <returns>Returns status</returns>
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        /// 2020/05/15, Vinoth N, C51165_Modification for get version members
        /// 2021/06/11, Vinoth N, EL5873_Modification for build settings
        private bool DoGetVersion(ProductModel pdt, CustomProjectModel pjt, List<int> pjtIds)
        {
            bool status = false;
            if (pjt.Parent == pdt.Id)
            {
                /* EL5873 mod START Modification for build settings */
                VersionModel version = new VersionModel
                {
                    Id = pjt.Id,
                    VersionName = pjt.Name,
                    Description = pjt.Description,
                    IsMember = pjtIds.Contains(pjt.Id) || pdt.IsMember,
                    IsActive = pjt.Status == (int)ProjectStatus.Active ? true : false
                };
                RMRepository repo = new RMRepository();
                /* C51165 mod START Modification for get version members */
                var members = repo.GetMembers(pjt.Id);
                version.MembersCount = members.Count;
                version.Members = ConvertToModel(members);
                /* C51165 mod END Modification for get version members */
                pdt.Versions.Add(version);
                pdt.IsSubMember = pdt.IsSubMember || version.IsMember;
                pdt.VersionCount++;
                return true;
                /* EL5873 mod END Modification for build settings */
            }
            foreach (var ver in pdt.Versions)
            {
                if (DoGetModule(pdt, ver, pjt, pjtIds))
                {
                    status = true;
                    break;
                }
            }
            return status;
        }

        /// <summary>
        /// Method to retrieve module details
        /// </summary>
        /// <param name="pdt">Product details</param>
        /// <param name="ver">Version details</param>
        /// <param name="pjt">Project details</param>
        /// <param name="pjtIds">List of project ids</param>
        /// <returns>Returns status</returns>
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        /// 2020/05/15, Vinoth N, C51165_Modification for get module members
        /// 2021/06/11, Vinoth N, EL5873_Modification for path settings
        private bool DoGetModule(ProductModel pdt, VersionModel ver, CustomProjectModel pjt, List<int> pjtIds)
        {
            bool status = false;
            if (pjt.Parent == ver.Id)
            {
                /* EL5873 mod START Modification for path settings */
                if (!pjtIds.Contains(pjt.Id) && !ver.IsMember && !pdt.IsMember) return true;
                ModuleModel module = new ModuleModel();
                module.Id = pjt.Id;
                module.ModuleName = pjt.Name;
                module.Description = pjt.Description;
                module.IsActive = pjt.Status == (int)ProjectStatus.Active ? ver.IsActive : false;
                module.IsMember = true;
                RMRepository repo = new RMRepository();
                /* C51165 mod START Modification for get module members */
                var members = repo.GetMembers(pjt.Id);
                module.MembersCount = members.Count;
                module.Members = ConvertToModel(members);
                /* C51165 mod END Modification for get module members */
                ver.IsSubMember = true;
                pdt.IsSubMember = true;
                ver.Modules.Add(module);
                ver.ModuleCount++;
                pdt.ModuleCount++;
                status = true;
                /* EL5873 mod END Modification for build settings */
            }
            foreach (var mod in ver.Modules)
            {
                if (pjt.Parent == mod.Id)
                {
                    DocumentModel docModel = new DocumentModel();
                    docModel.Id = pjt.Id;
                    docModel.Name = pjt.Name;
                    docModel.DocumentPath = pjt.Description;
                    docModel.IsActive = pjt.Status == (int)ProjectStatus.Active ? mod.IsActive : false;
                    mod.DocModels.Add(docModel);
                    mod.DocCount++;
                    ver.DocCount++;
                    pdt.DocCount++;
                    status = true;
                }

            }

            return status;
        }

        /// <summary>
        /// Method to update members
        /// </summary>
        /// <param name="id">Unique id of the project</param>
        /// <param name="members">Project members</param>
        /// 2019/02/21, Sujith, VJP192-Initial version
        private void UpdateMembers(int id, List<UserModel> members)
        {
            RMUserRepository rmuserRepo = new RMUserRepository();
            rmuserRepo.DeleteMembers(id);
            List<UserModel> users = new List<UserModel>();
            if (members != null)
            {
                foreach (var mem in members)
                {
                    if (users.Find(m => m.Id == mem.Id) == null)
                    {
                        users.Add(mem);
                    }
                }
                foreach (var user in users)
                {
                    if (!string.IsNullOrEmpty(user.Role))
                        rmuserRepo.AddMemberToProject(user.Id, id, user.Role);
                }
            }
        }

        /// <summary>
        /// Method to validate product
        /// </summary>
        /// <param name="projects">List projects</param>
        /// <param name="productId">Unique id of the product</param>
        /// <param name="productName">Name of the product</param>
        /// <param name="token">token of logged in user</param>
        /// <param name="message">Error message</param>
        /// <returns>Returns status</returns>
        /// 2019/02/21, Sujith, VJP192-Initial version
        private bool ValidateProduct(List<Project> projects, int productId, string productName, string token, ref string message)
        {
            bool status = false;
            if (productId > 0)
            {
                var product = projects.Find(m => m.Id == productId && m.Status == ProjectStatus.Active);
                if (product == null)
                {
                    message += Resources.Resource.ProductNotExist;
                    return status;
                }
            }
            else if (!string.IsNullOrEmpty(productName))
            {
                var productN = projects.Find(m => m.Id != productId && m.Name.ToLower() == productName.ToLower());
                if (productN != null)
                {
                    RMRepository repo = new RMRepository();
                    var pjtIds = repo.GetProjectsofUser(token);
                    if (pjtIds.Contains(productN.Id))
                        message += Resources.Resource.ProductExist;
                    else
                        message += Resources.Resource.ProductAutherization;

                    return status;
                }
            }
            status = true;
            return status;
        }

        /// <summary>
        /// Method to validate version
        /// </summary>
        /// <param name="projects">List of projects</param>
        /// <param name="versionId">Unique id of the version</param>
        /// <param name="versionName">Name of the version</param>
        /// <param name="productId">Unique id of the product</param>
        /// <param name="token">token of logged in user</param>
        /// <param name="message">Error message</param>
        /// <returns>Returns status</returns>
        /// 2019/02/21, Sujith, VJP192-Initial version
        /// 2021/06/14, Vinoth N, EL5873_Modification for path settings
        private bool ValidateVersion(List<Project> projects, int versionId, string versionName, int productId, string token, ref string message)
        {
            bool status = false;
            /* EL5873 mod START Modification for build settings */
            if (ValidateProduct(projects, productId, "", token, ref message))
            {
                if (versionId > 0)
                {
                    var version = projects.Find(m => m.Id == versionId && m.Status == ProjectStatus.Active);
                    if (version == null)
                    {
                        message += Resources.Resource.VersionNotExist;
                        return status;
                    }
                }
                if (!string.IsNullOrEmpty(versionName))
                {
                    var version = projects.Find(m => m.Id != versionId && m.Name.ToLower() == versionName.ToLower() && m.Parent != null && m.Parent.Id == productId);
                    if (version != null)
                    {
                        RMRepository repo = new RMRepository();
                        var pjtIds = repo.GetProjectsofUser(token);
                        if (pjtIds.Contains(productId))
                            message += Resources.Resource.VersionExist;
                        else
                            message += Resources.Resource.VersionAutherization;
                        return status;
                    }
                }
                status = true;
                /* EL5873 mod END Modification for build settings */
            }

            return status;
        }

        /// <summary>
        /// Method to validate module
        /// </summary>
        /// <param name="projects">List of projects</param>
        /// <param name="moduleId">Unique id of the module</param>
        /// <param name="moduleName">Name of the module</param>
        /// <param name="versionId">Unique id of the version</param>
        /// <param name="productId">Unique id of the product</param>
        /// <param name="token">token of logged in user</param>
        /// <param name="message">Error message</param>
        /// <returns>Returns status</returns>
        /// 2019/02/21, Sujith, VJP192-Initial version
        /// 2021/06/14, Vinoth N, EL5873_Modification for path settings
        private bool ValidateModule(List<Project> projects, int moduleId, string moduleName,
            int versionId, int productId, string token, ref string message)
        {
            bool status = false;
            /* EL5873 mod START Modification for build settings */
            if (ValidateVersion(projects, versionId, "", productId, token, ref message))
            {
                if (moduleId > 0)
                {
                    var module = projects.Find(m => m.Id == moduleId && m.Status == ProjectStatus.Active);
                    if (module == null)
                    {
                        message += Resources.Resource.ModuleNotExist;
                        return status;
                    }
                }
                if (!string.IsNullOrEmpty(moduleName))
                {
                    var module = projects.Find(m => m.Id != moduleId && m.Name.ToLower() == moduleName.ToLower() && m.Parent != null && m.Parent.Id == versionId);
                    if (module != null)
                    {
                        RMRepository repo = new RMRepository();
                        var pjtIds = repo.GetProjectsofUser(token);
                        if (pjtIds.Contains(versionId))
                            message += Resources.Resource.ModuleExist;
                        else
                            message += Resources.Resource.ModuleAutherization;
                        return status;
                    }
                }
                status = true;
                /* EL5873 mod END Modification for build settings */
            }

            return status;
        }

        /// <summary>
        /// Method to remove f2t folder
        /// </summary>
        /// <param name="path">path name</param>
        /// <returns>Returns status</returns>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        private bool DeleteF2TFolder(string path)
        {
            bool isSuccess = true;
            try
            {
                if (Directory.Exists(path))
                {
                    System.IO.Directory.Delete(path, true);
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                isSuccess = false;
            }
            return isSuccess;
        }

        /// <summary>
        /// Method to delete all the backups in the document
        /// </summary>
        /// <param name="path">path name</param>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        private void DeleteF2TBackups(string path)
        {
            if (File.Exists(path))
            {
                try
                {
                    var fileName = Path.GetFileNameWithoutExtension(path) + "_Backup";
                    var rootPath = Path.GetDirectoryName(path);
                    DirectoryInfo d = new DirectoryInfo(rootPath);
                    FileInfo[] Files = d.GetFiles().Where(p => Path.GetFileNameWithoutExtension(p.Name).Contains(fileName)).ToArray();
                    foreach (FileInfo file in Files)
                    {
                        File.Delete(file.FullName);
                    }
                    File.Delete(path);
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                }
            }
        }

        /// <summary>
        /// Method to get all modules in version
        /// </summary>
        /// <param name="productId">Product name.</param>
        /// <param name="versionId">Version name.</param>
        /// <returns>Returns Module list.</returns>
        /// 2021/06/17, Vinoth N, EL5873_Initial Version
        private List<ModuleDataModel> GetVersionModules(int productId, int versionId)
        {
            RMRepository repo = new RMRepository();
            List<ModuleDataModel> modules = new List<ModuleDataModel>();
            var output = repo.GetModules(productId, versionId).ToList();
            if (output != null)
                modules = output.GroupBy(x => x.Id).Select(y => y.First()).ToList();
            return modules;
        }
        #endregion
    }
}
#endregion
