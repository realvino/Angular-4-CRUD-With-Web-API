﻿#region File Header
// ---------------------------------------------------------------------------------------
// Copyright (C) Hitachi High-Tech Corporation, 2018-2021. All rights reserved.
// File Name    : TestCaseManager.cs
// Description  : Holds test case operations.
// Date         |    Author             |       Description
// ---------------------------------------------------------------------------------------
// 2018/01/17   |   Sujith A            |       Created
// 2018/10/17   |   Praveen M P         |       Modification for Create and scheduling jobs
// 2019/01/11   |   Sharon Thankachan   |       VJP192_Modification for automated run of TCs
// 2019/01/17   |   Sharon Thankachan   |       VJP192_Modification for attach multiple bugs in TC
// 2019/01/25   |   Sharon Thankachan   |       VJP192_Modification for Email Notification
// 2019/01/31   |   Sharon Thankachan   |       VJP192_Modification for scheduling job
// 2019/05/09   |   Sharon Thankachan   |       WG3736_Modification for map TC
// 2019/06/06   |   Vinoth N            |       WG3736_ Modification for Test Management
// 2019/06/26   |   Sharon Thankachan   |       WG3736_ Modification for Charts and reports
// 2020/01/08   |   Vinoth N            |       B1K017_Modification for removing Unicodes
// 2020/06/19   |   Vinoth N            |       C51165_Modification for recently assigned test cases
// 2020/10/23   |   Vinoth N            |       CRC207_Modification for delete individual test result 
// 2021/02/16   |   Sharon Thankachan   |       DMG213_Modification for Power Automate 
// 2021/06/14   |   Vinoth N            |       EL5873_Modification for build and path settings
// --------------------------------------------------------------------------------------- 
#endregion

#region Using
using HHT.TAS.AutoStartService;
using JenkinsNET;
using JenkinsNET.Exceptions;
using JenkinsNET.Models;
using Meyn.TestLink;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Web.Hosting;
using System.Xml;
using System.Xml.Linq;
using TMF.Common;
using TMF.DAL;
using TMF.DAL.Objects;
using TMF.DocumentHandler;
using TMF.Logger;
using TMF.ViewModels;
#endregion

#region NameSpace
namespace TMF.Business
{
    #region Class
    public class TestCaseManager : ITestCaseManager
    {
        #region Public Methods     
        /// <summary>
        /// Method to get tcmid and test plan
        /// </summary>
        /// <param name="tcmid"></param>
        /// <param name="testsuiteid"></param>
        /// <param name="testplanname"></param>
        /// <param name="testProject"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public string[] GetTcIdAndTestPlan(int tcmid, int testsuiteid, string testplanname, string testProject, string token)
        {
            string[] arr = new string[2];
            int tcid = 0;
            var tLProjectRepository = new TLRepository();
            try
            {
                TestPlan plan = ConnectTestLink(token).getTestPlanByName(testProject, testplanname);
                arr[0] = plan.id.ToString();
                tLProjectRepository.GetTestcaseIdByTCMID(Convert.ToInt32(tcmid), testsuiteid, ref tcid);
                arr[1] = tcid.ToString();
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return arr;
        }


        /// <summary>
        /// Get list of test case for mapping
        /// </summary>
        /// <param name="testSuiteID">test suite id</param>
        /// <param name="operation">operation type</param>
        /// <param name="section">section value</param>
        /// <returns>list if tc</returns>
        /// 2019/05/09, Sharon Thankachan, WG3736_Modification for Map TC
        public List<TestCaseDetailModel> GetTestcasesInDocument(int testSuiteID, string operation, string section)
        {
            List<TestCaseDetailModel> arr = new List<TestCaseDetailModel>();
            var tLProjectRepository = new TLRepository();
            try
            {
                List<DAL.Objects.TestCase> testCases = tLProjectRepository.GetTestcasesInDocument(section, testSuiteID, operation);
                /* WG3736 mod START Modification for Map TC*/
                if (operation != "0")
                {
                    testCases = testCases.OrderBy(m => Convert.ToInt32(m.NodeOrder)).ToList();
                }
                int i = 1;
                foreach (var val in testCases)
                {
                    arr.Add(new TestCaseDetailModel
                    {
                        ID = val.Id,
                        TCMId = val.TCMId,
                        Title = val.Summary,
                        TestPlanID = val.TestPlanId,
                        TestCaseVersionId = val.TestCaseVersionId,
                        TestType = val.TestType,
                        OrderNo = !string.IsNullOrEmpty(val.NodeOrder) ? Convert.ToInt32(val.NodeOrder) : 0,
                        SeqNo = i
                    });
                    i++;
                }
                /* WG3736 mod END Modification for Map TC*/
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return arr;
        }

        /// <summary>
        /// Map selected tcs to new section and sentence
        /// </summary>
        /// <param name="testCaseIDs">comma separated list of test suite ids</param>
        /// <param name="section">section to map</param>
        /// <param name="sentence">sentence to map</param>
        /// <param name="docSuiteId">docSuite Id</param>
        /// <returns>status of update operation</returns>
        public GeneralResultModel UpdateTestCaseLocation(string testCaseIDs, string section, string sentence, string docSuiteId)
        {
            GeneralResultModel result = new GeneralResultModel();
            var tLProjectRepository = new TLRepository();
            try
            {
                result.status = tLProjectRepository.UpdateTestCaseLocation(testCaseIDs, section, sentence);
                UpdateLastUpdateTime(Convert.ToInt32(docSuiteId));
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                result.status = false;
                result.message = Resources.Resource.TCLocationUpdateError;
            }
            return result;
        }

        /// <summary>
        /// Gets test cases from test plans in the provided test project
        /// </summary>
        /// <param name="userName">user Name</param>
        /// <param name="projectID">Project ID</param>
        /// <param name="testSuiteID">Test suite ID</param>
        /// <param name="token">String token</param>
        /// <param name="testSuiteName">testSuite Name</param>
        /// <param name="moduleIdForBug">module Id For Bug</param>
        /// <param name="productName">Product Name</param>
        /// <param name="versionName">version Name</param>
        /// <returns>List of TestCaseSummary</returns>
        /// 2018/10/17, Praveen M P ,V29627_Modification for Test summary details
        /// 2019/02/20, Sujith, VJP192_Modification for performance improvement
        /// 2019/05/09, Sharon Thankachan, WG3736_Modification for create and link bug 
        /// 2020/01/20, Vinoth N, B1K017_Modification for retrieve member name 
        public List<TestCaseSummaryModel> GetAllTestCases(string userName, int projectID, int testSuiteID, string token, string testSuiteName, int moduleIdForBug,
            string productName = "", string versionName = "")
        {
            TLUserRepository tlRepository = new TLUserRepository();
            TLRepository tLProjectRepository = new TLRepository();
            List<TestCaseSummaryModel> summary = new List<TestCaseSummaryModel>();
            var tLink = ConnectTestLink(token);
            List<TestPlan> testPlans = tLink.GetProjectTestPlans(projectID);
            {
                bool exist = false;
                // 2019/02/20, Sujith, VJP192_Modification 
                var tss = tLink.GetTestSuitesForTestSuiteNew(testSuiteID);
                if (tss.Count != 0)
                {
                    var pjtLists = new ProductManager().GetMemberProjectList(token, productName, versionName, userName);
                    var ts = tLink.GetTestSuiteById(testSuiteID);
                    var mod = pjtLists.Find(m => m.ModuleName == ts.name);
                    if (mod != null)
                    {
                        tss.RemoveAll(m => mod.DocModels.Find(n => n.Name == m.Name) == null);
                    }
                }
                else
                {
                    tss = new List<TestSuiteData>()
                    {
                        new TestSuiteData()
                        {
                            Id=testSuiteID
                        }
                    };
                }
                if (exist)
                {
                    /* WG3736 mod START Modification for create and link bug */
                    List<DAL.Objects.TestCase> testcases = new List<DAL.Objects.TestCase>();
                    foreach (var ts1 in tss)
                    {
                        testcases = testcases.Union(tLProjectRepository.GetAllTestCases(ts1.Id)).ToList();
                    }
                    foreach (var testcase in testcases)
                    {
                        if (testcase != null)
                        {
                            string result = string.Empty;
                            string testedDate = testcase.LastExnStatus.TestedDate.ToString("yyyy/MM/dd");
                            if (testcase.LastExnStatus.Status == 'f')
                            {
                                result = "NG";
                            }
                            else if (testcase.LastExnStatus.Status == 'p')
                            {
                                result = "OK";
                            }
                            else
                            {
                                testedDate = DateTime.MinValue.ToString();
                            }
                            /*V29627_Modification for Test summary details  START*/
                            summary.Add(new TestCaseSummaryModel
                            {
                                TCId = Convert.ToInt32(testcase.Id),
                                Name = testcase.Name,
                                TestExecutionStatus = result,
                                Title = testcase.Name,
                                TestExecutionDate = Convert.ToDateTime(testedDate),
                                ExecutionType = testcase.TestType,
                                BugID = testcase.BugId,
                                TestPlanName = testPlans.Find(m => m.id == testcase.TestPlanId).name,//testPlan.name,//
                                TCExternalID = Convert.ToInt32(testcase.Extid),
                                TestPlanID = testcase.TestPlanId,//testPlan.id,//
                                TCMId = testcase.TCMId,
                                ModuleId = moduleIdForBug,
                                TestSuiteId = testcase.TestCaseVersionId,
                                /* B1K017 mod START Modification for retrive member name */
                                AssignedTo = testcase.Assignee
                                /* B1K017 mod END Modification for retrive member name */
                            });
                            /*V29627_Modification for Test summary details  END*/
                        }
                        /* WG3736 mod END Modification for create and link bug */
                    }
                }

            }
            return summary;
        }

        /// <summary>
        /// Gets recently assigned test cases
        /// </summary>
        /// <param name="productName">product name</param>
        /// <param name="versionName">version name</param>
        /// <param name="userName">user name</param>
        /// <param name="limit">skip count</param>
        /// <returns>List of TestCaseSummary</returns>
        /// 2020/06/19, Vinoth N, C51165_Initial version
        public List<TestCaseSummaryModel> GetRecentlyAssignedTestCases(string productName, string versionName, string userName, int limit)
        {
            TLRepository manager = new TLRepository();
            List<TestCaseSummaryModel> summary = new List<TestCaseSummaryModel>();
            List<DAL.Objects.TestCase> testcases = new List<DAL.Objects.TestCase>();
            testcases = manager.GetRecentlyAssignedtestcases(productName, versionName, userName, limit);
            foreach (var testcase in testcases)
            {
                if (testcase != null)
                {
                    string result = string.Empty;
                    string testedDate = testcase.LastExnStatus.TestedDate.ToString("yyyy/MM/dd");
                    if (testcase.LastExnStatus.Status == 'f')
                    {
                        result = "NG";
                    }
                    else if (testcase.LastExnStatus.Status == 'p')
                    {
                        result = "OK";
                    }
                    else
                    {
                        testedDate = DateTime.MinValue.ToString();
                    }
                    summary.Add(new TestCaseSummaryModel
                    {
                        TCId = Convert.ToInt32(testcase.Id),
                        Name = testcase.Name,
                        TestExecutionStatus = result,
                        Title = testcase.Name,
                        TestExecutionDate = Convert.ToDateTime(testedDate),
                        ExecutionType = testcase.TestType,
                        BugID = testcase.BugId,
                        TCExternalID = Convert.ToInt32(testcase.Extid),
                        TestPlanID = testcase.TestPlanId,
                        TCMId = testcase.TCMId,
                        AssignedTo = testcase.Assignee,
                        AssignDate = testcase.AssignDate,
                        ModuleName = testcase.ProjectName,
                        TestSuiteId = testcase.TestSuiteId
                    });
                }
            }
            return summary;
        }

        /// <summary>
        /// Deletes the test cases from the data base
        /// </summary>
        /// <param name="externalIDs">Test case external IDs of selected test cases</param>
        /// <param name="token">user token</param>
        /// <param name="testPlanIDs">testPlan Ids</param>
        /// <param name="testCaseIds">testCase Ids</param>
        /// <param name="filePath">file Path</param>
        /// 2019/08/28, Vinoth N, WG3736_Modification for validate f2TDocument 
        public bool DeleteTestcases(string externalIDs, string token, string testPlanIDs, string testCaseIds, string filePath)
        {
            /* WG3736 mod START WG3736_Modification for validate f2TDocument */
            TLRepository tLProjectRepository = new TLRepository();
            RMUserRepository rmRepository = new RMUserRepository();
            APIHelper apiHelper = new APIHelper();
            List<int> tcIDs = new List<int>();
            /* WG3736 mod END WG3736_Modification for validate f2TDocument */
            int tcExtId = -1;
            string[] ids = testCaseIds.Split(';');
            int.TryParse(ids[0], out tcExtId);
            bool status = false;
            int docSuiteId = tLProjectRepository.GetParentSuiteId(tcExtId);
            DeleteAssignedUserInformation(token, testPlanIDs, testCaseIds);
            foreach (string tcversionID in ids)
            {
                int externalID = 0;
                if (int.TryParse(tcversionID, out externalID))
                {
                    status = tLProjectRepository.DeleteTestCase(externalID);
                }
            }
            /* WG3736 mod START WG3736_Modification for validate f2TDocument */
            var testCases = tLProjectRepository.GetAllTestCasesNew(docSuiteId, tcIDs.ToList());
            if (testCases.Count > 0)
            {
                UpdateLastUpdateTime(docSuiteId);
            }
            else
            {
                F2THandler openDoc = new F2THandler();
                if (openDoc.GetCommentCount(filePath) == 0)
                {
                    FileInfo fileInfo = new FileInfo(filePath.ToString());
                    tLProjectRepository.UpdateLastUpdatedTime(docSuiteId, fileInfo.LastWriteTime);
                }
                else
                {
                    UpdateLastUpdateTime(docSuiteId);
                }
            }
            /* WG3736 mod END WG3736_Modification for validate f2TDocument */
            return status;
        }

        /*V29627_Modification for scenario execution START*/ //sharon
        /// <summary>
        /// Delete attachment by testcaseID
        /// </summary>
        /// <param name="testCaseID">test case id</param>
        /// <param name="attachmentID">attachment id</param>
        /// <returns>general result</returns>
        public GeneralResultModel DeleteAttachment(int testCaseID, int attachmentID)
        {
            GeneralResultModel result = new GeneralResultModel();
            TLRepository tLProjectRepository = new TLRepository();
            result.status = tLProjectRepository.DeleteAttachment(testCaseID, attachmentID);
            return result;
        }
        /*V29627_Modification for scenario execution END*/

        /// <summary>
        /// Assigns the given test case to the user
        /// </summary>
        /// <param name="token">Token string</param>
        /// <param name="username">Name of the user</param>
        /// <param name="externalID">External Id of the test case</param>
        /// <param name="projectName">Test project name</param>
        /// <param name="testplanid">Test plan Id</param>
        public void AssignTestcaseToUser(string token, string username, int externalID, string projectName, int testplanid)
        {
            int buildID = 0;
            string buildName = string.Empty;
            TLRepository repo = new TLRepository();
            string testPlanName = "";
            string prefix = "";
            string extid = "";
            var proxy = ConnectTestLink(token);
            if (string.IsNullOrEmpty(projectName))
            {
                var id = repo.GetProjectId(testplanid, out testPlanName, out prefix);
                extid = string.Format("{0}-{1}", prefix, externalID);
            }
            else
            {
                TestProject testProject = proxy.GetProject(projectName);
                extid = string.Format("{0}-{1}", testProject.prefix, externalID);
            }
            TLUserRepository tlRepository = new TLUserRepository();
            tlRepository.GetBuildIdAndName(testplanid, ref buildName, ref buildID);
            string apiKey = GetAPIKey(token);
            proxy.assignTestCaseExecutionTask(apiKey, testplanid, buildID, buildID, extid, username);
        }

        /// <summary>
        /// Method to get inner test suite for a test suite
        /// </summary>
        /// <param name="suiteId">test suite id</param>
        /// <param name="token">api token</param>
        /// <param name="data">bool val</param>
        /// <returns>list of test suites</returns>
        public List<BaseData> GetTestSuitesFromTestSuites(int suiteId, string token, bool data)
        {
            int tcid = 0;
            TLRepository tLProjectRepository = new TLRepository();
            //tLProjectRepository.GetTestcaseIdByTCMID(75, 105166, ref tcid);
            List<BaseData> summary = new List<BaseData>();
            List<TestSuiteData> testSuites = new List<TestSuiteData>();
            List<TestSuite> testSuitesList = new List<TestSuite>();
            //if (data)
            {
                testSuites = ConnectTestLink(token).GetTestSuitesForTestSuiteNew(suiteId);
                foreach (TestSuiteData ts in testSuites)
                {
                    summary.Add(new BaseData { Id = ts.Id, Name = ts.Name });
                }
            }

            return summary;
        }

        /// <summary>
        /// get test suites
        /// </summary>
        /// <param name="projectid">id of the project</param>
        /// <param name="token">api token</param>
        /// <returns>List of type BaseData</returns>
        public List<BaseData> GetTestSuites(int projectid, string token)
        {
            List<BaseData> summary = new List<BaseData>();
            List<TestSuite> testSuite = ConnectTestLink(token).GetFirstLevelTestSuitesForTestProject(projectid);
            foreach (TestSuite ts in testSuite)
            {
                summary.Add(new BaseData { Id = ts.id, Name = ts.name });
            }
            return summary;
        }

        /// <summary>
        /// Method to get the module details for dashboard
        /// </summary>
        /// <param name="productName">name of the product</param>
        /// <param name="token">token</param>
        /// <param name="versionName">version name</param>
        /// <param name="modList">mod List</param>
        /// <returns>list of test case summary</returns>
        /// 2019/02/11, Sujith A ,VJP192- Modified
        /// 2021/06/14, Vinoth N, EL5873_Modification for build settings
        public List<TestCaseSummaryModel> GetTestProjectSummary(string productName, string token, string versionName, List<ModuleModel> modList)
        {

            TestProject project = ConnectTestLink(token).GetProject(productName);
            int projectid = project.id;
            string projectPrefix = project.prefix;
            List<TestCaseSummaryModel> summary = new List<TestCaseSummaryModel>();
            TestCaseManager manager = new TestCaseManager();
            List<BaseData> datas = manager.GetTestSuites(projectid, token);
            // 2019/02/11, Sujith A ,VJP192- Modified
            var memberProjectList = modList;
            try
            {
                if (datas.Count > 0)
                {
                    BaseData testSuiteVersion = (from testsuites in datas
                                                 where testsuites.Name == versionName
                                                 select testsuites).FirstOrDefault();
                    var repo = new TLRepository();
                    /* EL5873 mod START Modification for build and path settings */
                    if (testSuiteVersion != null)
                    {
                        List<BaseData> tss = manager.GetTestSuitesFromTestSuites(testSuiteVersion.Id, token, true);
                        foreach (BaseData testSuiteModule in tss)
                        {
                            var modu = memberProjectList.Find(m => m.ModuleName == testSuiteModule.Name);
                            if (modu == null) continue;
                            List<BaseData> testSuiteDocument = manager.GetTestSuitesFromTestSuites(testSuiteModule.Id, token, true);
                            testSuiteDocument.RemoveAll(m => modu.DocModels.Find(n => n.Name == m.Name) == null);
                            foreach (BaseData data in testSuiteDocument)
                            {
                                {
                                    var testcases = repo.GetTestcaseSummary(data.Id.ToString());
                                    foreach (var tc in testcases)
                                    {
                                        string testType = tc.TestType;
                                        TestResultStatus status = TestResultStatus.Undefined;
                                        if (tc.LastExnStatus.Status == 'p')
                                        {
                                            status = TestResultStatus.Pass;
                                        }
                                        else if (tc.LastExnStatus.Status == 'f')
                                        {
                                            status = TestResultStatus.Fail;
                                        }
                                        testType = string.IsNullOrEmpty(testType) ? string.Empty : testType;
                                        if (!string.IsNullOrEmpty(testType))
                                        {
                                            testType = testType.Substring(0, 2);
                                        }
                                        if (testSuiteModule.Name.ToLower().StartsWith("system"))
                                        {
                                            testType = "System";
                                        }
                                        /* EL5873 mod END Modification for build and path settings */
                                        int tcid = 0;
                                        int.TryParse(tc.Id, out tcid);
                                        if (testType.ToLower().Equals("s3") || testType.ToLower().Equals("s4") || testType.Equals("System"))
                                        {
                                            summary.Add(new TestCaseSummaryModel
                                            {
                                                DocumentName = data.Name,
                                                ProjectId = projectid,
                                                ModuleName = testSuiteModule.Name,
                                                TCId = tcid,
                                                Name = tc.Name,
                                                Status = status,
                                                TestType = testType
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return summary;
        }

        /// <summary>
        /// Method to get project id from name
        /// </summary>
        /// <param name="projectName">name of the project</param>
        /// <param name="token">token</param>
        /// <returns>project id</returns>
        public int GetProjectIdFromName(string projectName, string token)
        {
            TestProject tProject = ConnectTestLink(token).GetProject(projectName);
            return tProject.id;
        }

        /// <summary>
        /// get test project summary
        /// </summary>
        /// <param name="token">api token</param>
        /// <returns>List of type BaseData</returns>
        public List<BaseData> GetTestProjectSummary(string token)
        {
            List<BaseData> summary = new List<BaseData>();
            List<TestProject> testProjects = ConnectTestLink(token).GetProjects();
            foreach (TestProject testProject in testProjects)
            {
                if (testProject.active)
                    summary.Add(new BaseData { Id = testProject.id, Name = testProject.name });
            }

            return summary;
        }

        /// <summary>
        /// add ldap user to testlink db
        /// </summary>
        /// <param name="tlUser">testlink user</param>
        public void AddLDAPTestlinkUser(TestLinkUser tlUser)
        {
            TLUserRepository tlRepository = new TLUserRepository();
            if (!tlRepository.DoesUserExist(tlUser.Login))
            {
                tlRepository.CreateUser(tlUser);
            }
        }

        /// <summary>
        /// get test plan summary
        /// </summary>
        /// <param name="projectId">id of the project</param>
        /// <param name="token">api token</param>
        /// <returns>Returns list of type BaseData</returns>
        public List<BaseData> GetTestPlanSummary(int projectId, string token)
        {
            List<BaseData> summary = new List<BaseData>();
            List<TestPlan> testPlans = ConnectTestLink(token).GetProjectTestPlans(projectId);
            foreach (TestPlan testPlan in testPlans)
            {
                summary.Add(new BaseData { Id = testPlan.id, Name = testPlan.name });
            }
            return summary;
        }

        /// <summary>
        /// Create new test case
        /// </summary>
        /// <param name="testCaseDetails">Data to be saved for new test case</param>
        /// <param name="token">API token</param>
        /// <returns>Result of creation</returns>
        /// 2018/10/17, Praveen M P ,V29627_Modification for Test Case Management
        /// 2019/02/18, Sujith A ,VJP192- Modification for Product management
        /// 2019/07/09, Sujith A, WG3736_Modification for test case creation form document display UI
        /// 2020/01/08, Vinoth N, B1K017_Modification for removing Unicodes
        public GeneralResultModel CreateTestCase(TestCaseDetailModel testCaseDetailsModel, string token)
        {
            var testCaseDetails = ConverttoDALObject(testCaseDetailsModel);
            string extid = string.Empty;
            int testSuitID = 0;
            int tcmID = 0;
            GeneralResult testLinkResult = new GeneralResult();
            GeneralResultModel generalResult = new GeneralResultModel();
            generalResult.message = Resources.Resource.TCCreateFaild;
            string testPlanName = testCaseDetailsModel.TestPlanName;
            string testProject = "";
            string prefix = "";
            int testPlanId = testCaseDetailsModel.TestPlanID;
            try
            {
                TLRepository repository = new TLRepository();
                /* WG3736 mod START Modification for test case creation form document display UI*/
                testSuitID = int.Parse(testCaseDetailsModel.TestSuitID);
                if (testPlanId <= 0)
                {
                    testPlanName = repository.GetTestPlanName(testSuitID, out testProject);
                    /// 2019/02/18, Sujith A ,VJP192- modification for product management
                    TestPlan testPlan = ConnectTestLink(token).getTestPlanByName(testProject, testPlanName);
                    testPlanId = testPlan.id;
                }
                /* WG3736 mod END Modification for test case creation form document display UI*/
                if (testPlanId > 0)
                {
                    var projectId = repository.GetProjectId(testPlanId, out testPlanName, out prefix);
                    var proxy = ConnectTestLink(token);
                    var repo = new TLRepository();
                    tcmID = repo.GetTCMIDMaxValue(testSuitID) + 1;
                    testCaseDetails.Name = testCaseDetails.Name.Length > 90 ? testCaseDetails.Name.Substring(0, 90) : testCaseDetails.Name;
                    testCaseDetails.Name = testCaseDetails.Name + "_" + tcmID;

                    testLinkResult = proxy.CreateTestCase(testCaseDetailsModel.UserName, testSuitID, testCaseDetails.Name,
                        projectId, testCaseDetails.Summary, string.Empty, 1, true, ActionOnDuplicatedName.Block,
                        testCaseDetails.ExType, testCaseDetails.Importance);
                    /*V29627_Modification for adding custom fields START*/
                    if (testLinkResult.status)
                    {
                        if (testLinkResult.id > 0)
                        {
                            testLinkResult.message = testPlanId.ToString();
                            testCaseDetails.TCMId = tcmID.ToString();
                            extid = string.Format("{0}-{1}", prefix, testLinkResult.additionalInfo.external_id);
                            Dictionary<string, string> customFields = new Dictionary<string, string>();
                            /* B1K017 mod START Modification for removing Unicodes */
                            customFields.Add(Constants.CUSTOM_FIELD_MACHINENAME, SafeFormat(testCaseDetails.MachineName));
                            customFields.Add(Constants.CUSTOM_FIELD_TESTTYPE, SafeFormat(testCaseDetails.TestType));
                            customFields.Add(Constants.CUSTOM_FIELD_SUBTESTTYPE, SafeFormat(testCaseDetails.SubTestType));
                            customFields.Add(Constants.CUSTOM_FIELD_PROJECT_NAME, SafeFormat(testCaseDetailsModel.ProjectName));
                            customFields.Add(Constants.CUSTOM_FIELD_SCENARIO_NAME, SafeFormat(testCaseDetailsModel.MainScenarioName));
                            customFields.Add(Constants.CUSTOM_FIELD_SCRIPT_FILE, SafeFormat(testCaseDetailsModel.ScriptFile));
                            customFields.Add(Constants.CUSTOM_FIELD_SECTION, SafeFormat(testCaseDetailsModel.DocumentSection));
                            customFields.Add(Constants.CUSTOM_FIELD_SENTENCE, SafeFormat(testCaseDetailsModel.DocumentSentence));
                            customFields.Add(Constants.CUSTOM_FIELD_SCHEDULED_EXECUTION_VALUE, SafeFormat(testCaseDetailsModel.ScheduledExnValue));
                            customFields.Add(Constants.CUSTOM_FIELD_SCHEDULED_EXECUTION_TYPE, SafeFormat(testCaseDetailsModel.ScheduledExnType));
                            /* B1K017 mod END Modification for removing Unicodes */
                            customFields.Add(Constants.CUSTOM_FIELD_TCMID, testCaseDetails.TCMId);
                            proxy.UpdateTestCaseCustomFieldDesignValue(extid, testLinkResult.additionalInfo.version_number,
                                projectId.ToString(), customFields);

                            if (testCaseDetails.Attachments.Count > 0)
                            {
                                foreach (var item in testCaseDetails.Attachments)
                                {
                                    var attachmentResult = proxy.UploadTestCaseAttachment(testLinkResult.id, item.Name, item.FileType, item.Content, item.Title, item.FilePath);
                                }
                            }

                            if (testCaseDetails.Steps.Count > 0)
                            {
                                string testlinkURL = ConfigurationManager.AppSettings[Constants.APPSETTINGS_TESTLINK_URL];
                                List<Meyn.TestLink.Attachment> attachments = proxy.GetTestCaseAttachments(testLinkResult.id);
                                TestStep[] steps = GetTestSteps(testCaseDetails.Steps);
                                proxy.createTestCaseSteps(extid, testLinkResult.id.ToString(), testLinkResult.additionalInfo.version_number.ToString(), steps);
                            }
                            proxy.addTestCaseToTestPlan(projectId, testPlanId, extid, testLinkResult.additionalInfo.version_number);
                        }
                        else
                        {
                            testLinkResult.status = false;
                            testLinkResult.message = testLinkResult.additionalInfo.msg;
                            TMFLogger.LogError(testLinkResult.additionalInfo.msg);
                        }
                    }
                }
                generalResult.status = testLinkResult.status;
                generalResult.message = testLinkResult.status ? testLinkResult.message : Resources.Resource.TCCreateFaild;
                generalResult.id = testLinkResult.id;
                generalResult.testplan_id = testPlanId.ToString();
                testCaseDetailsModel.ID = testLinkResult.id.ToString(); ;
                testCaseDetailsModel.TestPlanID = Convert.ToInt32(testPlanId.ToString());
                testCaseDetailsModel.TCMId = tcmID.ToString();
                /*V29627_Modification for adding custom fields END*/

                UpdateLastUpdateTime(testSuitID);

                /*V29627_Modification  for create and schedule jenkins jobs START*/

                if (testCaseDetailsModel.ExnType && testCaseDetailsModel.ScheduledExnValue != null)
                {
                    CreateAndScheduleJob(testCaseDetailsModel, testCaseDetailsModel.TestProjectName, token);
                }

                /*V29627_Modification for create and schedule jenkins jobs END*/
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                generalResult.status = false;
                generalResult.message = Resources.Resource.TCCreateFaild;
            }

            return generalResult;
        }

        /// <summary>
        /// method to upload attachment
        /// </summary>
        /// <param name="attachment">attachment list</param>
        /// <param name="testCaseID">tc id</param>
        /// <param name="token">token</param>
        /// <param name="totalFileSize">File Size</param>
        /// <returns>list of attachment</returns>
        public List<AttachmentModel> UploadTestCaseAttachment(List<AttachmentModel> attachment, int testCaseID, string token, long totalFileSize)
        {
            List<AttachmentModel> attachmentDetails = new List<AttachmentModel>();
            if (attachment.Count > 0)
            {
                var attachmentList = ConverttoDALObject(attachment);
                var proxy = ConnectTestLink(token);
                AttachmentRequestResponse result;
                List<Meyn.TestLink.Attachment> attachments = proxy.GetTestCaseAttachments(testCaseID);
                var dirPath = HostingEnvironment.MapPath(Constants.TC_ATTACHMENT_UPLOAD_FOLDER_PATH);
                foreach (var item in attachmentList)
                {
                    result = proxy.UploadTestCaseAttachment(testCaseID, item.Name, item.FileType, new byte[10], item.Title, item.Name);
                }
                attachments = proxy.GetTestCaseAttachments(testCaseID);

                string testlinkURL = ConfigurationManager.AppSettings[Constants.APPSETTINGS_TESTLINK_URL];
                foreach (var item in attachments)
                {
                    var path = Path.Combine(dirPath, item.name);
                    long fileSize = 0;
                    if (File.Exists(path))
                        fileSize = new System.IO.FileInfo(path).Length;

                    string filePath = String.Concat(testlinkURL, Constants.TESTLINK_ATTACHMENT_DOWNLOAD_URL, item.id);
                    attachmentDetails.Add(new AttachmentModel { Id = item.id, Name = item.name, FileType = item.file_type, FilePath = filePath, Title = item.title, FileSize = fileSize });
                }
            }

            return attachmentDetails;
        }

        /// <summary>
        /// method to upload attachment
        /// </summary>
        /// <param name="attachment">attachment list</param>
        /// <param name="testCaseID">tc id</param>
        /// <param name="token">token</param>
        /// <returns>list of attachment</returns>
        /// 2020/01/18, Vinoth N, B1K017_Initial version
        public List<AttachmentModel> UploadTestSuiteAttachment(List<AttachmentModel> attachment, int testSuiteID, string token)
        {
            List<AttachmentModel> attachmentDetails = new List<AttachmentModel>();
            if (attachment.Count > 0)
            {
                var attachmentList = ConverttoDALObject(attachment);
                var proxy = ConnectTestLink(token);
                TLRepository repo = new TLRepository();
                AttachmentRequestResponse result;
                List<TMF.DAL.Objects.Attachment> attachments = repo.GetTestSuiteAttachments(testSuiteID);
                var dirPath = HostingEnvironment.MapPath(Constants.TC_ATTACHMENT_UPLOAD_FOLDER_PATH);
                foreach (var item in attachmentList)
                {
                    result = proxy.UploadTestSuiteAttachment(testSuiteID, item.Name, item.FileType, new byte[10], item.Title, item.Name);
                }

                attachments = repo.GetTestSuiteAttachments(testSuiteID);
                string testlinkURL = ConfigurationManager.AppSettings[Constants.APPSETTINGS_TESTLINK_URL];
                foreach (var item in attachments)
                {
                    var path = Path.Combine(dirPath, item.Name);
                    long fileSize = 0;
                    if (File.Exists(path))
                        fileSize = new System.IO.FileInfo(path).Length;

                    string filePath = String.Concat(testlinkURL, Constants.TESTLINK_ATTACHMENT_DOWNLOAD_URL, item.Id);
                    attachmentDetails.Add(new AttachmentModel { Id = item.Id, Name = item.Name, FileType = item.FileType, FilePath = filePath, Title = item.Title, FileSize = fileSize });
                }
            }
            return attachmentDetails;
        }

        /// <summary>
        /// method to retrieve attachment
        /// </summary>
        /// <param name="testSuiteID">tc id</param>
        /// <returns>list of attachment</returns>
        /// 2020/01/18, Vinoth N, B1K017_Initial version
        public List<AttachmentModel> GetTestSuiteAttachment(int testSuiteID)
        {
            List<AttachmentModel> attachmentDetails = new List<AttachmentModel>();
            TLRepository repo = new TLRepository();
            List<TMF.DAL.Objects.Attachment> attachments = repo.GetTestSuiteAttachments(testSuiteID);
            var dirPath = HostingEnvironment.MapPath(Constants.TC_ATTACHMENT_UPLOAD_FOLDER_PATH);
            attachments = repo.GetTestSuiteAttachments(testSuiteID);
            string testlinkURL = ConfigurationManager.AppSettings[Constants.APPSETTINGS_TESTLINK_URL];
            foreach (var item in attachments)
            {
                var path = Path.Combine(dirPath, item.Name);
                long fileSize = 0;
                if (File.Exists(path))
                    fileSize = new System.IO.FileInfo(path).Length;

                string filePath = String.Concat(testlinkURL, Constants.TESTLINK_ATTACHMENT_DOWNLOAD_URL, item.Id);
                attachmentDetails.Add(new AttachmentModel { Id = item.Id, Name = item.Name, FileType = item.FileType, FilePath = filePath, Title = item.Title, FileSize = fileSize });
            }
            return attachmentDetails;
        }

        /// <summary>
        /// Get test case details by test case ID
        /// </summary>
        /// <param name="testCaseID">Test case ID</param>
        /// <param name="testProjectName">Project name in which the test case is present</param>
        /// <param name="testPlanID">testPlan ID</param>
        /// <param name="token">API token</param>
        /// <param name="position">position</param>
        /// <param name="fromSection">fromSection</param>
        /// <returns>Test case details</returns>
        /// 2018/01/17, Sujith A , Initial Version
        /// 2019/01/17, Sharon Thankachan, VJP192_Modification for attach multiple bugs in TC
        /// 2019/01/25, Sharon Thankachan, VJP192_Modification for Email Notification
        public TestCaseDetailModel GetTestCaseByID(int testCaseID, string testProjectName, int testPlanID, string token, string position = "", bool fromSection = false)
        {
            var repo = new TLRepository();
            if (!string.IsNullOrEmpty(position))
            {
                testCaseID = repo.GetTcVersionID(testCaseID, position, fromSection);
            }
            testProjectName = repo.GetTestCaseProjectName(testCaseID);
            var proxy = ConnectTestLink(token);
            /*V29627_Modification for adding custom fields  START*/
            TestProject testProject = proxy.GetProject(testProjectName);
            var customFieldNames = new List<string>{
                Constants.CUSTOM_FIELD_TESTTYPE,
                Constants.CUSTOM_FIELD_SUBTESTTYPE,
                Constants.CUSTOM_FIELD_PROJECT_NAME,
                Constants.CUSTOM_FIELD_SCENARIO_NAME,
                Constants.CUSTOM_FIELD_SCRIPT_FILE,
                Constants.CUSTOM_FIELD_SECTION,
                Constants.CUSTOM_FIELD_SENTENCE,
                Constants.CUSTOM_FIELD_BUGID,
                Constants.CUSTOM_FIELD_TCMID,
                Constants.CUSTOM_FIELD_TESTER_NAMES,
                Constants.CUSTOM_FIELD_MACHINENAME,
                Constants.CUSTOM_FIELD_SCHEDULED_EXECUTION_VALUE,
                Constants.CUSTOM_FIELD_SCHEDULED_EXECUTION_TYPE
            };
            TestCaseDetailModel testCaseDetailsDAL = new TestCaseDetailModel();
            int externalId = repo.GetExternalId(testCaseID);
            if (externalId > 0)
            {
                TestCaseFromTestPlan testCaseFromTestPlan = proxy.GetTestCasesForTestPlan(testPlanID, testCaseID)
                    .Where(tc => tc.tc_id == testCaseID).FirstOrDefault();
                TestPlan pln = proxy.GetProjectTestPlans(testProject.id).Where(tc => tc.id == testPlanID).FirstOrDefault();
                Meyn.TestLink.TestCase testCaseDetails = proxy.GetTestCase(testCaseID);
                string extid = string.Format("{0}-{1}", testProject.prefix, testCaseDetails.externalid);
                testCaseDetailsDAL.TestSuiteName = pln.name.Substring(pln.name.LastIndexOf('_') + 1);
                testCaseDetailsDAL.ID = testCaseDetails.testcase_id.ToString();
                testCaseDetailsDAL.Title = testCaseDetails.name;
                testCaseDetailsDAL.Summary = testCaseDetails.summary;
                testCaseDetailsDAL.ExternalID = extid;
                testCaseDetailsDAL.ExnType = testCaseDetails.execution_type == Convert.ToInt32(ExecutionType.Automated) ? true : false;
                testCaseDetailsDAL.ProjectID = testProject.id.ToString();
                testCaseDetailsDAL.VersionID = testCaseDetails.version;
                if (testCaseDetails.steps.Count > 0)
                {
                    testCaseDetailsDAL.TestCase = testCaseDetails.steps[0].actions;
                    testCaseDetailsDAL.ExpectedResult = testCaseDetails.steps[0].expected_results;
                }

                List<Meyn.TestLink.Attachment> attachments = proxy.GetTestCaseAttachments(testCaseID);
                testCaseDetailsDAL.Attachments = new List<AttachmentModel>();
                string testlinkURL = Constants.TC_ATTACHMENT_UPLOAD_FOLDER_PATH;
                foreach (var item in attachments)
                {
                    string filePath = String.Concat(testlinkURL, "/", item.name);
                    testCaseDetailsDAL.Attachments.Add(new AttachmentModel { Id = item.id, Name = item.name, Title = item.title, FileType = item.file_type, FilePath = filePath });
                }
                string bugId = string.Empty;
                var customFields = repo.GetAllCustomFieldValues(testCaseID);
                foreach (var customField in customFields)
                {
                    string item = customField.Key;
                    string customFieldValue = customField.Value;
                    if (item == Constants.CUSTOM_FIELD_TESTTYPE)
                        testCaseDetailsDAL.TestType = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_SUBTESTTYPE)
                        testCaseDetailsDAL.SubTestType = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_PROJECT_NAME)
                        testCaseDetailsDAL.ProjectName = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_SCENARIO_NAME)
                        testCaseDetailsDAL.MainScenarioName = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_SCRIPT_FILE)
                        testCaseDetailsDAL.ScriptFile = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_SECTION)
                        testCaseDetailsDAL.DocumentSection = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_SENTENCE)
                        testCaseDetailsDAL.DocumentSentence = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_BUGID)
                        bugId = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_TESTER_NAMES)
                        testCaseDetailsDAL.DateAndTesterName = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_TCMID)
                        testCaseDetailsDAL.TCMId = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_MACHINENAME)
                        testCaseDetailsDAL.MachineName = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_SCHEDULED_EXECUTION_VALUE)
                        testCaseDetailsDAL.ScheduledExnValue = customFieldValue;
                    else if (item == Constants.CUSTOM_FIELD_SCHEDULED_EXECUTION_TYPE)
                        testCaseDetailsDAL.ScheduledExnType = customFieldValue;
                }
                /*VJP192_Modification for attach multiple bugs in TC START*/
                if (!string.IsNullOrEmpty(bugId))
                {
                    var attachedBugs = bugId.Split(';');
                    testCaseDetailsDAL.BugDetails = new List<BaseData>();
                    IBugManager remineManager = new BugManager();
                    foreach (var bug in attachedBugs)
                    {
                        if (!string.IsNullOrWhiteSpace(bug))
                            testCaseDetailsDAL.BugDetails.Add(remineManager.GetBugInfo(Convert.ToInt32(bug), token));
                    }
                }
                /*VJP192_Modification for attach multiple bugs in TC END*/

                var statusDAL = ListAllExecutionResults(testPlanID, testCaseFromTestPlan.tcversion_id, testCaseDetailsDAL.DateAndTesterName);
                testCaseDetailsDAL.TestExecutionStatus = ConvertToModelObject(statusDAL);
                if (!string.IsNullOrWhiteSpace(testCaseDetailsDAL.DateAndTesterName))
                    testCaseDetailsDAL.TestExecutionStatus = GetTestExecutionStatusFromCustomField(testCaseDetailsDAL.DateAndTesterName, testCaseDetailsDAL.TestExecutionStatus);
                testCaseDetailsDAL.AssignedTo = repo.GetAssignedUser(testCaseFromTestPlan.feature_id);
                /*VJP192_Modification for Email Notification START*/
                testCaseDetailsDAL.PreviousAssignedTo = testCaseDetailsDAL.AssignedTo;
                /*VJP192_Modification for Email Notification END*/
            }
            /* V29627_Modification for adding custom fields  END */
            return testCaseDetailsDAL;
        }

        /// <summary>
        /// Update test case details by ID
        /// </summary>
        /// <param name="testCaseDetails">Data to be updated in the test case</param>
        /// <param name="token">API token</param>
        /// <returns>Result</returns>
        /// 2018/10/17, Praveen M P ,V29627_Modification for adding custom fields and job execution
        /// 2019/07/04, Sujith A, WG3736_Modification for unassigning user
        /// 2020/01/08, Vinoth N, B1K017_Modification for removing Unicodes
        public GeneralResultModel UpdateTestCaseByID(TestCaseDetailModel testCaseDetailsModel, string token)
        {
            GeneralResultModel generalResult = new GeneralResultModel();
            /*V29627_Modification for jenkins job scheduling START*/
            string projectName = new TLRepository().GetTestCaseProjectName(Convert.ToInt32(testCaseDetailsModel.ID));

            if (testCaseDetailsModel.ExnType && testCaseDetailsModel.ScheduledExnValue != null)
            {
                try
                {
                    generalResult.status = CreateAndScheduleJob(testCaseDetailsModel, projectName, token);
                    generalResult.message = generalResult.status == false ? Resources.Resource.UnableUpdateTC : Resources.Resource.SavedSuccessfully;
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                    generalResult.status = false;
                    generalResult.message = Resources.Resource.CommunicateWithJenkinFaild;
                }
                if (!generalResult.status)
                {
                    return generalResult;
                }
            }

            var testCaseDetails = ConverttoDALObject(testCaseDetailsModel);
            GeneralResult testLinkResult = new Meyn.TestLink.GeneralResult();
            TestStep[] steps = new TestStep[0];
            if (testCaseDetails.Steps.Count > 0)
                steps = GetTestSteps(testCaseDetails.Steps);
            testCaseDetails.Name = testCaseDetails.Name.Length > 30 ? testCaseDetails.Name.Substring(0, 30) : testCaseDetails.Name;
            var proxy = ConnectTestLink(token);
            testLinkResult = proxy.UpdateTestCaseByID(testCaseDetails.Extid, testCaseDetailsModel.VersionID, testCaseDetails.Name, testCaseDetails.Summary, testCaseDetails.PreConditions, steps, testCaseDetails.Importance, testCaseDetails.ExType, 1, 0);
            if (testLinkResult.status)
            {
                /* B1K017 mod START Modification for removing Unicodes */
                testLinkResult.id = int.Parse(testCaseDetails.Id);
                Dictionary<string, string> customFields = new Dictionary<string, string>();
                customFields.Add(Constants.CUSTOM_FIELD_TESTTYPE, SafeFormat(testCaseDetails.TestType));
                customFields.Add(Constants.CUSTOM_FIELD_SUBTESTTYPE, SafeFormat(testCaseDetailsModel.SubTestType ?? string.Empty));
                customFields.Add(Constants.CUSTOM_FIELD_MACHINENAME, SafeFormat(testCaseDetailsModel.MachineName ?? string.Empty));
                /*V29627_Modification for adding custom fields END*/
                customFields.Add(Constants.CUSTOM_FIELD_PROJECT_NAME, SafeFormat(testCaseDetailsModel.ProjectName));
                customFields.Add(Constants.CUSTOM_FIELD_SCENARIO_NAME, SafeFormat(testCaseDetailsModel.MainScenarioName));
                customFields.Add(Constants.CUSTOM_FIELD_SCRIPT_FILE, SafeFormat(testCaseDetailsModel.ScriptFile));
                customFields.Add(Constants.CUSTOM_FIELD_SECTION, SafeFormat(testCaseDetailsModel.DocumentSection ?? string.Empty));
                customFields.Add(Constants.CUSTOM_FIELD_SENTENCE, SafeFormat(testCaseDetailsModel.DocumentSentence ?? string.Empty));
                string val = testCaseDetailsModel.ScheduledExnValue ?? string.Empty;
                customFields.Add(Constants.CUSTOM_FIELD_SCHEDULED_EXECUTION_VALUE, val);
                customFields.Add(Constants.CUSTOM_FIELD_SCHEDULED_EXECUTION_TYPE, SafeFormat(testCaseDetailsModel.ScheduledExnType));
                var customStatus = proxy.UpdateTestCaseCustomFieldDesignValue(testCaseDetails.Extid, testCaseDetailsModel.VersionID, testCaseDetailsModel.ProjectID, customFields);
                /* B1K017 mod END Modification for removing Unicodes */
            }
            generalResult.status = testLinkResult.status;
            generalResult.message = testLinkResult.status ? testLinkResult.message : Resources.Resource.TCUpdateFaild;
            generalResult.id = testLinkResult.id;
            var ts = proxy.GetTestSuitesForTestPlan(testCaseDetailsModel.TestPlanID);
            /* WG3736 mod START Modification for unassigning user*/
            if (string.IsNullOrEmpty(testCaseDetailsModel.AssignedTo) && !string.IsNullOrEmpty(testCaseDetailsModel.PreviousAssignedTo))
            {
                DeleteAssignedUserInformation(token, testCaseDetailsModel.TestPlanID.ToString(), testCaseDetails.Id);
            }
            /* WG3736 mod END Modification for unassigning user*/
            if (ts.Count > 0)
                UpdateLastUpdateTime(ts.ToList().OrderByDescending(m => m.id).FirstOrDefault().id);

            return generalResult;
        }

        /// <summary>
        /// Update global pre condition
        /// </summary>
        /// <param name="preCondition">Data for global pre condition</param>
        /// <param name="projectId">Project Id</param>
        /// <returns>Result of update</returns>
        /// 2020/01/08, Vinoth N, B1K017_Initial version
        public GeneralResultModel UpdateGlobalPreCondition(StringBuilder preCondition, int projectId)
        {
            GeneralResultModel generalResult = new GeneralResultModel();
            TLRepository repo = new TLRepository();
            var status = repo.UpdatePreCondition(projectId, preCondition);
            generalResult.status = status;
            if (status)
                generalResult.message = Resources.Resource.SavedSuccessfully;
            else
                generalResult.message = Resources.Resource.Failed;

            return generalResult;
        }

        /// <summary>
        /// get global pre condition
        /// </summary>
        /// <param name="projectId">Project Id</param>
        /// <returns>Result of update</returns>
        /// 2020/01/08, Vinoth N, B1K017_Initial version
        public StringBuilder GetGlobalPreCondition(int projectId)
        {
            TLRepository repo = new TLRepository();
            StringBuilder result = new StringBuilder();
            result = repo.GetPreCondition(projectId);
            return result;
        }

        /// <summary>
        /// Save execution status OK/NG
        /// </summary>
        /// <param name="testExecutionStatus">execution status</param>
        /// <param name="projectName">project name</param>
        /// <param name="token">token</param>
        /// <returns>general result</returns>
        /// 2021/06/15, Vinoth N, EL5873_Modification for build settings
        public GeneralResultModel SetTestExecutionStatus(ViewModels.TestExecutionStatus testExecutionStatusModel, string projectName, string token)
        {
            var testExecutionStatus = ConvertToDALObject(testExecutionStatusModel);
            Meyn.TestLink.GeneralResult testLinkResult = new Meyn.TestLink.GeneralResult();
            GeneralResultModel generalResult = new GeneralResultModel();
            TLUserRepository userRepo = new TLUserRepository();
            /* EL5873 mod START Modification for build settings */
            TLRepository tLProjectRepository = new TLRepository();
            var status = testExecutionStatus.Status == 'p' ? TestCaseResultStatus.Pass : TestCaseResultStatus.Fail;
            TestLinkUser userDetails = userRepo.GetUser(testExecutionStatus.TesterName);
            var proxy = ConnectTestLink(token);
            if (userDetails != null)
            {
                if (testExecutionStatus.TestPlanID > 0)
                {
                    TestCaseFromTestPlan testCaseFromTestPlan = proxy.GetTestCasesForTestPlan(testExecutionStatus.TestPlanID, testExecutionStatus.TestCaseID).Where(tc => tc.tc_id == testExecutionStatus.TestCaseID).FirstOrDefault();
                    if (testCaseFromTestPlan != null)
                    {
                        string date = testExecutionStatus.TestedDate.ToString("yyyy-MM-dd HH:mm:ss");
                        testLinkResult = proxy.ReportTCResult(testCaseFromTestPlan.tc_id, testExecutionStatus.TestPlanID, status, testCaseFromTestPlan.platform_id, null, false, true, string.Empty, testCaseFromTestPlan.assigned_build_id, 0, date);
                        if (testLinkResult.status)
                        {
                            Dictionary<string, string> customFields = new Dictionary<string, string>();
                            TestProject testProject = proxy.GetProject(projectName);
                            string extid = string.Format("{0}-{1}", testProject.prefix, testCaseFromTestPlan.external_id);
                            string customFieldValue = proxy.GetTestCaseCustomFieldDesignValue(extid, testCaseFromTestPlan.version, testProject.id.ToString(), Constants.CUSTOM_FIELD_TESTER_NAMES);
                            if (!string.IsNullOrEmpty(customFieldValue.Trim()))
                            {
                                customFieldValue = customFieldValue.Trim();
                                customFieldValue = customFieldValue.TrimEnd(';') + ";";
                            }
                            customFieldValue = testExecutionStatusModel.TesterName + ";" + customFieldValue;
                            customFields.Add(Constants.CUSTOM_FIELD_TESTER_NAMES, customFieldValue);
                            var customStatus = proxy.UpdateTestCaseCustomFieldDesignValue(extid, testCaseFromTestPlan.version, testProject.id.ToString(), customFields);
                            generalResult.status = true;
                            generalResult.message = userDetails.Login;
                            generalResult.id = testLinkResult.id;
                        }
                        else
                        {
                            generalResult.status = false;
                            generalResult.message = Resources.Resource.UnableToSaveExcecutionStatus;
                        }
                    }
                    else
                    {
                        generalResult.status = false;
                        generalResult.message = "Cannot retrieve the test case ID: " + testExecutionStatus.TestCaseID + " from test plan: " + "TMFTestPlan";
                    }
                /* EL5873 mod END Modification for build settings */
                }
                else
                {
                    generalResult.status = false;
                    generalResult.message = Resources.Resource.TestplanNotFound;
                }
            }
            else
            {
                generalResult.status = false;
                generalResult.message = "User: " + testExecutionStatus.TesterName + " not found.";
            }
            var ts = proxy.GetTestSuitesForTestPlan(testExecutionStatusModel.TestPlanID);
            if (ts.Count > 0)
                UpdateLastUpdateTime(ts.ToList().OrderByDescending(m => m.id).FirstOrDefault().id);
            return generalResult;
        }

        /// <summary>
        /// method to link tc with bug
        /// </summary>
        /// <param name="extid">external id</param>
        /// <param name="version">version</param>
        /// <param name="testProjectId">testProjectId</param>
        /// <param name="bugId">bugId</param>
        /// <param name="token">token</param>
        /// <param name="testPlanId">testPlan Id</param>
        /// <returns>true or false</returns>
        /// 2018/01/17, Sujith A , Initial Version
        /// 2019/01/17, Sharon Thankachan, VJP192_Modification for attach multiple bugs in TC
        public bool LinkTestCaseWithBug(string extid, int version, int testProjectId, int bugId, string token, int testPlanId)
        {
            /*VJP192_Modification for attach multiple bugs in TC START*/
            var proxy = ConnectTestLink(token);
            string attachedBugs = proxy.GetTestCaseCustomFieldDesignValue(extid, version, testProjectId.ToString(), Constants.CUSTOM_FIELD_BUGID);
            if (!string.IsNullOrWhiteSpace(attachedBugs))
            {
                attachedBugs = string.Join(";", attachedBugs, bugId.ToString());
            }
            else
            {
                attachedBugs = bugId.ToString();
            }
            Dictionary<string, string> customFields = new Dictionary<string, string>();
            customFields.Add(Constants.CUSTOM_FIELD_BUGID, attachedBugs);
            /*VJP192_Modification for attach multiple bugs in TC END*/
            proxy.UpdateTestCaseCustomFieldDesignValue(extid, version, testProjectId.ToString(), customFields);
            var ts = proxy.GetTestSuitesForTestPlan(testPlanId);
            if (ts.Count > 0)
                UpdateLastUpdateTime(ts.ToList().OrderByDescending(m => m.id).FirstOrDefault().id);
            return true;
        }

        /// <summary>
        /// Method to Delete linked bugs from test case
        /// </summary>
        /// <param name="extId">external id</param>
        /// <param name="versionID">version id</param>
        /// <param name="projectId">project id</param>
        /// <param name="token">token id</param>
        /// <param name="bugId">bug Id</param>
        /// <returns>status</returns>
        /// 2018/01/17, Sujith A , Initial Version
        /// 2019/01/17, Sharon Thankachan, VJP192_Modification for attach multiple bugs in TC
        public bool DeleteLinkedBugFromTestCase(string extId, int versionID, string projectId, string token, string bugId)
        {
            /*VJP192_Modification for attach multiple bugs in TC START*/
            string attachedBugs = ConnectTestLink(token).GetTestCaseCustomFieldDesignValue(extId, versionID, projectId, Constants.CUSTOM_FIELD_BUGID);
            if (!string.IsNullOrWhiteSpace(attachedBugs))
            {
                var bugList = attachedBugs.Split(';').ToList();
                bugList.Remove(bugId);
                attachedBugs = string.Join(";", bugList);
            }
            else
                attachedBugs = string.Empty;

            Dictionary<string, string> customFields = new Dictionary<string, string>();
            customFields.Add(Constants.CUSTOM_FIELD_BUGID, attachedBugs);
            /*VJP192_Modification for attach multiple bugs in TC END*/
            var status = ConnectTestLink(token).UpdateTestCaseCustomFieldDesignValue(extId, versionID, projectId.ToString(), customFields);
            return status.Length == 0;
        }

        /// <summary>
        /// Method to retrieve document details
        /// </summary>
        /// <param name="productName">Name of product</param>
        /// <param name="versionName">Name of version</param>
        /// <param name="moduleName">name of module</param>
        /// <returns>return document details</returns>
        public List<DocumentModel> GetDocumentDetails(string productName, string versionName, string moduleName)
        {
            TLRepository repo = new TLRepository();
            var pp = repo.GetDocumentDetails(productName, versionName, moduleName);
            var models = new List<DocumentModel>();
            foreach (var doc in pp)
            {
                models.Add(ConvertToModelObject(doc));
            }
            return models;
        }


        /// <summary>
        /// Method to Get tas projects
        /// </summary>
        /// <param name="machineName">name of the machine</param>
        /// <returns>list of projects</returns>
        /// 2018/10/23, Praveen M P , V29627_Initial version
        public List<SelectListItemHelper> GetTasProjects(string machineName)
        {
            List<SelectListItemHelper> list = new List<SelectListItemHelper>();
            if (String.IsNullOrEmpty(machineName) == false)
            {
                List<string> projectList = new List<string>();
                IAutoStartService client = ConnectToService(machineName);
                try
                {
                    var task = Task.Run(() => client.GetProjects());
                    if (task.Wait(TimeSpan.FromSeconds(6)))
                    {
                        projectList = task.Result;
                        foreach (string str in projectList)
                        {
                            list.Add(new SelectListItemHelper { Text = str, Value = str });
                        }
                    }
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                }
            }
            return list;
        }

        /// <summary>
        /// Method to Get tas projects
        /// </summary>
        /// <param name="machineName">name of the machine</param>
        /// <param name="projectName">name of the project</param>
        /// <returns>list of projects</returns>
        /// 2018/10/23, Praveen M P , V29627_Initial version
        public List<SelectListItemHelper> GetMainScenarios(string machineName, string projectName)
        {
            List<SelectListItemHelper> list = new List<SelectListItemHelper>();
            List<string> projectList = new List<string>();
            IAutoStartService client = ConnectToService(machineName);
            try
            {
                var task = Task.Run(() => client.GetMainScenarios(projectName));
                if (task.Wait(TimeSpan.FromSeconds(2)))
                {
                    projectList = task.Result;
                    foreach (string str in projectList)
                    {
                        list.Add(new SelectListItemHelper { Text = str, Value = str });
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return list;
        }

        /// <summary>
        /// Method to Get tas sub scenario list
        /// </summary>
        /// <param name="machineName">name of the machine</param>
        /// <param name="projectName">name of the project</param>
        /// <param name="mainScenario">main scenario name</param>
        /// <returns>List of sub scenarios</returns>
        /// 2018/10/23, Praveen M P , V29627_Initial version
        public List<SelectListItemHelper> GetSubScenarios(string machineName, string projectName, string mainScenario)
        {
            List<SelectListItemHelper> list = new List<SelectListItemHelper>();
            List<string> projectList = new List<string>();
            IAutoStartService client = ConnectToService(machineName);
            try
            {
                var task = Task.Run(() => client.GetSubScenarios(mainScenario, projectName));
                if (task.Wait(TimeSpan.FromSeconds(2)))
                {
                    projectList = task.Result;
                    foreach (string str in projectList)
                    {
                        list.Add(new SelectListItemHelper { Text = str, Value = str });
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return list;
        }

        /// <summary>
        /// Method to get queue status
        /// </summary>
        /// <param name="testCaseIds">test case ids</param>
        /// <param name="testPlanId">test plan id</param>
        /// <param name="product">product name</param>
        /// <param name="version">version name</param>
        /// <param name="token">token</param>
        /// <returns>list of jobs in queue</returns>
        /// 2018/10/17, Praveen M P , V29627_Initial version
        /// 2019/01/11, Sharon Thankachan, VJP192_Modification for automated run of TCs
        /// 2019/06/06, Vinoth N, WG3736_Modification for load jenkins and TAS machine details
        public List<AutoExecutionStatusModel> GetJobQueueStatus(string testCaseIds, string testPlanId, string product, string version, string token)
        {
            TMFLogger.LogMethodEntry();
            List<AutoExecutionStatusModel> list = new List<AutoExecutionStatusModel>();
            JenkinsClient client = new JenkinsClient();
            List<TestCaseDetailModel> listTcDetails = new List<TestCaseDetailModel>();
            var repo = new RMUserRepository();
            var loginName = repo.GetLogin(token);
            /* WG3736 mod START Modification for import data from configuration*/
            var jenkinModel = new JenkinsConfigurationModel();
            jenkinModel = GetConfigurationData();

            try
            {
                client.BaseUrl = jenkinModel.JenkinsURL;
                client.UserName = jenkinModel.Username;
                client.ApiToken = jenkinModel.APIKey;
                /*VJP192_Modification for automated run of TCs START*/
                listTcDetails = GroupTestCaseByNode(testCaseIds, testPlanId, product, version, token, new string[0], string.Empty, false);
                List<TASMachineModel> allmachines = new List<TASMachineModel>();
                allmachines = GetAllMachines();
                var machineNames = (from name in allmachines select name.MachineName).ToList();
                List<string> runningJobs = GetRunningJobList(jenkinModel.JenkinsURL);
                List<string> busyNodes = new List<string>();
                foreach (string job in runningJobs)
                {
                    busyNodes.Add(GetNodeFromJob(job));
                }
                foreach (TestCaseDetailModel tc in listTcDetails)
                {

                    bool exists = CheckNodeExists(jenkinModel.JenkinsURL, tc.MachineName);
                    /* WG3736 mod END Modification for import data from configuration*/
                    if (!tc.AssignedTo.Equals(loginName) && tc.ExnType)
                    {
                        list.Add(new AutoExecutionStatusModel { Id = tc.TCMId != string.Empty ? Convert.ToInt32(tc.TCMId) : 0, Name = tc.Title, Value = string.Empty, Status = "UnAssigned", Node = tc.MachineName, ExcludeTcId = tc.ID });
                    }
                    else if (tc.ExnType && (string.IsNullOrWhiteSpace(tc.ProjectName) || string.IsNullOrWhiteSpace(tc.MainScenarioName) || string.IsNullOrWhiteSpace(tc.SubScenario)))
                    {
                        list.Add(new AutoExecutionStatusModel { Id = tc.TCMId != string.Empty ? Convert.ToInt32(tc.TCMId) : 0, Name = tc.Title, Value = string.Empty, Status = "Missing", Node = tc.MachineName, ExcludeTcId = tc.ID });
                    }
                    else if ((string.IsNullOrWhiteSpace(tc.MachineName) || !machineNames.Contains(tc.MachineName)) && tc.ExnType)
                    {
                        list.Add(new AutoExecutionStatusModel { Id = tc.TCMId != string.Empty ? Convert.ToInt32(tc.TCMId) : 0, Name = tc.Title, Value = string.Empty, Status = "NotFound", Node = tc.MachineName, ExcludeTcId = tc.ID });
                    }
                    else if (!exists && tc.ExnType)
                    {
                        list.Add(new AutoExecutionStatusModel { Id = tc.TCMId != string.Empty ? Convert.ToInt32(tc.TCMId) : 0, Name = tc.Title, Value = string.Empty, Status = "NoNode", Node = tc.MachineName, ExcludeTcId = tc.ID });
                    }
                    /*VJP192_Modification for automated run of TCs END*/
                    else if (!tc.ExnType)
                    {
                        list.Add(new AutoExecutionStatusModel { Id = tc.TCMId != string.Empty ? Convert.ToInt32(tc.TCMId) : 0, Name = tc.Title, Value = string.Empty, Status = "0", Node = tc.MachineName, ExcludeTcId = tc.ID });
                    }
                    else if (tc.ExnType)
                    {
                        if (busyNodes.Contains(tc.MachineName))
                        {
                            list.Add(new AutoExecutionStatusModel { Id = Convert.ToInt32(tc.TCMId), Name = tc.Title, Value = string.Empty, Status = "Queued", Node = tc.MachineName });
                        }
                        else
                        {
                            list.Add(new AutoExecutionStatusModel { Id = Convert.ToInt32(tc.TCMId), Name = tc.Title, Value = string.Empty, Status = "1", Node = tc.MachineName });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                list.Clear();
                list.Add(new AutoExecutionStatusModel { Id = 0, Name = Resources.Resource.CheckJenkins, Value = string.Empty, Status = "Error", });
                TMFLogger.LogException(ex);
            }
            TMFLogger.LogMethodExit();
            return list;
        }

        /// <summary>
        /// Method to run Test cases
        /// </summary>
        /// <param name="testCaseIds">test case ids</param>
        /// <param name="testPlanId">test plan id</param>
        /// <param name="product">product</param>
        /// <param name="version">version</param>
        /// <param name="token">api token</param>
        /// <param name="applyToAll">if machine name apply to all tc's</param>
        /// <param name="username">current logged in username</param>
        /// <param name="excludeTcids">exclude Tcids</param>
        /// <param name="notConfiguredTCids">not Configured TCids</param>
        /// <param name="alternateNode">alternate Node</param>
        /// <param name="scheduledExnValue">scheduled Exn Value</param>
        /// <param name="scheduledExnType">scheduled Exn Type</param>
        /// <returns>result</returns>
        /// 2018/10/17, Praveen M P , V29627_Initial version
        /// 2019/01/11, Sharon Thankachan, VJP192_Modification for automated run of TCs
        /// 2019/01/31, Sharon Thankachan, VJP192_Modification for scheduling job
        /// 2019/06/06, Vinoth N, WG3736_Modification for get jenkins details from configuration file
        public string RunTestCases(string testCaseIds, string testPlanId, string product, string version, string token, string excludeTcids,
            string notConfiguredTCids, string alternateNode, bool applyToAll, string username, string scheduledExnValue, string scheduledExnType)
        {
            TMFLogger.LogMethodEntry();
            string result = string.Empty; ;
            string assignedNode = string.Empty;
            string tasgentParam = string.Empty;
            string jobName = string.Empty;
            var client = new JenkinsClient();
            JenkinsProject conf = null;
            var listTcDetails = new List<TestCaseDetailModel>();
            string[] testplanIds = testPlanId.Split(',');
            string[] excludeTcs = excludeTcids.Split(',');
            /*VJP192_Modification for automated run of TCs START*/
            string[] notConfiguredTCs = notConfiguredTCids.Trim().TrimEnd(',').Split(',');
            TMFLogger.LogInformation("Alternate Node: " + alternateNode);
            listTcDetails = GroupTestCaseByNode(testCaseIds, testPlanId, product, version, token, notConfiguredTCs, alternateNode, applyToAll);
            /*VJP192_Modification for automated run of TCs END*/
            if (listTcDetails.Count > 0)
            {
                var repo = new RMUserRepository();
                var loginName = repo.GetLogin(token);
                UserDetailsModel model = new AccountManager().GetUserDetails(loginName);
                var mailAddress = model.Email;

                /*VJP192_Modification for scheduling job START*/
                var groupedTcs = from grp in listTcDetails
                                 where grp.MachineName != string.Empty
                                 group grp by new
                                 {
                                     grp.MachineName
                                 };
                TMFLogger.LogInformation("Run Group Count: " + groupedTcs.Count());
                foreach (var groupItem in groupedTcs)
                {
                    List<TestCaseDetailModel> testcase = (from tcs in groupItem
                                                          select tcs).ToList();
                    string tcParams = string.Empty;
                    foreach (TestCaseDetailModel singleTc in testcase)
                    {
                        bool has = excludeTcs.Any(cus => cus == singleTc.ID);
                        if (!has)
                        {
                            tcParams = tcParams + (string.Format("{0},", singleTc.ID));
                        }
                    }

                    var task = Task.Run(() => GetTasAgentLocation(groupItem.Key.MachineName));
                    if (task.Wait(TimeSpan.FromSeconds(10)))
                    {
                        tasgentParam = string.Format("{0} {1} \"{2}\" \"{3}\" {4} {5} {6} \"{7}\"", task.Result, "TMF", product, version, tcParams, testplanIds[0], username, mailAddress);
                    }
                    else
                        return "Can't connect to TAS AutoStartService";
                    /* WG3736 mod START Modification for import data from configuration*/
                    var jenkinModel = new JenkinsConfigurationModel();
                    jenkinModel = GetConfigurationData();
                    string BuildInterval = scheduledExnValue;
                    if (String.IsNullOrEmpty(BuildInterval) == false)
                    {
                        if (scheduledExnType == "0")
                        {
                            DateTime dt = Convert.ToDateTime(BuildInterval);
                            int Hour = (dt.Hour <= 12) ? (dt.Hour + 12) : dt.Hour;
                            BuildInterval = string.Format("{0} {1} {2} {3} *", dt.Minute, Hour, dt.Day, dt.Month);
                        }
                        else if (scheduledExnType == "2")
                        {
                            string[] dates = BuildInterval.Split(',');
                            if (dates[2] == "1")
                            {
                                BuildInterval = GetDailyPeriodicExecutionData(dates);
                            }
                            else
                            {
                                var time = dates[3].Split(':');
                                var days = dates[4].Replace(':', ',');
                                BuildInterval = time[1] + " " + time[0] + " * * " + days;
                                BuildInterval = BuildInterval.Remove(BuildInterval.Length - 1, 1);
                            }
                        }
                        else
                        {
                            string[] spltVal = BuildInterval.Split(',');
                            if (spltVal[1].Trim() == "0")
                            {
                                BuildInterval = string.Format("*/{0} * * * *", spltVal[0]);
                            }
                            else
                            {
                                BuildInterval = string.Format("{0} */{1} * * *", spltVal[0].Trim(), spltVal[1].Trim());
                            }
                        }
                    }
                    try
                    {
                        client.BaseUrl = jenkinModel.JenkinsURL;
                        client.UserName = jenkinModel.Username;
                        client.ApiToken = jenkinModel.APIKey;
                        string xmlString = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\JobConfig.xml");
                        XDocument xdocc = XDocument.Parse(xmlString);
                        XNode xnode = xdocc.FirstNode;
                        conf = new JenkinsProject(xnode);
                        XDocument xdoc = conf.Node.Document;
                        var node = xdoc.Root.Descendants("canRoam").FirstOrDefault();
                        node.Value = "false";
                        node = xdoc.Root.Descendants("assignedNode").FirstOrDefault();
                        node.Value = groupItem.Key.MachineName;
                        node = xdoc.Root.Descendants("command").FirstOrDefault();
                        node.Value = tasgentParam;
                        node = xdoc.Root.Descendants("spec").FirstOrDefault();
                        node.Value = BuildInterval;
                        var emailNode = xdoc.Root.Descendants("recipientList").FirstOrDefault();
                        emailNode.Value = mailAddress;
                        jobName = string.Format("{0}_{1}_{2}_{3}_{4}", product, version, groupItem.Key.MachineName, "", DateTime.Now.ToString("ddMMMyyyy_tthhmmssfff"));
                        /*VJP192_Modification for scheduling job END*/
                        var task2 = Task.Run(() => client.Jobs.CreateAsync(jobName, conf));
                        if (String.IsNullOrEmpty(BuildInterval) == true)
                        {
                            if (task2.Wait(TimeSpan.FromSeconds(10)))
                            {
                                JenkinsBuildResult res = client.Jobs.Build(jobName);
                            }
                        }

                    }
                    catch (JenkinsNetException jex)
                    {
                        TMFLogger.LogError(jex.Message);
                    }
                    TMFLogger.LogDebug("-------BUILD START/QUEUE-------");
                    TMFLogger.LogDebug("jobname: " + jobName);

                    List<string> jobs = GetRunningJobList(jenkinModel.JenkinsURL);
                    TMFLogger.LogDebug("running job count: " + jobs.Count);
                    foreach (var item in jobs)
                    {
                        TMFLogger.LogDebug("jobname: " + item);
                    }
                    /* WG3736 mod END Modification for import data from configuration*/
                    bool exist = jobs.Any(cus => cus == jobName);
                    TMFLogger.LogDebug("job exist and running : " + exist.ToString());

                    if (!exist && jobs.Count > 0)
                    {
                        result = Resources.Resource.BuildQueued;
                        TMFLogger.LogDebug("result : BuildQueued");
                    }
                    else
                    {
                        result = Resources.Resource.BuildStarted;
                        TMFLogger.LogDebug("result : BuildStarted");
                    }
                }
            }
            TMFLogger.LogMethodExit();

            return result;
        }

        /// 2019/01/21, Sujith A ,VJP192
        /// <summary>
        /// Method to retrieve document display content
        /// </summary>
        /// <param name="productName">Selected product name</param>
        /// <param name="versionName">Selected version name</param>
        /// <param name="moduleName">Selected module name</param>
        /// <param name="documentName">Selected document name</param>
        /// <param name="token">User token</param>
        /// <param name="path">document path</param>
        /// <returns>Returns the html file path</returns>
        public string DisplayDocument(string productName, string versionName, string moduleName, string documentName, string token, string path)
        {
            IF2THandler f2tHandler = new F2THandler();
            string htmlFile = f2tHandler.ConvertToHtml(productName, versionName, moduleName, documentName, path);

            return htmlFile;
        }

        /// <summary>
        /// Method to retrieve document suite id
        /// </summary>
        /// <param name="token">Token</param>
        /// <param name="productName">Product name.</param>
        /// <param name="versionName">Version name.</param>
        /// <param name="moduleName">Module name.</param>
        /// <param name="documentName">Document name.</param>
        /// <returns>Returns document suite id</returns>
        /// 2020/10/29, Vinoth N, CRC207_Initial Version
        public int GetDocumentSuiteID(string token, string productName, string versionName, string moduleName, string documentName)
        {
            APIHelper apiHelper = new APIHelper();
            RMUserRepository rmRepository = new RMUserRepository();
            TLUserRepository tlRepository = new TLUserRepository();
            string login = rmRepository.GetLogin(token);
            string apiKey = tlRepository.GetApiKey(login);
            var docSuiteID = apiHelper.GetDocumentSuiteID(apiKey, productName, versionName, moduleName, documentName);
            return docSuiteID;
        }

        /// <summary>
        /// Method to copy paste test cases
        /// </summary>
        /// <param name="userName">Name of the logged in user</param>
        /// <param name="testcaseIds">Selected test case ids</param>
        /// <param name="testPlanName">Name of the test plan</param>
        /// <param name="testSuiteId">Selected test suite id</param>
        /// <param name="token">Logged in user token</param>
        /// <returns>Returns list of test case pasted</returns>
        /// 2019/01/22, Sujith A ,VJP192- Initial version for copy test cases
        public GeneralResultModel CopyTestcase(string userName, string testcaseIds, string testPlanName, string testSuiteId, string token)
        {
            GeneralResultModel model = new GeneralResultModel();
            model.message = Resources.Resource.TCCopyFaild;
            List<TestCaseSummaryModel> testCaseList = new List<TestCaseSummaryModel>();
            try
            {
                TLRepository repository = new TLRepository();
                string[] ids = testcaseIds.Split(',');
                int testcaseId = 0;
                int tsId = 0;
                int.TryParse(testSuiteId, out tsId);
                int testPlanId = 0;
                string prefix = "";
                testPlanName = testPlanName.Replace("&", "&amp;");
                testPlanId = repository.GetTestPlanIdFromName(testPlanName);
                int pjtId = repository.GetProjectId(testPlanId, out testPlanName, out prefix);
                int tcmId = repository.GetTCMIDMaxValue(tsId);
                var proxy = ConnectTestLink(token);
                foreach (var id in ids)
                {
                    tcmId++;
                    int.TryParse(id, out testcaseId);
                    var testCase = proxy.GetTestCase(testcaseId);
                    var cFields = repository.GetAllCustomFieldValues(testcaseId);
                    cFields[Constants.CUSTOM_FIELD_TCMID] = tcmId.ToString();
                    cFields[Constants.CUSTOM_FIELD_TESTER_NAMES] = string.Empty;
                    cFields[Constants.CUSTOM_FIELD_BUGID] = string.Empty;
                    if (testCase?.testsuite_id != tsId)
                    {
                        cFields[Constants.CUSTOM_FIELD_SECTION] = string.Empty;
                        cFields[Constants.CUSTOM_FIELD_SENTENCE] = string.Empty;
                    }
                    string tcName = testCase.name.Remove(testCase.name.LastIndexOf("_")) + "_" + tcmId;
                    var atts = proxy.GetTestCaseAttachments(testcaseId);
                    string actions = testCase.steps[0].actions;
                    string expected_results = testCase.steps[0].expected_results;

                    var testLinkResult = proxy.CreateTestCase(userName, tsId, tcName, pjtId, testCase.summary, new TestStep[0],
                        testCase.preconditions, "", testCase.node_order, false, ActionOnDuplicatedName.GenerateNew,
                        testCase.execution_type, testCase.importance);
                    if (testLinkResult.status)
                    {
                        if (testLinkResult.id > 0)
                        {
                            if (atts.Count > 0)
                            {
                                foreach (var item in atts)
                                {
                                    string newAttName = Guid.NewGuid().ToString();
                                    if (item.name.Contains("."))
                                    {
                                        newAttName += item.name.Substring(item.name.LastIndexOf("."));
                                    }
                                    actions = actions.Replace(item.name, newAttName);
                                    expected_results = expected_results.Replace(item.name, newAttName);
                                    var attachmentResult = proxy.UploadTestCaseAttachment(testLinkResult.id, newAttName,
                                        item.file_type, item.content, item.title, "");
                                    var filePath = AppDomain.CurrentDomain.BaseDirectory + @"\Uploads\TCAttachments\";
                                    if (File.Exists(filePath + "\\" + item.name))
                                    {
                                        File.Copy(filePath + "\\" + item.name, filePath + "\\" + newAttName);
                                    }
                                }
                            }
                            TestStep[] steps = new TestStep[testCase.steps.Count];
                            steps[0] = new TestStep(1, actions, expected_results, true, testCase.steps[0].execution_type);
                            testLinkResult.message = testPlanId.ToString();
                            string extid = string.Format("{0}-{1}", prefix, testLinkResult.additionalInfo.external_id);
                            proxy.createTestCaseSteps(extid, testLinkResult.id.ToString(), "1", steps);
                            proxy.UpdateTestCaseCustomFieldDesignValue(extid, testLinkResult.additionalInfo.version_number,
                                pjtId.ToString(), cFields);
                            proxy.addTestCaseToTestPlan(pjtId, testPlanId, extid,
                                testLinkResult.additionalInfo.version_number);
                        }
                        else
                        {
                            testLinkResult.status = false;
                            testLinkResult.message = testLinkResult.additionalInfo.msg;
                        }
                        testCaseList.Add(new TestCaseSummaryModel
                        {
                            TCId = Convert.ToInt32(testLinkResult.id),
                            Name = testCase.name,
                            TestExecutionStatus = "",
                            Title = testCase.summary,
                            TestExecutionDate = DateTime.MinValue,
                            TestPlanName = testPlanName,
                            TCExternalID = Convert.ToInt32(testLinkResult.additionalInfo.external_id),
                            TestPlanID = testPlanId,
                            TCMId = tcmId.ToString()
                        });
                    }
                }
                model.message = Resources.Resource.TCCopySuccess;
                model.status = true;
                UpdateLastUpdateTime(tsId);
            }
            catch (Exception ex)
            {
                model.message = Resources.Resource.TCCopyOneorMoreFaild;
                TMFLogger.LogException(ex);
            }
            return model;
        }

        /// <summary>
        /// Get active machines from the given list of machines
        /// </summary>
        /// <param name="machineNames">list of machines</param>
        /// <returns>list of active machines</returns>
        /// 2019/01/11, Sharon Thankachan, VJP192_Initial Version
        /// 2019/06/06, Vinoth N, WG3736_Modification for get jenkins details from configuration file
        public List<string> GetActiveMachines(string[] machineNames)
        {
            List<string> activeMachines = new List<string>();
            /* WG3736 mod START Modification for import data from configuration*/
            var jenkinModel = new JenkinsConfigurationModel();
            jenkinModel = GetConfigurationData();
            foreach (var machine in machineNames)
            {
                if (!string.IsNullOrWhiteSpace(machine) && CheckNodeExists(jenkinModel.JenkinsURL, machine))
                {
                    activeMachines.Add(machine);
                }
            }
            /* WG3736 mod END Modification for import data from configuration*/
            return activeMachines;
        }

        /// <summary>
        /// Sends mail to the assigned user
        /// </summary>
        /// <param name="userName">Username of assigned user</param>
        /// <param name="tcIds">tc ids and test plan ids</param>
        /// <param name="testCaseBaseURL">test case base url</param>
        /// <param name="moduleId">moduleId from redmine</param>
        /// 2019/01/11, Sharon Thankachan, VJP192_Initial Version
        /// 2019/05/31, Vinoth N, WG3736_Modification for mail subject
        /// 2021/02/16, Sharon Thanakchan, DMG213_Modification for Power Automate
        public void SendNotificationMail(string userName, Dictionary<int, int> tcIds, string testCaseBaseURL, string moduleId)
        {
            try
            {
                /* WG3736 mod START Modification for mail subject */
                RMRepository rmRepo = new RMRepository();
                string mailAddress = rmRepo.GetUserProfile(userName, out string name, out string language);
                testCaseBaseURL = ConfigurationManager.AppSettings["TestcaseURL"];
                if (mailAddress != string.Empty)
                {
                    /* DMG213 mod START Modification for email notification enhancement*/
                    EmailManager emailManager = new EmailManager();
                    IAdministrationManager adminManager = new AdministrationManager();
                    ConfigurationModel configModel = new ConfigurationModel();
                    configModel = adminManager.GetConfigurationData();
                    if (configModel.EmailConfiguration.UseSMTP)
                    {
                        emailManager.SendMail(mailAddress, "TMF - Test cases assigned", GenerateMailContent(tcIds, moduleId, testCaseBaseURL, name, language), String.Empty, true, false);
                    }
                    else
                    {
                        emailManager.SendMailWithPowerAutomate(mailAddress, EmailCategory.TestcaseAssigned, GenerateMailContent(tcIds, moduleId, testCaseBaseURL, name, language, true));
                    }
                    /* DMG213 mod END Modification for email notification enhancement*/
                }
                /* WG3736 mod END Modification for mail subject */
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
        }

        /// <summary>
        /// Method to get chart and report data for test case
        /// </summary>
        /// <param name="filterData">filter data</param>
        /// <returns>Data for chart and reports of test case</returns>
        /// 2019/06/26, Sharon Thankachan, WG3736_Initial Version
        /* WG3736 new START Chart and reports*/
        public TestCaseChartReportModel GetTestCaseChartData(ReportFilterModel filterData)
        {
            TMFLogger.LogMethodEntry();
            TestCaseChartReportModel model = new TestCaseChartReportModel();
            try
            {
                ReportFilter filter = new ReportFilter { ProjectName = filterData.ProjectName, VersionName = filterData.VersionName, ModuleName = filterData.ModuleName, DocumentName = filterData.DocumentName, FromDate = filterData.FromDate, ToDate = filterData.ToDate };
                TLRepository tlRepo = new TLRepository();
                DataSet reportData = tlRepo.GetTestCaseChartData(filter);
                if (reportData != null && reportData.Tables.Count > 0)
                {
                    SortedDictionary<string, int> keyValuePair = new SortedDictionary<string, int>();
                    #region PieChartByTcStatus
                    model.TestCasePieChart = GenerateTestCaseByStatusData(reportData.Tables[0]);

                    #endregion

                    #region PieChartAutomated
                    model.TestCaseAutomatedPieChart = GenerateTestCaseByStatusData(reportData.Tables[1]);
                    #endregion

                    #region PieChartManual
                    model.TestCaseManualPieChart = GenerateTestCaseByStatusData(reportData.Tables[2]);
                    #endregion

                    #region TcCreatedMonthly
                    Dictionary<string, int> keyValuePairBar = new Dictionary<string, int>();
                    model.TestCaseBarMonthlyChart = GenerateTestCaseChartData(reportData.Tables[3], out keyValuePairBar);
                    int total = 0;
                    var runningTotals = model.TestCaseBarMonthlyChart.Data.Select(x => total += x).ToArray();
                    model.TotalTestCaseBarMonthlyChart = new ChartModel { Label = keyValuePairBar.Keys.ToArray(), Data = runningTotals };
                    #endregion

                    #region TcCreatedWeekly
                    keyValuePairBar = new Dictionary<string, int>();
                    model.TestCaseBarWeeklyChart = GenerateTestCaseWeeklyData(reportData.Tables[4], out keyValuePairBar);
                    total = 0;
                    runningTotals = model.TestCaseBarWeeklyChart.Data.Select(x => total += x).ToArray();
                    model.TotalTestCaseBarWeeklyChart = new ChartModel { Label = keyValuePairBar.Keys.ToArray(), Data = runningTotals };
                    #endregion

                    #region TcCreatedDaily
                    keyValuePairBar = new Dictionary<string, int>();
                    model.TestCaseBarDailyChart = GenerateTestCaseChartData(reportData.Tables[5], out keyValuePairBar);
                    total = 0;
                    runningTotals = model.TestCaseBarDailyChart.Data.Select(x => total += x).ToArray();
                    model.TotalTestCaseBarDailyChart = new ChartModel { Label = keyValuePairBar.Keys.ToArray(), Data = runningTotals };
                    #endregion

                    #region TabularReport
                    model.TestCaseTabularReport = GenerateTestCaseTabularData(reportData.Tables[6]);
                    #endregion

                    for (int i = 0; i < model.TestCasePieChart.Data.Length; i++)
                    {
                        model.TestCasePieChart.Label[i] = model.TestCasePieChart.Label[i] + " - " + model.TestCasePieChart.Data[i];
                    }
                    for (int i = 0; i < model.TestCaseAutomatedPieChart.Data.Length; i++)
                    {
                        model.TestCaseAutomatedPieChart.Label[i] = model.TestCaseAutomatedPieChart.Label[i] + " - " + model.TestCaseAutomatedPieChart.Data[i];
                    }
                    for (int i = 0; i < model.TestCaseManualPieChart.Data.Length; i++)
                    {
                        model.TestCaseManualPieChart.Label[i] = model.TestCaseManualPieChart.Label[i] + " - " + model.TestCaseManualPieChart.Data[i];
                    }
                }
                else
                    model = new TestCaseChartReportModel();
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            TMFLogger.LogMethodExit();
            return model;
        }
        /* WG3736 new END Chart and reports*/

        /// <summary>
        /// Generate excel report for charts 
        /// </summary>
        /// <param name="tcExcelData">excel data for tc</param>
        /// <param name="bugExcelData">excel data for bug</param>
        /// <param name="filter">filter data</param>
        /// <returns>file name of created excel</returns>
        /// 2019/06/26, Sharon Thankachan, WG3736_Initial Version
        /* WG3736 new START Chart and reports*/
        public string GenerateExcelFile(TestCaseChartReportExcelModel tcExcelData, BugChartReportExcelModel bugExcelData, ReportFilterModel filterData)
        {
            TMFLogger.LogMethodEntry();
            ChartReportExcel tcData = new ChartReportExcel { ChartImageTitle = tcExcelData.ChartImageTitle, TabularData = ToDataTable(tcExcelData.TestCaseTabularData) };
            ChartReportExcel bugData = new ChartReportExcel { ChartImageTitle = bugExcelData.ChartImageTitle, TabularData = ToDataTable(bugExcelData.BugTabularData) };
            ReportFilter filter = new ReportFilter { ProjectName = filterData.ProjectName, VersionName = filterData.VersionName, ModuleName = filterData.ModuleName, DocumentName = filterData.DocumentName, FromDate = filterData.FromDate, ToDate = filterData.ToDate };
            IReportHandler reportHandle = new ReportHandler(System.Globalization.CultureInfo.CurrentCulture);
            string fileName = reportHandle.GenerateChartReport(tcData, bugData, filter);
            TMFLogger.LogMethodExit();
            return fileName;
        }
        /* WG3736 new END Chart and reports*/

        /// <summary>
        /// Method to convert list to datatable
        /// </summary>
        /// <typeparam name="T">list type</typeparam>
        /// <param name="items">list data</param>
        /// <returns>datatable</returns>
        /// 2019/06/26, Sharon Thankachan, WG3736_Initial Version
        /* WG3736 new START Chart and reports*/
        private System.Data.DataTable ToDataTable<T>(List<T> items)
        {
            System.Data.DataTable dataTable = new System.Data.DataTable(typeof(T).Name);
            if (items != null && items.Count > 0)
            {
                //Get all the properties
                PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo prop in Props)
                {
                    //Defining type of data column gives proper data table 
                    var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
                    //Setting column names as Property names
                    dataTable.Columns.Add(prop.Name, type);
                }
                foreach (T item in items)
                {
                    var values = new object[Props.Length];
                    for (int i = 0; i < Props.Length; i++)
                    {
                        //inserting property values to datatable rows
                        values[i] = Props[i].GetValue(item, null);
                    }
                    dataTable.Rows.Add(values);
                }
                //put a breakpoint here and check datatable
            }
            return dataTable;
        }
        /* WG3736 new START Chart and reports*/

        /// <summary>
        /// Method to update order number of all test cases
        /// </summary>
        /// <param name="testcases">Test cases with updated order number</param>
        /// <param name="testSuiteID">Test suiteId</param>
        /// <returns>Returns update status</returns>
        /// 2019/05/28, Sujith A, WG3736_Initial Version
        /* WG3736 new START Update tc order*/
        public GeneralResultModel UpdateTestCasesOrder(List<TestCaseDetailModel> testcases, string testSuiteID)
        {
            GeneralResultModel result = new GeneralResultModel();
            result.message = Resources.Resource.OrdernoUpdateFaild;
            try
            {
                TLRepository repo = new TLRepository();
                List<int> tcIds = testcases.Select(m => Convert.ToInt32(m.TestCaseVersionId)).ToList();
                List<int> orderNos = testcases.Select(m => Convert.ToInt32(m.OrderNo)).ToList();
                result.status = repo.UpdateTestcaseOrder(tcIds, orderNos);
                result.message = Resources.Resource.TCOrderNoUpdated;
                UpdateLastUpdateTime(Convert.ToInt32(testSuiteID));
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return result;
        }
        /* WG3736 new END Update tc order*/

        /// <summary>
        /// Method to retrieve all sections which contain test cases
        /// </summary>
        /// <param name="testSuiteId">Unique id of the test suite</param>
        /// <returns>Returns all the sections</returns>
        /// 2019/06/17, Sujith A, WG3736_Initial Version
        /* WG3736 new START Update tc order*/
        public List<string> GetAllSections(string testSuiteId)
        {
            List<string> sections = new List<string>();
            TLRepository repo = new TLRepository();
            sections = repo.GetAllSections(testSuiteId);
            return sections;
        }
        /* WG3736 new END Update tc order*/

        /// <summary>
        /// Method to search test cases with a text 
        /// </summary>
        /// <param name="testSuiteId">Unique id of the test suite</param>
        /// <param name="searchText">Text to find</param>
        /// <param name="lookIn">Fields to look in the search text</param>
        /// <param name="testType">Test type of the test case</param>
        /// <returns>Returns test cases</returns>
        /// 2019/06/19, Sujith A, WG3736_Initial Version
        /* WG3736 new START Update tc order*/
        public List<TestCaseDetailModel> SearchTestCaseText(int testSuiteId, string searchText, string lookIn, string testType)
        {
            List<TestCaseDetailModel> arr = new List<TestCaseDetailModel>();
            var tLProjectRepository = new TLRepository();
            try
            {
                List<DAL.Objects.TestCase> testCases = tLProjectRepository.SearchTestCaseText(testSuiteId, searchText, lookIn, testType);
                foreach (var val in testCases)
                {
                    arr.Add(new TestCaseDetailModel
                    {
                        ID = val.Id,
                        TCMId = val.TCMId,
                        Title = val.Summary,
                        TestPlanID = val.TestPlanId,
                        TestCaseVersionId = val.TestCaseVersionId,
                        TestType = val.TestType,
                    });
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return arr;
        }
        /* WG3736 new END Update tc order*/

        /// <summary>
        /// Method to update replace text in test case 
        /// </summary>
        /// <param name="tcIds">Ids of the test cases</param>
        /// <param name="searchText">Text to find</param>
        /// <param name="replaceText">Text to replace</param>
        /// <param name="lookIn">Fields to look in the search text</param>
        /// <returns>Returns update status</returns>
        /// 2019/06/19, Sujith A, WG3736_Initial Version
        /* WG3736 new START Update tc text*/
        public GeneralResultModel UpdateTestCaseText(string[] tcIds, string searchText, string replaceText, string lookIn)
        {
            GeneralResultModel model = new GeneralResultModel();
            try
            {
                TLRepository repo = new TLRepository();
                var totalCount = repo.UpdateTestCaseText(tcIds, searchText, replaceText, lookIn);
                model.status = true;
                model.message = "Found " + totalCount + " occurrences of '" + searchText + "'. Replaced " + totalCount + " occurrences";
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                model.message = Resources.Resource.ReplaceTextFaild;
            }
            return model;
        }
        /* WG3736 new END Update tc text*/

        /// <summary>
        /// Method to update test type of a test case 
        /// </summary>
        /// <param name="tcIds">Ids of the test cases</param>
        /// <param name="testType">Test type to replace</param>
        /// <returns>Returns update status</returns>
        /// 2019/06/19, Sujith A, WG3736_Initial Version
        /* WG3736 new START Update tc type*/
        public GeneralResultModel UpdateTestType(string[] tcIds, string testType)
        {
            GeneralResultModel model = new GeneralResultModel();
            model.message = Resources.Resource.UpdateTestTypeFaild;
            try
            {
                TLRepository repo = new TLRepository();
                model.status = repo.UpdateTestType(tcIds, testType);
                if (model.status)
                {
                    model.message = "Updated Test Type of " + tcIds.Count() + " test cases";
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return model;
        }
        /* WG3736 new END Update tc type*/

        /// <summary>
        /// Method to get comment count
        /// </summary>
        /// <param name="filePath">F2T document path</param>
        /// <returns>Returns count</returns>
        /// 2020/07/25, Vinoth N, C51165_Initial version
        public int CommentCounter(string filePath)
        {
            F2THandler f2tHandler = new F2THandler();
            int count = f2tHandler.GetCommentCount(filePath);
            return count;
        }

        /// <summary>
        /// Method to get running jobs
        /// </summary>
        /// <param name="url">ur of jenkins</param>
        /// <returns>list of jobs</returns>
        /// 2018/10/17, Praveen M P , V29627_Initial version
        public List<string> GetRunningJobList(string url)
        {
            List<string> list = new List<string>();
            string apiUrl = string.Format("{0}/api/xml?tree=jobs[name,url,color]&xpath=/hudson/job[ends-with(color/text(),%22_anime%22)]&wrapper=jobs", url);
            Uri address = new Uri(apiUrl);
            HttpWebRequest request = WebRequest.Create(address) as HttpWebRequest;
            request.Method = "GET";
            request.ContentType = "text/xml";
            request.Timeout = 10000;
            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            {
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string strOutputXml = reader.ReadToEnd();
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(strOutputXml);
                XmlNodeList xnList = xml.SelectNodes("/jobs/job/name");
                foreach (XmlNode xn in xnList)
                {
                    list.Add(xn.InnerText);
                }
            }
            return list;
        }

        /// <summary>
        /// Method to get running node from job
        /// </summary>
        /// <param name="jobName">name of the job</param>
        /// <returns>node name</returns>
        /// 2018/10/17, Praveen M P , V29627_Initial version
        /// 2019/06/06, Vinoth N, WG3736_Modification for get jenkins details from configuration file
        public string GetNodeFromJob(string jobName)
        {
            string nodeName = string.Empty;
            var client = new JenkinsClient();
            /* WG3736 mod START Modification for import data from configuration*/
            var jenkinModel = new JenkinsConfigurationModel();
            jenkinModel = GetConfigurationData();
            try
            {
                client.BaseUrl = jenkinModel.JenkinsURL;
                client.UserName = jenkinModel.Username;
                client.ApiToken = jenkinModel.APIKey;
                /* WG3736 mod END Modification for import data from configuration*/
                JenkinsProject proj = client.Jobs.GetConfiguration(jobName);
                XDocument xdoc = proj.Node.Document;
                var node = xdoc.Root.Descendants("assignedNode").FirstOrDefault();
                if (node != null)
                {
                    nodeName = node.Value;
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return nodeName;
        }

        /// <summary>
        /// Method to create jenkin job for build settings
        /// </summary>
        /// <param name="buildSettings">Build settings input</param>
        /// <param name="token">User identification token</param>
        /// <returns>result</returns>
        /// 2021/06/14, Vinoth N, EL5873_Initial version
        public GeneralResultModel BuildTASProject(BuildSettingsModel buildSettings, string token)
        {
            TMFLogger.LogMethodEntry();
            GeneralResultModel result = new GeneralResultModel() { status = true};
            string tasgentParam = string.Empty;
            var client = new JenkinsClient();
            JenkinsProject conf = null;
            if (buildSettings != null)
            {
                var repo = new RMUserRepository();
                var loginName = repo.GetLogin(token);
                UserDetailsModel model = new AccountManager().GetUserDetails(loginName);
                var mailAddress = model.Email;
                var task = Task.Run(() => GetTasAgentLocation(buildSettings.TASMachine));
                if (task.Wait(TimeSpan.FromSeconds(10)))
                {
                    try
                    {
                        tasgentParam = string.Format("{0} {1} {2} {3} {4} {5} {6}", task.Result, "BUILD", "product", "version", buildSettings.TASProject, loginName, mailAddress);
                        string jobName = string.Format("{0}_{1}_{2}_{3}", buildSettings.TASMachine, buildSettings.ProductId, buildSettings.VersionId, buildSettings.TASProject);
                        var jenkinModel = new JenkinsConfigurationModel();
                        jenkinModel = GetConfigurationData();
                        List<string> jobs = GetRunningJobList(jenkinModel.JenkinsURL);
                        if (jobs.Any(cus => cus == jobName))
                        {
                            result.message = Resources.Resource.BuildQueued;
                            result.status = false;
                        }
                        else if (DeleteJenkinsJob(jenkinModel.JenkinsURL, jobName) == true)
                        {
                            string BuildInterval = string.Empty;
                            if (!string.IsNullOrEmpty(buildSettings.ScheduleTime) && buildSettings.ScheduleType > 0)
                            {
                                if (buildSettings.ScheduleType == 1)
                                {
                                    var time = buildSettings.ScheduleTime.Split(':');
                                    BuildInterval = time[1] + " " + time[0] + " * * *";
                                }
                                else if (buildSettings.ScheduleType == 2)
                                {
                                    var time = buildSettings.ScheduleTime.Split(':');
                                    BuildInterval = time[1] + " " + time[0] + " * * " + buildSettings.ScheduleDate;
                                }
                            }
                            client.BaseUrl = jenkinModel.JenkinsURL;
                            client.UserName = jenkinModel.Username;
                            client.ApiToken = jenkinModel.APIKey;
                            string xmlString = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\JobConfig.xml");
                            XDocument xdocc = XDocument.Parse(xmlString);
                            XNode xnode = xdocc.FirstNode;
                            conf = new JenkinsProject(xnode);
                            XDocument xdoc = conf.Node.Document;
                            var node = xdoc.Root.Descendants("canRoam").FirstOrDefault();
                            node.Value = "false";
                            node = xdoc.Root.Descendants("assignedNode").FirstOrDefault();
                            node.Value = buildSettings.TASMachine;
                            node = xdoc.Root.Descendants("command").FirstOrDefault();
                            node.Value = tasgentParam;
                            node = xdoc.Root.Descendants("spec").FirstOrDefault();
                            node.Value = BuildInterval;
                            var emailNode = xdoc.Root.Descendants("recipientList").FirstOrDefault();
                            emailNode.Value = mailAddress;
                            var task2 = Task.Run(() => client.Jobs.CreateAsync(jobName, conf));
                            if (string.IsNullOrEmpty(BuildInterval) == true)
                            {
                                if (task2.Wait(TimeSpan.FromSeconds(10)))
                                {
                                    JenkinsBuildResult res = client.Jobs.Build(jobName);
                                }
                            }
                            result.message = Resources.Resource.BuildStarted;
                        }                                              
                    }
                    catch (JenkinsNetException jex)
                    {
                        result.message = "Failed.";
                        result.status = false;
                                     if (ex is ArgumentOutOfRangeException)
                {
                    exceptionMessage = "Specified Index was out of range";
                }
                else if (ex is MissingMemberException)
                {
                    if (ex.Message.Contains("has no attribute"))
                    {
                        exceptionMessage = ex.Message.Substring(ex.Message.LastIndexOf(' ')) + " is an invalid command";
                    }
                }
                else if (ex is ArgumentTypeException)
                {
                    exceptionMessage = "Invalid argument(s) found: " + ex.Message;
                }
                else if (ex is Runtime.UnboundNameException)
                {
                    exceptionMessage = ex.Message;
                }
                else if (ex is SMLParserException || ex is InvalidCommandParameterException || ex is DirectoryNotFoundException ||
                    ex is OverflowException)
                {
                    exceptionMessage = ex.Message;
                    switch (exceptionMessage.ToUpper())
                    {
                        case "ARRAY":
                            dataType = TMFDataType.SecsII_Array;
                            break;
                        case "A":
                            dataType = TMFDataType.SecsII_ASCII;
                            break;
                        case "B":
                            dataType = TMFDataType.SecsII_Binary;
                            break;
                        case "BOOLEAN":
                            dataType = TMFDataType.SecsII_Bool;
                            break;
                        case "F4":
                            dataType = TMFDataType.SecsII_F4;
                            break;
                        case "F8":
                            dataType = TMFDataType.SecsII_F8;
                            break;
                        case "I1":
                            dataType = TMFDataType.SecsII_I1;
                            break;
                        case "I2":
                            dataType = TMFDataType.SecsII_I2;
                            break;
                        case "I4":
                            dataType = TMFDataType.SecsII_I4;
                            break;
                        case "I8":
                            dataType = TMFDataType.SecsII_I8;
                            break;
                        case "JIS8":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "LCS":
                            dataType = TMFDataType.SecsII_LCS;
                            break;
                        case "U1":
                            dataType = TMFDataType.SecsII_U1;
                            break;
                        case "U2":
                            dataType = TMFDataType.SecsII_U2;
                            break;
                        case "U4":
                            dataType = TMFDataType.SecsII_U4;
                            break;
                        case "U8":
                            dataType = TMFDataType.SecsII_U8;
                            break;
                        case "J":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "L":
                            dataType = TMFDataType.SecsII_List;
                            break;
                        default:
                            throw new SMLParserException("Invalid data type '" + msgType + "' found");
                    }
                }
                        TMFLogger.LogError(jex.Message);
                    }
                }
                else
                {
                    result.status = false;
                    result.message = "Can't connect to TAS AutoStartService";
                }
            }
            TMFLogger.LogMethodExit();
            return result;
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Generate TestCase Tabular Data
        /// </summary>
        /// <param name="data">data </param>
        /// <returns>tabular data</returns>
        /// 2019/06/26, Sharon Thankachan, WG3736_Initial Version
        /* WG3736 new START Chart and reports*/
        private List<TestCaseTabularReportModel> GenerateTestCaseTabularData(DataTable data)
        {
            List<TestCaseTabularReportModel> tabularReport = new List<TestCaseTabularReportModel>();
            var groups = data.AsEnumerable().OrderBy(x => x.Field<string>("ENGINEER")).GroupBy(x => x.Field<string>("ENGINEER"));
            int id = 1;
            foreach (var item in groups)
            {
                TestCaseTabularReportModel modelData = new TestCaseTabularReportModel { Id = id++, Developer = item.Key };
                int totalCount = 0;
                foreach (DataRow dr in item)
                {
                    if (dr["STATUS"] != DBNull.Value && dr["STATUS"].ToString() == ExecutionStatus.OK.ToString())
                    {
                        modelData.OK = Convert.ToInt32(dr["count"]);
                        totalCount += modelData.OK;
                    }
                    else if (dr["STATUS"] != DBNull.Value && dr["STATUS"].ToString() == ExecutionStatus.NG.ToString())
                    {
                        modelData.NG = Convert.ToInt32(dr["count"]);
                        totalCount += modelData.NG;
                    }
                    else if (dr["STATUS"] != DBNull.Value && dr["STATUS"].ToString() == ExecutionStatus.NE.ToString())
                    {
                        modelData.NE = Convert.ToInt32(dr["count"]);
                        totalCount += modelData.NE;
                    }
                }
                modelData.Total = totalCount;
                tabularReport.Add(modelData);
            }
            return tabularReport;
        }
        /* WG3736 new START Update tc order*/

        /// <summary>
        /// Generate TestCase Weekly Data
        /// </summary>
        /// <param name="data">data</param>
        /// <param name="keyValuePairBar">parent data</param>
        /// <returns>chart data</returns>
        /// 2019/06/26, Sharon Thankachan, WG3736_Initial Version
        /* WG3736 new START Chart and reports*/
        private ChartModel GenerateTestCaseWeeklyData(DataTable data, out Dictionary<string, int> keyValuePairBar)
        {
            keyValuePairBar = new Dictionary<string, int>();
            foreach (DataRow item in data.Rows)
            {
                keyValuePairBar.Add(string.Format("{0} {1}w", item["YEAR"].ToString(), item["WEEK"].ToString()), Convert.ToInt32(item["count"]));
            }
            return new ChartModel { Label = keyValuePairBar.Keys.ToArray(), Data = keyValuePairBar.Values.ToArray() };
        }
        /* WG3736 new END Chart and reports*/

        /// <summary>
        /// Generate TestCase Chart Data
        /// </summary>
        /// <param name="data">data</param>
        /// <param name="keyValuePairBar">parent data</param>
        /// <returns>chart data</returns>
        /// 2019/06/26, Sharon Thankachan, WG3736_Initial Version
        /* WG3736 new START Chart and reports*/
        private ChartModel GenerateTestCaseChartData(DataTable data, out Dictionary<string, int> keyValuePairBar)
        {
            keyValuePairBar = new Dictionary<string, int>();
            foreach (DataRow item in data.Rows)
            {
                keyValuePairBar.Add((string)item["label"], Convert.ToInt32(item["count"]));
            }
            return new ChartModel { Label = keyValuePairBar.Keys.ToArray(), Data = keyValuePairBar.Values.ToArray() };
        }
        /* WG3736 new END Chart and reports*/

        /// <summary>
        /// Generate TestCase By Status Data
        /// </summary>
        /// <param name="data">data</param>
        /// <returns>chart data</returns>
        /// 2019/06/26, Sharon Thankachan, WG3736_Initial Version
        /* WG3736 new START Chart and reports*/
        private ChartModel GenerateTestCaseByStatusData(DataTable data)
        {
            SortedDictionary<string, int> keyValuePair = new SortedDictionary<string, int>();
            foreach (DataRow item in data.Rows)
            {
                keyValuePair.Add((string)item["label"], item["count"] != DBNull.Value ? Convert.ToInt32(item["count"]) : 0);
            }
            foreach (var status in Enum.GetValues(typeof(ExecutionStatus)))
            {
                if (!keyValuePair.ContainsKey(status.ToString()))
                    keyValuePair.Add(status.ToString(), 0);
            }
            return new ChartModel { Label = keyValuePair.Keys.Reverse().ToArray(), Data = keyValuePair.Values.Reverse().ToArray() };
        }
        /* WG3736 new END Chart and reports*/

        /// <summary>
        /// Method to get TASAgent location
        /// </summary>
        /// <param name="machineName">Name of the machine</param>
        /// <returns>TASAgent location</returns>
        /// 2018/10/17, Praveen M P , V29627_Initial version
        private string GetTasAgentLocation(string machineName)
        {
            string location = string.Empty;
            List<SelectListItemHelper> list = new List<SelectListItemHelper>();
            IAutoStartService client = ConnectToService(machineName);
            location = client.GetTasAgentLocation();
            return location;
        }

        /// <summary>
        /// Get the list of all execution details by TC
        /// </summary>
        /// <param name="testPlanID">test plan id</param>
        /// <param name="tcVersionID">test case version id</param>
        /// <param name="testerName">tester Name</param>
        /// <returns>list of exen. status</returns>
        private List<DAL.Objects.TestExecutionStatus> ListAllExecutionResults(int testPlanID, int tcVersionID, string testerName)
        {
            TLRepository tLProjectRepository = new TLRepository();
            return tLProjectRepository.ListAllExecutionResults(testPlanID, tcVersionID, testerName).ToList();
        }

        /// <summary>
        /// Delete the execution result from database
        /// </summary>
        /// <param name="executionId">test plan  id</param>
        /// <returns></returns>
        /// 2020/10/19, Vinoth N, CRC207_Initial version
        public int RemoveExecutionResult(int executionId)
        {
            TLRepository tLProjectRepository = new TLRepository();
            return tLProjectRepository.RemoveExecutionResult(executionId);
        }

        /// <summary>
        /// Gets the test type of given test case
        /// </summary>
        /// <param name="projectID">Project ID</param>
        /// <param name="token">string token</param>
        /// <param name="currentTestCase">Current test case instance</param>
        /// <param name="cfName">Current test case name</param>
        /// <returns>Test type</returns>
        private string GetCustomeFieldValue(int projectID, string token, TestCaseFromTestPlan currentTestCase, string cfName)
        {
            string currentTestType = string.Empty;
            try
            {
                List<TestProject> testProjects = ConnectTestLink(token).GetProjects();
                TestProject result = testProjects.Where(s => s.id == projectID).First();

                if (result != null)
                {
                    string extid = string.Format("{0}-{1}", result.prefix, currentTestCase.external_id);
                    currentTestType = ConnectTestLink(token).GetTestCaseCustomFieldDesignValue(extid, currentTestCase.version, projectID.ToString(), cfName);
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return currentTestType;
        }

        /// <summary>
        /// connect to testlink
        /// </summary>
        /// <param name="token">api token</param>
        /// <returns>TestLink object</returns>
        private TestLink ConnectTestLink(string token)
        {
            RMUserRepository repo = new RMUserRepository();
            string login = repo.GetLogin(token);
            string apiPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_TESTLINK_API_PATH];
            TLUserRepository tlrepo = new TLUserRepository();
            string apikey = tlrepo.GetApiKey(login);
            if (string.IsNullOrEmpty(apikey))
            {
                apikey = tlrepo.GenerateAPIKey(login);
            }
            TestLink proxy = new TestLink(apikey, apiPath);
            return proxy;
        }

        /// <summary>
        /// Method to get test steps
        /// </summary>
        /// <param name="DALSteps">list of steps</param>
        /// <returns>step array</returns>
        private TestStep[] GetTestSteps(List<Step> DALSteps)
        {
            int indx = 0;
            TestStep[] steps = new TestStep[DALSteps.Count];
            foreach (var item in DALSteps)
            {
                indx++;
                TestStep step = new TestStep(indx, item.Actions, item.ExpResults, true, Convert.ToInt32(item.ExType));
                steps[indx - 1] = step;
            }

            return steps;
        }

        /// <summary>
        /// Gets the API key
        /// </summary>
        /// <param name="token">Login token string</param>
        /// <returns>API key</returns>
        private string GetAPIKey(string token)
        {
            string apiKey = string.Empty;
            RMUserRepository repo = new RMUserRepository();
            string login = repo.GetLogin(token);
            string apiPath = ConfigurationManager.AppSettings[Constants.APPSETTINGS_TESTLINK_API_PATH];
            TLUserRepository tlrepo = new TLUserRepository();
            apiKey = tlrepo.GetApiKey(login);
            if (string.IsNullOrEmpty(apiKey))
            {
                apiKey = tlrepo.GenerateAPIKey(login);
            }

            return apiKey;
        }

        /// <summary>
        /// convert dal to object
        /// </summary>
        /// <param name="testCaseDetailsViewModel">test case details</param>
        /// <returns>test case obj.</returns>
        private TMF.DAL.Objects.TestCase ConverttoDALObject(TestCaseDetailModel testCaseDetailsViewModel)
        {
            TMF.DAL.Objects.TestCase testCaseObj = new TMF.DAL.Objects.TestCase();
            testCaseObj.Id = testCaseDetailsViewModel.ID;
            testCaseObj.Name = testCaseDetailsViewModel.Title;
            testCaseObj.TestType = testCaseDetailsViewModel.TestType;
            testCaseObj.SubTestType = testCaseDetailsViewModel.SubTestType;
            testCaseObj.TesterName = new List<string>() { testCaseDetailsViewModel.AssignedTo };
            testCaseObj.TCMId = testCaseDetailsViewModel.TCMId;
            testCaseObj.NodeOrder = "1";
            testCaseObj.Summary = testCaseDetailsViewModel.Title;
            testCaseObj.PreConditions = " ";
            testCaseObj.ExType = testCaseDetailsViewModel.ExnType ? Convert.ToInt16(ExecutionType.Automated) : Convert.ToInt16(ExecutionType.Manual);
            testCaseObj.SchdExn = testCaseDetailsViewModel.ScheduledExn ? 1 : 0;
            testCaseObj.Importance = Convert.ToInt16(Importance.Medium);
            testCaseObj.Extid = testCaseDetailsViewModel.ExternalID;
            testCaseObj.MachineName = testCaseDetailsViewModel.MachineName;
            if (testCaseDetailsViewModel.TestCase != null || testCaseDetailsViewModel.ExpectedResult != null)
            {
                testCaseObj.Steps = new List<Step>(){new Step()
                    {
                        StepNumber = "1",
                        Actions = testCaseDetailsViewModel.TestCase==null?string.Empty:testCaseDetailsViewModel.TestCase,
                        ExpResults = testCaseDetailsViewModel.ExpectedResult==null?string.Empty:testCaseDetailsViewModel.ExpectedResult,
                        ExType = Convert.ToInt16(ExecutionType.Automated).ToString()
                    } };
            }
            testCaseObj.Attachments = ConverttoDALObject(testCaseDetailsViewModel.Attachments);

            return testCaseObj;
        }

        /// <summary>
        /// method to convert dal to object
        /// </summary>
        /// <param name="files">list of files</param>
        /// <returns>list of attachments</returns>
        private List<TMF.DAL.Objects.Attachment> ConverttoDALObject(List<AttachmentModel> files)
        {
            var attachments = new List<TMF.DAL.Objects.Attachment>();
            foreach (var file in files)
            {
                var attachment = new TMF.DAL.Objects.Attachment();
                attachment.Name = file.Name;
                attachment.FileType = file.FileType;
                attachment.Content = file.Content;
                attachment.FilePath = file.FilePath;
                attachment.Title = file.Title;
                attachments.Add(attachment);
            }

            return attachments;
        }

        /// <summary>
        /// convert model to object
        /// </summary>
        /// <param name="exnStatus">execution status</param>
        /// <returns>list of exec. status</returns>
        private List<ViewModels.TestExecutionStatus> ConvertToModelObject(List<DAL.Objects.TestExecutionStatus> exnStatus)
        {
            var modelExnStatuses = new List<ViewModels.TestExecutionStatus>();
            foreach (var exnDAL in exnStatus)
            {
                var modelExnStatus = new ViewModels.TestExecutionStatus
                {
                    Id = exnDAL.Id,
                    TestCaseID = exnDAL.TestCaseID,
                    TestedDate = exnDAL.TestedDate,
                    TesterName = exnDAL.TesterName,
                    TestPlanID = exnDAL.TestPlanID,
                    TestPlanName = exnDAL.TestPlanName,
                    Result = exnDAL.Status
                };
                modelExnStatuses.Add(modelExnStatus);
            }
            return modelExnStatuses;
        }

        /// <summary>
        /// convert to dal object
        /// </summary>
        /// <param name="executionStatusModel">execution status details</param>
        /// <returns>execution status</returns>
        private DAL.Objects.TestExecutionStatus ConvertToDALObject(ViewModels.TestExecutionStatus executionStatusModel)
        {
            var testExecutionStatusDAL = new DAL.Objects.TestExecutionStatus();
            testExecutionStatusDAL.TestCaseID = executionStatusModel.TestCaseID;
            testExecutionStatusDAL.TesterName = executionStatusModel.TesterName;
            testExecutionStatusDAL.TestedDate = executionStatusModel.TestedDate;
            testExecutionStatusDAL.Status = executionStatusModel.Result;
            testExecutionStatusDAL.TestPlanName = executionStatusModel.TestPlanName;
            testExecutionStatusDAL.TestPlanID = executionStatusModel.TestPlanID;

            return testExecutionStatusDAL;
        }

        /// <summary>
        /// Method to convert model to object
        /// </summary>
        /// <param name="document">Document</param>
        /// <returns>document details</returns>
        private DocumentModel ConvertToModelObject(Document document)
        {
            var documentModel = new DocumentModel();
            documentModel.LastUpdateTime = document.LastUpdateTime;
            documentModel.Name = document.Name;
            documentModel.ParentId = document.ParentId;
            // 2019/01/21, Sujith A ,VJP192- modified to store document details
            documentModel.TestPlanName = document.TestPlanName;
            documentModel.Id = document.Id;

            return documentModel;
        }

        /// <summary>
        /// Get test execution status from custom field data
        /// </summary>
        /// <param name="executionData">custom field value</param>
        /// <param name="testExecutionStatusList">test execution status list</param>
        /// <returns>list of execution status</returns>
        private List<ViewModels.TestExecutionStatus> GetTestExecutionStatusFromCustomField(string executionData, List<ViewModels.TestExecutionStatus> testExecutionStatusList)
        {
            List<ViewModels.TestExecutionStatus> executionResult = new List<ViewModels.TestExecutionStatus>();
            string[] testerList = executionData.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
            testerList = testerList.Reverse().ToArray();
            if (testerList.Length > 0)
                for (int i = 0; i < testerList.Length; i++)
                {
                    if (testExecutionStatusList.Count > i)
                        testExecutionStatusList[i].TesterName = testerList[i];
                }
            testExecutionStatusList.Reverse();
            return testExecutionStatusList;
        }

        /// <summary>
        /// Method to update last updated time
        /// </summary>
        /// <param name="docSuiteId">Unique id of document test suite</param>
        private void UpdateLastUpdateTime(int docSuiteId)
        {
            TLRepository repo = new TLRepository();
            repo.UpdateLastUpdatedTime(docSuiteId, DateTime.Now);
        }

        /// <summary>
        /// Method to check with previous value
        /// </summary>
        /// <param name="tc">test case details</param>
        /// <param name="testProject">project</param>
        /// <param name="token">token</param>
        /// <returns>true or false</returns>
        /// 2018/10/17, Praveen M P , V29627_Initial version
        private bool CheckIfValuesMatch(TestCaseDetailModel tc, string testProject, string token)
        {
            var testCaseSummary = new TestCaseDetailModel();
            testCaseSummary = GetTestCaseByID(Convert.ToInt32(tc.ID), testProject, tc.TestPlanID, token);
            bool status = true;
            if (testCaseSummary.ScheduledExnValue != null)
            {
                if (!(testCaseSummary.ScheduledExnValue.Replace(" ", string.Empty).Equals(tc.ScheduledExnValue.Replace(" ", string.Empty)))
                    || !(testCaseSummary.MachineName.Equals(tc.MachineName))
                    || !(testCaseSummary.MainScenarioName.Equals(tc.MainScenarioName))
                    || !(testCaseSummary.ProjectName.Equals(tc.ProjectName))
                    || !(testCaseSummary.ScriptFile.Equals(tc.ScriptFile)))
                {
                    status = false;
                }
            }
            return status;
        }

        /// <summary>
        /// Method to Connect to auto start service 
        /// </summary>
        /// <param name="mechineName">Name of the machine</param>
        /// <returns>connected client</returns>
        /// 2018/10/17, Praveen M P , V29627_Initial version
        private IAutoStartService ConnectToService(string mechineName)
        {
            IAutoStartService client = null;
            try
            {
                var binding = new NetTcpBinding("NetTcpBinding_IAutoStartService");
                var endpoint = new EndpointAddress(string.Format("net.tcp://{0}:9002/TASAutoStartService", mechineName));
                ChannelFactory<IAutoStartService> channelFactory = new ChannelFactory<IAutoStartService>(binding, endpoint);
                client = channelFactory.CreateChannel();
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return client;
        }

        /// <summary>
        /// Method to group tc by machine name
        /// </summary>
        /// <param name="testCaseIds">test case ids</param>
        /// <param name="testPlanId">test plan id</param>
        /// <param name="product">product</param>
        /// <param name="version">version</param>
        /// <param name="token">api token</param>
        /// <param name="notConfiguredTCs">tc's no configured in TMF</param>
        /// <param name="alternateNode">alternate machine name to run for not configured tc's</param>
        /// <param name="applyToAll">if machine name apply to all tc's</param>
        /// <returns>List of TestCaseDetails</returns>
        /// 2018/10/23, Praveen M P , V29627_Initial version
        /// 2019/01/11, Sharon Thankachan, VJP192_Modification for automated run of TCs
        private List<TestCaseDetailModel> GroupTestCaseByNode(string testCaseIds, string testPlanId, string product, string version,
            string token, string[] notConfiguredTCs, string alternateNode, bool applyToAll)
        {
            TMFLogger.LogMethodEntry();
            List<TestCaseDetailModel> listTcDetails = new List<TestCaseDetailModel>();
            var listTc = new Dictionary<string, string>();
            string[] testcaseids = testCaseIds.Split(',');
            string[] testplanIds = testPlanId.Split(',');
            /*VJP192_code optimization*/
            TLRepository repo = new TLRepository();
            var testCases = repo.GetTestCaseMchineDetails(testCaseIds);
            int i = 0;
            foreach (string tc in testcaseids)
            {
                listTc.Add(testcaseids[i], testplanIds[i]);
                i++;
            }
            if (listTc.Count > 0)
            {
                foreach (KeyValuePair<string, string> tcdetail in listTc)
                {
                    /*VJP192_code optimization*/
                    var testCaseSummary = ConvertToModel(testCases.Find(m => m.Id == tcdetail.Key));
                    testCaseSummary.Title = string.IsNullOrWhiteSpace(testCaseSummary.Title) ? string.Empty : testCaseSummary.Title.Replace("<p>", string.Empty).Replace("</p>", string.Empty);
                    testCaseSummary.Summary = string.IsNullOrWhiteSpace(testCaseSummary.Summary) ? string.Empty : testCaseSummary.Summary.Replace("<p>", string.Empty).Replace("</p>", string.Empty);
                    /*VJP192_Modification for automated run of TCs START*/
                    if (testCaseSummary.ExnType && !string.IsNullOrWhiteSpace(alternateNode) && applyToAll || (notConfiguredTCs.Length > 0 && notConfiguredTCs.Contains(testCaseSummary.ID.ToString())))
                    {
                        testCaseSummary.MachineName = alternateNode;
                    }
                    /*VJP192_Modification for automated run of TCs END*/
                    listTcDetails.Add(testCaseSummary);
                }
            }
            TMFLogger.LogMethodExit();

            return listTcDetails;
        }

        /// <summary>
        /// Method to get jenkins job list
        /// </summary>
        /// <param name="url">url of the jenkins</param>
        /// <returns>Job list</returns>
        /// 2018/10/24, Praveen M P , V29627_Initial version
        private List<string> GetJobList(string url)
        {
            List<string> list = new List<string>();
            string apiUrl = string.Format("{0}/api/xml?tree=jobs[name,builds[number,actions[parameters[name,value]]]]&exclude=hudson/job/build/action/parameter[value!=%275447e2f43ea44eb4168d6b32e1a7487a3fdf237f%27]", url);

            Uri address = new Uri(apiUrl);
            HttpWebRequest request = WebRequest.Create(address) as HttpWebRequest;
            request.Method = "GET";
            request.ContentType = "text/xml";
            request.Timeout = 10000;
            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            {
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string strOutputXml = reader.ReadToEnd();
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(strOutputXml);
                XmlNodeList xnList = xml.SelectNodes("/hudson/job");
                foreach (XmlNode xn in xnList)
                {
                    list.Add(xn.InnerText);
                }
            }
            return list;
        }

        /// <summary>
        /// Method to send progress staus
        /// </summary>
        /// <param name="url">api perams</param>
        /// <param name="nodeName">node name</param>
        /// <returns>Return</returns>
        /// 2018/10/17, Praveen M P , V29627_Initial version
        private bool CheckNodeExists(string url, string nodeName)
        {
            var exists = true;
            string apiUrl = string.Format("{0}/computer/{1}/api/xml?tree=displayName", url, nodeName);
            Uri address = new Uri(apiUrl);
            try
            {
                HttpWebRequest request = WebRequest.Create(address) as HttpWebRequest;
                request.Method = "GET";
                request.ContentType = "text/xml";
                request.Timeout = 10000;
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    StreamReader reader = new StreamReader(response.GetResponseStream());
                    string strOutputXml = reader.ReadToEnd();
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(strOutputXml);
                    XmlNodeList xnList = xml.SelectNodes("/slaveComputer/displayName");
                    foreach (XmlNode xn in xnList)
                    {
                        exists = true;
                    }
                }
            }
            catch (Exception)
            {
                return false; 
            }
            return exists;
        }

        /// <summary>
        /// Method to send progress staus
        /// </summary>
        /// <param name="typeId">type Id</param>
        /// <param name="nodeName">node name</param>
        /// <param name="slaveName">name of the node that to be configure</param>
        /// 2020/10/23, Vinoth N , CRC207_Initial version
        public void ConfigureSlave(int typeId, string nodeName, string slaveName)
        {
            var jenkinModel = new JenkinsConfigurationModel();
            jenkinModel = GetConfigurationData();
            switch (typeId)
            {
                case 1:
                    if (!CheckNodeExists(jenkinModel.JenkinsURL, nodeName))
                        DoCreateNode(jenkinModel.JenkinsURL, nodeName);
                    break;
                case 2:
                    if (CheckNodeExists(jenkinModel.JenkinsURL, slaveName))
                    {
                        if (slaveName != nodeName)
                            DoUpdateNode(jenkinModel.JenkinsURL, slaveName, nodeName);
                    }
                    else
                        DoCreateNode(jenkinModel.JenkinsURL, nodeName);
                    break;
                case 3:
                    if (CheckNodeExists(jenkinModel.JenkinsURL, nodeName))
                        DoDeleteNode(jenkinModel.JenkinsURL, nodeName);
                    break;
            }
        }

        /// <summary>
        /// Method to create jenkin slave
        /// </summary>
        /// <param name="url">api perams</param>
        /// <param name="nodeName">node name</param>
        /// <returns>Return</returns>
        /// 2020/10/23, Vinoth N , CRC207_Initial version
        private bool DoCreateNode(string url, string nodeName)
        {
            var exists = true;
            string apiUrl = string.Format("{0}/computer/doCreateItem", url);
            try
            {
                var client = new RestClient(apiUrl)
                {
                    Timeout = 10000
                };
                var request = new RestRequest(Method.POST);
                request.AddParameter("name", nodeName);
                request.AddParameter("_.nodeDescription", "TAS+Machine");
                request.AddParameter("_.numExecutors", "1");
                request.AddParameter("_.remoteFS", "C:\\Jenkins");
                request.AddParameter("mode", "NORMAL");
                request.AddParameter("type", "hudson.slaves.DumbSlave");
                request.AddParameter("json", " {\"name\": \"" + nodeName + "\", \"nodeDescription\": \"\", \"numExecutors\": \"1\", \"remoteFS\": " +
                    "\"C:\\\\Jenkins\", \"labelString\": \"\", \"mode\": \"NORMAL\", \"\": [\"hudson.slaves.JNLPLauncher\", \"hudson.slaves.RetentionStrategy$Always\"], " +
                    "\"launcher\": {\"stapler-class\": \"hudson.slaves.JNLPLauncher\", \"tunnel\": \"\", \"vmargs\": \"\"}, \"retentionStrategy\": {\"stapler-class\": " +
                    "\"hudson.slaves.RetentionStrategy$Always\"}, \"nodeProperties\": {\"stapler-class-bag\": \"true\"}, \"type\": \"hudson.slaves.DumbSlave\"}");
                request.AddParameter("Submit", "Save");
                IRestResponse response = client.Execute(request);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                return false;
            }
            return exists;
        }

        /// <summary>
        /// Method to update jenkin slave
        /// </summary>
        /// <param name="url">api perams</param>
        /// <param name="slaveName">name of the node to be upadte</param>
        /// <param name="nodeName">node name</param>
        /// <returns>Return</returns>
        /// 2020/10/23, Vinoth N , CRC207_Initial version
        private bool DoUpdateNode(string url, string slaveName, string nodeName)
        {
            var exists = true;
            string apiUrl = string.Format("{0}/computer/{1}/configSubmit", url, slaveName);
            try
            {
                var client = new RestClient(apiUrl)
                {
                    Timeout = 10000
                };
                var request = new RestRequest(Method.POST);
                request.AddParameter("json", " {\"name\": \"" + nodeName + "\", \"nodeDescription\": \"\", \"numExecutors\": \"1\", \"remoteFS\": \"C:\\\\Jenkins\", " +
                    "\"labelString\": \"\", \"mode\": \"NORMAL\", \"\": [\"hudson.slaves.JNLPLauncher\", \"hudson.slaves.RetentionStrategy$Always\"], " +
                    "\"launcher\": {\"stapler-class\": \"hudson.slaves.JNLPLauncher\", \"tunnel\": \"\", \"vmargs\": \"\"}, \"retentionStrategy\": " +
                    "{\"stapler-class\": \"hudson.slaves.RetentionStrategy$Always\"}, \"nodeProperties\": {\"stapler-class-bag\": \"true\"}}");
                IRestResponse response = client.Execute(request);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                return false;
            }
            return exists;
        }

        /// <summary>
        /// Method to delete jenkin slave
        /// </summary>
        /// <param name="url">api perams</param>
        /// <param name="nodeName">node name</param>
        /// <returns>Return</returns>
        /// 2020/10/23, Vinoth N , CRC207_Initial version
        private bool DoDeleteNode(string url, string nodeName)
        {
            var exists = true;
            string apiUrl = string.Format("{0}/computer/{1}/doDelete", url, nodeName);
            try
            {
                var client = new RestClient(apiUrl)
                {
                    Timeout = 10000
                };
                var request = new RestRequest(Method.POST);
                request.AddParameter("json", "{}");
                request.AddParameter("Submit", "Yes");
                IRestResponse response = client.Execute(request);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                return false;
            }
            return exists;
        }

        /// <summary>
        /// Method to return daily periodic data
        /// </summary>
        /// <param name="dates">start and end date</param>
        /// <returns>data</returns>
        /// 2019/02/13, Praveen MP ,VJP192- Modification for periodic job execution
        private string GetDailyPeriodicExecutionData(string[] dates)
        {
            string cron = string.Empty;
            var startDate = Convert.ToDateTime(dates[0]);
            var endDate = Convert.ToDateTime(dates[1]);
            try
            {
                int monthsApart = 12 * (startDate.Year - endDate.Year) + startDate.Month - endDate.Month;
                int mnth = Math.Abs(monthsApart) + 1;
                int j = startDate.Month;
                for (int i = 0; i < mnth; i++)
                {
                    var time = dates[3].Split(':');
                    cron += time[1] + " " + time[0] + " *" + " " + (j) + " *" + Environment.NewLine;
                    if (j >= 12)
                        j = 1;
                    else
                        j++;
                }
            }
            catch (Exception)
            {
                return cron;
            }

            return cron;
        }
        /// <summary>
        /// Method to create and schedule jenksin job
        /// </summary>
        /// <param name="model">test case details</param>
        /// <param name="testproject">project</param>
        /// <param name="token">token based on loggged user</param>
        /// <returns>result</returns>
        /// 2018/10/17, Praveen M P, V29627_Initial version
        /// 2019/06/06, Vinoth N, WG3736_Modification for get jenkins details from configuration file
        private bool CreateAndScheduleJob(TestCaseDetailModel model, string testproject, string token)
        {
            JenkinsClient client = new JenkinsClient();
            JenkinsProject conf = null;
            string jobName = string.Empty;
            bool stat = false;
            /* WG3736 mod START Modification for import data from configuration*/
            var jenkinModel = new JenkinsConfigurationModel();
            jenkinModel = GetConfigurationData();
            try
            {
                if (model == null || string.IsNullOrEmpty(testproject) || string.IsNullOrEmpty(token))
                {
                    return false;
                }
                client.BaseUrl = jenkinModel.JenkinsURL;
                client.UserName = jenkinModel.Username;
                client.ApiToken = jenkinModel.APIKey;
                string xmlString = File.ReadAllText(string.Format("{0}App_Data\\JobConfig.xml", AppDomain.CurrentDomain.BaseDirectory));
                XDocument xdocc = XDocument.Parse(xmlString);
                XNode xnode = xdocc.FirstNode;
                conf = new JenkinsProject(xnode);
                string BuildInterval = model.ScheduledExnValue;
                if (BuildInterval != null)
                {
                    if (model.ScheduledExnType == "0")
                    {
                        DateTime dt = Convert.ToDateTime(BuildInterval);
                        int Hour = (dt.Hour <= 12) ? (dt.Hour + 12) : dt.Hour;
                        BuildInterval = string.Format("{0} {1} {2} {3} *", dt.Minute, Hour, dt.Day, dt.Month);
                    }
                    // 2019/02/13, Praveen MP ,VJP192- Modification for periodic job execution
                    else if (model.ScheduledExnType == "2")
                    {
                        string[] dates = BuildInterval.Split(',');
                        if (dates[2] == "1")
                        {
                            BuildInterval = GetDailyPeriodicExecutionData(dates);
                        }
                        else
                        {
                            var time = dates[3].Split(':');
                            var days = dates[4].Replace(':', ',');
                            BuildInterval = time[1] + " " + time[0] + " * * " + days;
                            BuildInterval = BuildInterval.Remove(BuildInterval.Length - 1, 1);
                        }
                    }
                    else
                    {
                        string[] spltVal = BuildInterval.Split(',');
                        if (spltVal[1].Trim() == "0")
                        {
                            BuildInterval = string.Format("*/{0} * * * *", spltVal[0]);
                        }
                        else
                        {
                            BuildInterval = string.Format("{0} */{1} * * *", spltVal[0].Trim(), spltVal[1].Trim());
                        }
                    }
                }
                var repo = new RMUserRepository();
                var loginName = repo.GetLogin(token);
                StringBuilder tasAgentLocationBuilder = new StringBuilder(GetTasAgentLocation(model.MachineName));
                tasAgentLocationBuilder.AppendFormat(" {0} \"{1}\" \"{2}\"", "TMF", model.TestProjectName, model.TestSuiteName);
                tasAgentLocationBuilder.AppendFormat(" {0} {1}", model.ID, model.TestPlanID);
                tasAgentLocationBuilder.AppendFormat(" {0}", loginName);

                XDocument xdoc = conf.Node.Document;
                var node = xdoc.Root.Descendants("command").FirstOrDefault();
                node.Value = tasAgentLocationBuilder.ToString();
                node = xdoc.Root.Descendants("spec").FirstOrDefault();
                node.Value = BuildInterval;

                node = xdoc.Root.Descendants("assignedNode").FirstOrDefault();
                node.Value = model.MachineName;

                UserDetailsModel modeluser = new AccountManager().GetUserDetails(loginName);
                string mailAddress = modeluser.Email;

                var emailNode = xdoc.Root.Descendants("recipientList").FirstOrDefault();
                emailNode.Value = mailAddress;

                jobName = string.Format("{0}_{1}", model.TestPlanName, model.TCMId);
                if (string.IsNullOrEmpty(jobName))
                {
                    return false;
                }
                List<string> joblist = new List<string>();
                HttpWebRequest httpReq = (HttpWebRequest)WebRequest.Create(jenkinModel.JenkinsURL);
                httpReq.Timeout = 3000;
                httpReq.AllowAutoRedirect = false;
                HttpWebResponse httpRes = (HttpWebResponse)httpReq.GetResponse();
                if (httpRes.StatusCode == HttpStatusCode.OK)
                {
                    joblist = GetJobList(jenkinModel.JenkinsURL);
                }
                httpRes.Close();
                /* WG3736 mod END Modification for import data from configuration*/
                bool has = joblist.Any(job => job == jobName);
                if (!has)
                {
                    client.Jobs.CreateAsync(jobName, conf);
                }
                if (!CheckIfValuesMatch(model, testproject, token))
                {
                    client.Jobs.DeleteAsync(jobName);
                    Task task = client.Jobs.CreateAsync(jobName, conf);
                }
                stat = true;
            }
            catch (JenkinsNetException jex)
            {
                stat = false;
                TMFLogger.LogError(jex.Message);
            }
            return stat;
        }

        /// <summary>
        /// Method to delete associated user info.
        /// </summary>
        /// <param name="token">token</param>
        /// <param name="testPlanIDs">plan id</param>
        /// <param name="testCaseIds">test case id</param>
        private void DeleteAssignedUserInformation(string token, string testPlanIDs, string testCaseIds)
        {
            var tLProjectRepository = new TLRepository();
            var tcIds = testCaseIds.Split(';');
            string[] tplanId = testPlanIDs.Split(';');
            int count = 0;
            foreach (string tcid in tcIds)
            {
                int id = Convert.ToInt32(tcid);
                TestCaseFromTestPlan testCaseFromTestPlan = ConnectTestLink(token).GetTestCasesForTestPlan(Convert.ToInt32(tplanId[count]), id)
                  .Where(tc => tc.tc_id == id).FirstOrDefault();
                tLProjectRepository.DeleteAssociatedUserAssignement(testCaseFromTestPlan.feature_id);
                count++;
            }
        }

        /*V29627_Modification for Automated execution  END*/

        /// <summary>
        /// Creates content of the email
        /// </summary>
        /// <param name="tcIds">tc ids and test plan ids</param
        /// <param name="moduleId">Module Id</param>
        /// <param name="testCaseBaseURL">Testcase URL</param>
        /// <param name="userName">Name of the user</param>
        /// <param name="language">Language</param>
        /// <param name="powerAutomate">Power automate</param>
        /// <returns>Mail content</returns>
        /// 2019/01/11, Sharon Thankachan, VJP192_Initial Version
        /// 2019/05/31, Vinoth N, WG3736_Modification for mail design changes
        /// 2021/02/16, Sharon Thanakchan, DMG213_Modification for Power Automate
        private string GenerateMailContent(Dictionary<int, int> tcIds, string moduleId, string testCaseBaseURL, string userName, string language, bool powerAutomate = false)
        {
            /* WG3736 mod START Modification for mail design changes*/
            TLRepository tlRepo = new TLRepository();
            string message = String.Empty;
            StringBuilder content = new StringBuilder();
            var key = tcIds.Keys;
            List<int> TCkeys = key.Cast<int>().ToList();
            List<string> updatedTCkeys = TCkeys.ConvertAll<string>(x => x.ToString());
            var testCases = tlRepo.GetTestcaseDetails(updatedTCkeys);
            /* DMG213 mod START Modification for email notification enhancement*/
            if (!powerAutomate)
            {
                message = AdministrationManager.CustomResource(language, "MailTCAssigned");
                message = message.Replace("{fullName}", userName);
                message = message.Replace("{signature}", AdministrationManager.CustomResource(language, "MailSignature"));
                foreach (var pair in testCases)
                {
                    var url = testCaseBaseURL + "/TestCase/TestCaseDetail?testCaseID=" + pair.Id + "&testPlan=" + pair.TestPlanId + "&testSuitID=" + pair.TestCaseVersionId + "&pId=" + moduleId;
                    content.Append(@"<a href=" + url + " >TestCase#" + pair.TCMId + ": " + pair.Name + " </a><br>");
                }
                message = message.Replace("{content}", content.ToString());
            }
            else
            {
                foreach (var pair in testCases)
                {
                    var url = testCaseBaseURL + "/TestCase/TestCaseDetail?testCaseID=" + pair.Id + "&testPlan=" + pair.TestPlanId + "&testSuitID=" + pair.TestCaseVersionId + "&pId=" + moduleId;
                    content.Append(@"<a href=" + url + " >TestCase#" + pair.TCMId + ": " + pair.Name + " </a><br>");
                }
                message = content.ToString();
            }
            /* DMG213 mod END Modification for email notification enhancement*/
            /* WG3736 mod END Modification for mail design changes*/
            return message;
        }

        /// <summary>
        /// Method to convert dal object to model
        /// </summary>
        /// <param name="testcase">Test case dal object</param>
        /// <returns>Returns test case detail model</returns>
        /// VJP192_code optimization- Initial version
        private TestCaseDetailModel ConvertToModel(DAL.Objects.TestCase testcase)
        {
            TestCaseDetailModel model = new TestCaseDetailModel();
            if (testcase != null)
            {
                model.Summary = testcase.Summary;
                model.Title = testcase.Summary;
                model.ID = testcase.Id;
                model.TCMId = testcase.TCMId;
                model.MachineName = testcase.MachineName;
                model.AssignedTo = testcase.Assignee;
                model.ExnType = testcase.ExType == Convert.ToInt32(ExecutionType.Automated) ? true : false;
                model.ProjectName = testcase.ProjectName;
                model.MainScenarioName = testcase.MainScenarioName;
                model.SubScenario = testcase.SubScenarioName;
            }
            return model;
        }

        /// <summary>
        /// Method to get jenkins configuration
        /// </summary>
        /// <returns>Returns jenkins configuration</returns>
        /// Vinoth N - WG3736_Initial version
        /* WG3736 new START Jenkins configuration*/
        public JenkinsConfigurationModel GetConfigurationData()
        {
            JenkinsConfigurationModel output = new JenkinsConfigurationModel();
            try
            {
                IAdministrationManager callRepository = new AdministrationManager();
                output = callRepository.GetConfigurationData().JenkinsConfiguration;
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return output;
        }
        /* WG3736 new END Jenkins configuration*/

        /// <summary>
        /// Get all TAS machines from configuration file
        /// </summary>
        /// <param></param>
        /// <returns>list of machines</returns>
        /// 2019/06/06, Vinoth N, WG3736_Initial Version
        /* WG3736 new START TAS Machines*/
        public List<TASMachineModel> GetAllMachines()
        {
            List<TASMachineModel> allMachines = new List<TASMachineModel>();
            ConfigurationRepository callRepository = new ConfigurationRepository();
            TMF.DAL.Objects.Configuration modelXml = new TMF.DAL.Objects.Configuration();
            modelXml = callRepository.LoadConfigurationData();

            foreach (var tas in modelXml.TASMachines)
            {
                allMachines.Add(new TASMachineModel { Id = tas.Id, AliasName = tas.AliasName, MachineName = tas.MachineName });
            }

            return allMachines;
        }
        /* WG3736 new END TAS Machines*/

        /// <summary>
        /// Method to retrive product details
        /// </summary>
        /// <param name="testCaseId">Test case Id</param>
        /// <param name="isSuite">suite flag</param>
        /// <returns>Return product details</returns>
        /// 2019/06/06, Vinoth N, WG3736_Initial version
        /* WG3736 new START For retrive product details*/
        public object GetTestProductDetails(int testCaseId, bool isSuite = false)
        {
            TLRepository repo = new TLRepository();
            object data = repo.GetTestProductDetails(testCaseId, isSuite);
            return data;
        }
        /* WG3736 new END For retrive product details*/
        #endregion

        #region Private Methods

        /// <summary>
        /// Method to remove Unicode chars
        /// </summary>
        /// <param name="data">source line</param>
        /// <returns>Return data</returns>
        /// 2019/06/06, Vinoth N, WG3736_Initial version
        private string SafeFormat(string data)
        {
            string formattedString = data ?? "";
            return formattedString.Replace("\u0005", "").Replace("\u0001", "");
        }

        /// <summary>
        /// Method to check the job exist.
        /// </summary>
        /// <param name="url">URL of jenkins</param>
        /// <param name="jobName">Job name</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/15, Vinoth N, EL5873_Initial version
        private bool GetJobExist(string url, string jobName)
        {
            var status = false;
            string apiUrl = string.Format("{0}/api/xml?tree=jobs[name]" +
                "&xpath=/hudson/job[ends-with(name/text(),%22"+ jobName + "%22)]&wrapper=jobs", url);
            Uri address = new Uri(apiUrl);
            HttpWebRequest request = WebRequest.Create(address) as HttpWebRequest;
            request.Method = "GET";
            request.ContentType = "text/xml";
            request.Timeout = 10000;
            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            {
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string strOutputXml = reader.ReadToEnd();
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(strOutputXml);
                XmlNodeList xnList = xml.SelectNodes("/jobs/job/name");
                if (xnList.Count > 0)
                    status = true;
            }
            return status;
        }

        /// <summary>
        /// Method to delete job in jenkins.
        /// </summary>
        /// <param name="url">URL of jenkins</param>
        /// <param name="jobName">Job name</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/16, Vinoth N, EL5873_Initial version
        private bool DeleteJenkinsJob(string url, string jobName)
        {
            bool status;
            try
            {
                if (GetJobExist(url, jobName))
                {
                    url = url.Remove(url.Length - 1, 1);
                    string apiUrl = string.Format("{0}/job/{1}/doDelete", url, jobName);
                    var client = new RestClient(apiUrl) { Timeout = -1 };
                    var request = new RestRequest(Method.POST);
                    request.AddHeader("Origin", url);
                    request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
                    request.AddParameter("application/x-www-form-urlencoded", "<file contents here>", ParameterType.RequestBody);
                    IRestResponse response = client.Execute(request);
                }
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
                TMFLogger.LogException(ex);
            }           
            return status;
        }

        #endregion

    }
    #endregion
}
#endregion
