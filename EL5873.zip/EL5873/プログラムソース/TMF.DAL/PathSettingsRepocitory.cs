﻿#region File Header
// ---------------------------------------------------------------------------------------
// Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved.
// File Name     : PathSettingsRepocitory.cs
// Description   : Contains path settings CURD operations.
// Date          |    Author             |        Description
// ---------------------------------------------------------------------------------------
// 2021/06/21    |   Vinoth N            |        EL5873_Initial Version
// --------------------------------------------------------------------------------------- 
#endregion

#region Using
using MySql.Data.MySqlClient;
using System;
using System.Data;
using TMF.DAL.Objects;
#endregion

#region Namespace
namespace TMF.DAL
{
    #region Class
    /// <summary>
    /// Contains path settings CURD operations.
    /// </summary>
    /// <author>Vinoth N</author>
    /// <copyright>Copyright (C) Hitachi High-Tech Corporation 2021.</copyright>
    public class PathSettingsRepocitory
    {
        #region Variables
        /// <summary>
        /// Connection string.
        /// </summary>
        private readonly string connString;
        #endregion

        #region Constructor
        /// <summary>
        /// Parameter redmine path settings constructor.
        /// </summary>
        /// 2021/06/21, Vinoth N, EL5873_Initial Version
        public PathSettingsRepocitory(string connection)
        {
            connString = connection;
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Method to create path settings.
        /// </summary>
        /// <param name="pathSettings">Path settings input.</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/21, Vinoth N, EL5873_Initial Version
        public bool Create(PathSettings pathSettings)
        {
            bool status;
            using (var context = new RedmineDBContext())
            {
                MySqlCommand cmdInsert = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmdInsert.Connection = conn;
                    cmdInsert.CommandText = "INSERT INTO `path_settings`(`module_id`,`repository_source`," +
                                      "`buid_script`,`execution_script`,`created_on`)" +
                                      "VALUES(@module, @repocitary, @build, @execution, NOW()); ";
                    cmdInsert.Parameters.AddWithValue("@module", pathSettings.ModuleId);
                    cmdInsert.Parameters.AddWithValue("@repocitary", pathSettings.RepositorySource);
                    cmdInsert.Parameters.AddWithValue("@build", pathSettings.BuildScript);
                    cmdInsert.Parameters.AddWithValue("@execution", pathSettings.ExecutionScript);
                    status = cmdInsert.ExecuteNonQuery() > 0;
                }
                catch (Exception ex)
                {
                    throw(ex);
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        cmdInsert.Parameters.Clear();
                        conn.Close();
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Method to update path settings
        /// </summary>
        /// <param name="pathSettings">Path settings input.</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/21, Vinoth N, EL5873_Initial Version
        public bool Update(PathSettings pathSettings)
        {
            bool status;
            using (var context = new RedmineDBContext())
            {
                MySqlCommand cmdUpdate = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmdUpdate.Connection = conn;
                    cmdUpdate.CommandText = "UPDATE `path_settings` SET " +
                                      "`module_id` = @module," +
                                      "`repository_source` = @repocitary," +
                                      "`buid_script` = @build," +
                                      "`execution_script` = @execution," +
                                      "`updated_on` = NOW()" +
                                      "WHERE `id` = @id";
                    cmdUpdate.Parameters.AddWithValue("@id", pathSettings.Id);
                    cmdUpdate.Parameters.AddWithValue("@module", pathSettings.ModuleId);
                    cmdUpdate.Parameters.AddWithValue("@repocitary", pathSettings.RepositorySource);
                    cmdUpdate.Parameters.AddWithValue("@build", pathSettings.BuildScript);
                    cmdUpdate.Parameters.AddWithValue("@execution", pathSettings.ExecutionScript);
                    status = cmdUpdate.ExecuteNonQuery() > 0;
                }
                catch (Exception ex)
                {
                    status = false;
                                 if (ex is ArgumentOutOfRangeException)
                {
                    exceptionMessage = "Specified Index was out of range";
                }
                else if (ex is MissingMemberException)
                {
                    if (ex.Message.Contains("has no attribute"))
                    {
                        exceptionMessage = ex.Message.Substring(ex.Message.LastIndexOf(' ')) + " is an invalid command";
                    }
                }
                else if (ex is ArgumentTypeException)
                {
                    exceptionMessage = "Invalid argument(s) found: " + ex.Message;
                }
                else if (ex is Runtime.UnboundNameException)
                {
                    exceptionMessage = ex.Message;
                }
                else if (ex is SMLParserException || ex is InvalidCommandParameterException || ex is DirectoryNotFoundException ||
                    ex is OverflowException)
                {
                    exceptionMessage = ex.Message;
                    switch (exceptionMessage.ToUpper())
                    {
                        case "F8":
                            dataType = TMFDataType.SecsII_F8;
                            break;
                        case "I1":
                            dataType = TMFDataType.SecsII_I1;
                            break;
                        default:
                            throw new SMLParserException("Invalid data type '" + msgType + "' found");
                    }
                }
                    throw(ex);
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        cmdUpdate.Parameters.Clear();
                        conn.Close();
                    }
                }
            }
            return status;
        }

        /// <summary>
        /// Method to get path settings.
        /// </summary>
        /// <param name="input">Collection of general inputs.</param>
        /// <returns>Returns build settings.</returns>
        /// 2021/06/22, Vinoth N, EL5873_Initial Version
        public PathSettings GetAll(object[] input)
        {
            PathSettings settings = new PathSettings();
            using (var context = new RedmineDBContext())
            {
                DataTable settingsTable = new DataTable();
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "select * from `path_settings` where `module_id` = @moduleId limit 1";
                    cmd.Parameters.AddWithValue("@moduleId", input[0].ToString());
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(settingsTable);
                    }
                    foreach (DataRow row in settingsTable.Rows)
                    {
                        settings = new PathSettings()
                        {
                            Id = Convert.ToInt32(row["id"] ?? 0),
                            ModuleId = Convert.ToInt32(row["module_id"] ?? 0),
                            BuildScript = row["buid_script"].ToString(),
                            RepositorySource = row["repository_source"].ToString(),
                            ExecutionScript = row["execution_script"].ToString()
                        };
                    }
                }
                catch (Exception ex)
                {
                                 if (ex is ArgumentOutOfRangeException)
                {
                    exceptionMessage = "Specified Index was out of range";
                }
                else if (ex is MissingMemberException)
                {
                    if (ex.Message.Contains("has no attribute"))
                    {
                        exceptionMessage = ex.Message.Substring(ex.Message.LastIndexOf(' ')) + " is an invalid command";
                    }
                }
                else if (ex is ArgumentTypeException)
                {
                    exceptionMessage = "Invalid argument(s) found: " + ex.Message;
                }
                else if (ex is Runtime.UnboundNameException)
                {
                    exceptionMessage = ex.Message;
                }
                else if (ex is SMLParserException || ex is InvalidCommandParameterException || ex is DirectoryNotFoundException ||
                    ex is OverflowException)
                {
                    exceptionMessage = ex.Message;
                    switch (exceptionMessage.ToUpper())
                    {
                          case "F8":
                            dataType = TMFDataType.SecsII_F8;
                            break;
                        case "I1":
                            dataType = TMFDataType.SecsII_I1;
                            break;
                        case "ARRAY":
                            dataType = TMFDataType.SecsII_Array;
                            break;
                        case "A":
                            dataType = TMFDataType.SecsII_ASCII;
                            break;
                        case "B":
                            dataType = TMFDataType.SecsII_Binary;
                            break;
                        case "BOOLEAN":
                            dataType = TMFDataType.SecsII_Bool;
                            break;
                        case "F4":
                            dataType = TMFDataType.SecsII_F4;
                            break;
                        case "F8":
                            dataType = TMFDataType.SecsII_F8;
                            break;
                        case "U2":
                            dataType = TMFDataType.SecsII_U2;
                            break;
                        case "U4":
                            dataType = TMFDataType.SecsII_U4;
                            break;
                        case "U8":
                            dataType = TMFDataType.SecsII_U8;
                            break;
                        case "J":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "L":
                            dataType = TMFDataType.SecsII_List;
                            break;
                        default:
                            throw new SMLParserException("Invalid data type '" + msgType + "' found");
                    }
                }
                   throw(ex);
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
            return settings;
        }
        #endregion
    }
    #endregion
}
#endregion