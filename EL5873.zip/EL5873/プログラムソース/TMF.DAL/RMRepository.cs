﻿#region File Header
// ---------------------------------------------------------------------------------------
// Copyright (C) Hitachi High-Tech Corporation, 2018-2021. All rights reserved.
// File Name     : RMRepository.cs
// Description   : Contains RMRepository related functionalities
// Date          |    Author             |         Description
// ---------------------------------------------------------------------------------------
// 2018/06/07    |   Nabinsha N S        |         Created
// 2019/01/30    |   Sujith A            |         Modification for product management - VJP192
// 2019/06/26    |   Sharon Thankachan   |         WG3736_ Modification for Charts and reports
// 2019/07/30    |   Vinoth N            |         WG3736_Modification for Change email content 
// 2020/01/26    |   Vinoth N            |         B1K017_Modification for Tabular data based on “Assigned To” in bugs
// 2020/05/15    |   Vinoth N            |         C51165_Modification for related bugs and recently assigned test cases
// 2021/06/07    |   Vinoth N            |         EL5873_Modification for build and path settings
// --------------------------------------------------------------------------------------- 
#endregion

#region Using

using MySql.Data.MySqlClient;
using Redmine.Net.Api;
using Redmine.Net.Api.Types;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using TMF.Common;
using TMF.DAL.Objects;
using TMF.Logger;
using TMF.ViewModels;

#endregion

namespace TMF.DAL
{
    public class RMRepository
    {

        #region Variables
        /// <summary>
        /// connection string
        /// </summary>
        public string connString = ConfigurationManager.ConnectionStrings["Redmine"].ToString();

        /// <summary>
        /// List of bug id's those are added to the bug summary list
        /// </summary>
        List<int> bugIds = new List<int>();

        /// <summary>
        /// List of sub projects
        /// </summary>
        List<SubProject> subProjetcs = new List<SubProject>();

        /// <summary>
        /// Store module name
        /// </summary>
        string globalModuleName = string.Empty;

        /// <summary>
        /// Build settings repository.
        /// </summary>
        private readonly BuildSettingsRepocitory buildRepocitory;

        /// <summary>
        /// Path settings repository.
        /// </summary>
        private readonly PathSettingsRepocitory pathRepocitory;
        #endregion

        #region Constructor
        /// <summary>
        /// Default constructor for redmine repository.
        /// </summary>
        /// 2021/06/07, Vinoth N, EL5873_Initial Version
        public RMRepository()
        {
            buildRepocitory = new BuildSettingsRepocitory(connString);
            pathRepocitory = new PathSettingsRepocitory(connString);
        }
        #endregion

        #region Public methods

        /// <summary>
        /// get custom field id by name
        /// </summary>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public int GetCustomFieldID(string fieldName)
        {
            int custID = 0;
            using (var context = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT * FROM `custom_fields` WHERE name=@fieldName";
                    cmd.Parameters.AddWithValue("@fieldName", fieldName);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            custID = Convert.ToInt32(reader["id"]);
                        }
                    }
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }

            return custID;
        }

        /// <summary>
        /// Gets the mail address
        /// </summary>
        /// <param name="userInput">Id or userName</param>
        /// <param name="name">Name for the User</param>
        /// <param name="language">language for the User</param>
        /// <returns>Mail address</returns>
        /// 2019/05/30, Vinoth N, WG3736_Modification for get FullName and language
        public string GetUserProfile(string userInput, out string name, out string language)
        {
            string emailId = string.Empty;
            /* WG3736 mod START Modification for get FullName and language*/
            string query = string.Empty;
            name = string.Empty;
            language = string.Empty;
            if (int.TryParse(userInput, out int userID))
            {
                query = "SELECT firstname,lastname,address,language FROM `users` INNER JOIN `email_addresses` on `users`.`id` = `email_addresses`.`user_id` WHERE `email_addresses`.`user_id`=@userInput";
            }
            else
            {
                query = "SELECT firstname,lastname,address,language FROM `users` INNER JOIN `email_addresses` on `users`.`id` = `email_addresses`.`user_id` WHERE `users`.`login`=@userInput";
            }
            using (var context = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = query;
                    cmd.Parameters.AddWithValue("@userInput", userInput);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            name = reader[0].ToString() + " " + reader[1].ToString();
                            emailId = reader[2].ToString();
                            language = reader[3].ToString();
                        }
                    }
                }
                /* WG3736 mod END Modification for get FullName and language*/
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
            return emailId;
        }

        /// <summary>
        /// Gets the bug details from Redmine Database based on project Id
        /// </summary>
        /// <param name="projectId">Project id</param>
        /// <param name="token">token</param>
        /// <param name="moduleName">Module name</param>
        /// <param name="isRelated">flag for related</param>
        /// <returns>Bug summary list</returns>
        /// 2019/02/11, Sujith A ,VJP192- Modified
        /// 2020/05/15, Vinoth N, C51165_Modification for related bugs
        public List<BugSummary> GetBugDetailsById(int projectId, string token, string moduleName = "", bool isRelated = false)
        {
            List<BugSummary> sumamry = new List<BugSummary>();
            try
            {
                using (var context = new RedmineDBContext())
                {
                    DataTable table = new DataTable();
                    MySqlCommand cmd = new MySqlCommand();
                    MySqlConnection conn = new MySqlConnection(connString);
                    /* C51165 mod START Modification for related bugs */
                    try
                    {
                        conn.Open();
                        cmd.Connection = conn;
                        if (isRelated)
                            GetBugInformationByBugId(projectId, cmd, sumamry, token);
                        else
                            GetBugInformationById(projectId, cmd, sumamry, moduleName, false, token);
                    }
                    catch (Exception ex)
                    {
                        TMFLogger.LogException(ex);
                    }
                    /* C51165 mod END Modification for related bugs */
                    finally
                    {
                        if (conn != null && conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return sumamry;
        }

        /// <summary>
        /// get sub projects by project id
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        private List<SubProject> GetSubProjectById(int projectId)
        {
            List<SubProject> subProjects = new List<SubProject>();
            int subProjectId = 1;
            string subProjectName = string.Empty;
            try
            {
                using (var context = new RedmineDBContext())
                {
                    DataTable table = new DataTable();
                    MySqlCommand cmd = new MySqlCommand();
                    MySqlConnection conn = new MySqlConnection(connString);
                    MySqlConnection conn2 = new MySqlConnection(connString);
                    try
                    {
                        conn.Open();
                        cmd.Connection = conn;
                        while (subProjectId != 0)
                        {
                            subProjectId = 0;
                            cmd.CommandText = "SELECT id,name FROM `projects` WHERE parent_id =" + projectId + "";
                            List<int> projectIds = new List<int>();
                            using (MySqlDataReader reader = cmd.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    subProjectId = Convert.ToInt32(reader[0]);
                                    subProjectName = reader[1].ToString();
                                    subProjects.Add(new SubProject { Id = subProjectId, SubProjectName = subProjectName });
                                    projectId = subProjectId;
                                    projectIds.Add(projectId);
                                }
                            }
                            foreach (int pj in projectIds)
                            {
                                MySqlCommand cmd2 = new MySqlCommand();
                                conn2.Open();
                                cmd2.Connection = conn2;
                                cmd2.CommandText = "SELECT id,name FROM `projects` WHERE parent_id =" + pj + "";
                                using (MySqlDataReader reader1 = cmd.ExecuteReader())
                                {
                                    while (reader1.Read())
                                    {
                                        subProjectId = Convert.ToInt32(reader1[0]);
                                        subProjectName = reader1[1].ToString();
                                        subProjects.Add(new SubProject { Id = subProjectId, SubProjectName = subProjectName });
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (conn != null && conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                        if (conn2 != null && conn2.State == ConnectionState.Open)
                        {
                            conn2.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return subProjects;
        }

        /// <summary>
        /// Get return list of sub projects
        /// </summary>
        /// <param name="projectName"></param>
        /// <param name="versionName"></param>
        /// <returns></returns>
        public List<SubProject> GetProjectTree(string projectName, string versionName)
        {
            using (var context = new RedmineDBContext())
            {
                DataTable table = new DataTable();
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    bugIds.Clear();
                    subProjetcs.Clear();
                    List<int> projectIdList = IsProjectValid(cmd, projectName, versionName);
                    if (projectIdList.Count > 0)
                    {
                        List<BaseData> moduleList = GetModuleList(versionName, cmd, projectIdList[0]);
                        GetSubProjects(versionName, cmd, moduleList, projectIdList[1]);
                    }
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
            return subProjetcs;
        }

        public Dictionary<string, string> GetAncestorByProjectID(int projectID)
        {
            Dictionary<string, string> projectTree = new Dictionary<string, string>();
            using (var context = new RedmineDBContext())
            {
                DataTable table = new DataTable();
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "select t1.name as Child, t2.name as Parent, t3.name as GrandParent, t4.name as GreatGrandParent " +
                        "from bitnami_redmine.projects t1 " +
                        "left join bitnami_redmine.projects t2 on t1.parent_id = t2.id " +
                        "left join bitnami_redmine.projects t3 on t2.parent_id = t3.id " +
                        "left join bitnami_redmine.projects t4 on t3.parent_id = t4.id " +
                        "where t1.id = @projectID";
                    cmd.Parameters.AddWithValue("@projectID", projectID);
                    table.Load(cmd.ExecuteReader());
                    if (table.Rows.Count > 0)
                    {
                        projectTree["CHILD"] = table.Rows[0]["Child"] != DBNull.Value ? table.Rows[0]["Child"].ToString() : string.Empty;
                        projectTree["PARENT"] = table.Rows[0]["Parent"] != DBNull.Value ? table.Rows[0]["Parent"].ToString() : string.Empty;
                        projectTree["GRANDPARENT"] = table.Rows[0]["GrandParent"] != DBNull.Value ? table.Rows[0]["GrandParent"].ToString() : string.Empty;
                        projectTree["GREATGRANDPARENT"] = table.Rows[0]["GreatGrandParent"] != DBNull.Value ? table.Rows[0]["GreatGrandParent"].ToString() : string.Empty;
                    }
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }

            return projectTree;

        }
        /// <summary>
        /// Gets the bug details from Redmine Database
        /// </summary>
        /// <param name="projectName">Project name in Redmine</param>
        /// <param name="versionName">Version name in Redmine</param>
        /// <returns>Bug summary list</returns>
        public List<BugSummary> GetBugDetailsDashBoard(string projectName, string versionName)
        {
            List<BugSummary> sumamry = new List<BugSummary>();
            try
            {
                using (var context = new RedmineDBContext())
                {
                    DataTable table = new DataTable();
                    MySqlCommand cmd = new MySqlCommand();
                    MySqlConnection conn = new MySqlConnection(connString);
                    try
                    {
                        conn.Open();
                        cmd.Connection = conn;
                        bugIds.Clear();
                        subProjetcs.Clear();
                        List<int> projectIdList = IsProjectValid(cmd, projectName, versionName);
                        if (projectIdList.Count > 0)
                        {
                            GetBugInformationById(projectIdList[1], cmd, sumamry, "");
                        }
                    }
                    finally
                    {
                        if (conn != null && conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return sumamry;
        }

        /// <summary>
        /// Gets the custom field names and values associated with the given bug
        /// </summary>
        /// <param name="bugId">Bug Id</param>
        /// <returns>Dictionary of custom fields and values</returns>
        public Dictionary<string, string> GetCustomFieldValues(int bugId)
        {
            Dictionary<string, string> customFieldValues = new Dictionary<string, string>();
            using (var context = new RedmineDBContext())
            {
                DataTable table = new DataTable();
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT custom_fields.name, custom_values.value FROM `custom_values` INNER JOIN custom_fields ON custom_fields.id = custom_values.custom_field_id  WHERE customized_id =@bugId";
                    cmd.Parameters.AddWithValue("@bugId", bugId);
                    table.Load(cmd.ExecuteReader());
                    foreach (DataRow row in table.Rows)
                    {
                        customFieldValues[row[0].ToString()] = row[1].ToString();
                    }
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }

            return customFieldValues;
        }

        /// <summary>
        /// Deletes the issues from issues table
        /// </summary>
        /// <param name="bugId">Issue Id</param>
        /// <returns>Status of deletion</returns>
        /// 2020/05/15, Vinoth N, C51165_Modified delete for related bugs
        public bool DeleteIssues(int bugId)
        {
            bool deleted = false;
            try
            {
                using (RedmineDBContext dbContext = new RedmineDBContext())
                {
                    MySqlCommand cmd = new MySqlCommand();
                    MySqlConnection conn = new MySqlConnection(connString);
                    try
                    {
                        conn.Open();
                        cmd.Connection = conn;
                        /* C51165 mod START Modification for delete related bugs */
                        cmd.CommandText = "DELETE FROM issues where id=@bugId; DELETE FROM issue_relations where issue_relations.issue_from_id = @bugId or issue_relations.issue_to_id = @bugId;";
                        /* C51165 mod START Modification for delete related bugs */
                        cmd.Parameters.AddWithValue("@bugId", bugId);
                        deleted = cmd.ExecuteNonQuery() > 0;
                    }
                    finally
                    {
                        if (conn != null && conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return deleted;
        }

        /// <summary>
        /// Sets user id to a bug in order to assign the bug to the user
        /// </summary>
        /// <param name="userId">Id of the user</param>
        /// <param name="bugId">Id of the issue</param>
        public void AssignBugToUser(string userId, string bugId)
        {
            try
            {
                using (RedmineDBContext dbContext = new RedmineDBContext())
                {
                    MySqlCommand cmd = new MySqlCommand();
                    MySqlConnection conn = new MySqlConnection(connString);
                    try
                    {
                        conn.Open();
                        cmd.Connection = conn;
                        cmd.CommandText = "UPDATE issues SET assigned_to_id = @userId WHERE id = @bugId";
                        cmd.Parameters.AddWithValue("@userId", userId);
                        cmd.Parameters.AddWithValue("@bugId", bugId);
                        cmd.ExecuteReader();
                    }
                    finally
                    {
                        if (conn != null && conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
        }

        /// <summary>
        /// Method returns the id of the project
        /// </summary>
        /// <param name="projectName">Name of the project</param>
        /// <param name="parentId">Parent id of the project</param>
        /// <returns>Returns id of the project</returns>
        public int GetProjectId(string projectName, string parentId)
        {
            int id = -1;
            List<int> returnId = new List<int>();
            using (var dbContext = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT id FROM `projects` WHERE name =@projectName ";
                    if (!string.IsNullOrEmpty(parentId))
                    {
                        cmd.CommandText = cmd.CommandText + "and parent_id = " + parentId;
                    }
                    cmd.Parameters.AddWithValue("@projectName", projectName);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            id = Convert.ToInt32(reader[0]);
                        }
                    }
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }

            return id;
        }

        /// <summary>
        /// Method to delete a product
        /// </summary>
        /// <param name="projectId">Unique id of the project</param>
        /// <returns>Returns delete status</returns>
        /// 2019/01/30, Sujith A ,VJP192
        public bool DeleteProject(int projectId)
        {
            bool status = false;
            List<int> returnId = new List<int>();
            using (var dbContext = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "UPDATE projects set status=5 WHERE id =@projectId ";
                    cmd.Parameters.AddWithValue("@projectId", projectId);
                    status = cmd.ExecuteNonQuery() > 0;
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }

            return status;
        }

        /// <summary>
        /// Method to restore a deleted product
        /// </summary>
        /// <param name="projectId">Unique id of the project</param>
        /// <returns>Returns restore status</returns>
        /// 2019/03/12, Sharon Thankachan ,VJP192
        public bool RestoreProject(int projectId)
        {
            bool status = false;
            List<int> returnId = new List<int>();
            using (var dbContext = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "UPDATE projects set status=1 WHERE id =@projectId ";
                    cmd.Parameters.AddWithValue("@projectId", projectId);
                    status = cmd.ExecuteNonQuery() > 0;
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }

            return status;
        }

        /// <summary>
        /// Method to retrieve members in the project
        /// </summary>
        /// <param name="projectId">Unique id of the project</param>
        /// <returns>Returns members in the project</returns>
        /// 2019/01/30, Sujith A ,VJP192
        public List<Objects.User> GetMembers(int projectId)
        {
            List<Objects.User> members = new List<Objects.User>();
            using (var context = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    string memberGetQuery = "SELECT members.user_id,users.login FROM `members` INNER JOIN users on members.user_id=users.id WHERE `project_id`= @projectId";
                    cmd.Parameters.Clear();
                    cmd.CommandText = memberGetQuery;
                    cmd.Parameters.AddWithValue("@projectId", projectId);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Objects.User user = new Objects.User();
                            user.Id = Convert.ToInt32(reader[0].ToString());
                            user.Login = reader[1].ToString();
                            members.Add(user);
                        }
                    }
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }

            return members;
        }

        /// <summary>
        /// Method to retrieve projects of the logged in user
        /// </summary>
        /// <param name="token">Logged in user token</param>
        /// <returns>Returns project list</returns>
        /// 2019/02/11, Sujith A ,VJP192- Initial version
        public List<int> GetProjectsofUser(string token)
        {
            List<int> members = new List<int>();
            RMUserRepository repo = new RMUserRepository();
            string login = repo.GetLogin(token);
            string memberGetQuery = "";
            if (login.ToLower() == "tmfadmin")
            {
                memberGetQuery = "SELECT id FROM `projects`";
            }
            else
            {

                memberGetQuery = "SELECT members.project_id FROM `members` INNER JOIN users on members.user_id=users.id WHERE users.login= @login";
            }
            using (var context = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.Parameters.Clear();
                    cmd.CommandText = memberGetQuery;
                    cmd.Parameters.AddWithValue("@login", login);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = Convert.ToInt32(reader[0].ToString());
                            members.Add(id);
                        }
                    }
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }

            return members;
        }

        /// <summary>
        /// Method to update project 
        /// </summary>
        /// <param name="projectId">Unique id of the project</param>
        /// <param name="name">Name of the project</param>
        /// <param name="description">Description of the project</param>
        /// 2019/02/11, Sujith A ,VJP192- Initial version
        public bool UpdateProject(int projectId, string name, string description)
        {
            bool status = false;
            using (var context = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "update projects set name=@name,description=@description where id=@projectId";
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@description", description);
                    cmd.Parameters.AddWithValue("@projectId", projectId);
                    status = cmd.ExecuteNonQuery() > 0;
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }

            return status;
        }

        /// <summary>
        /// Method to get chart and report data for bugs
        /// </summary>
        /// <param name="filterData">filter data</param>
        /// <param name="linkedBugs">linked bugs</param>
        /// <returns>Data for chart and reports of bugs</returns>
        /// 2019/06/26, Sharon Thankachan, WG3736_Initial Version
        /// 2019/10/01, Vinoth N, WG3736_Modification for Localization
        /// 2020/01/27, Vinoth N, B1K017_Modification for Tabular data based on “Assigned To” in bugs
        /* WG3736 new START For Charts and reports*/
        public DataSet GetBugChartData(ReportFilter filterData, string linkedBugs)
        {
            TMFLogger.LogMethodEntry();
            /* WG3736 mod START Modification for Localization */
            string cultureInfo = "SET lc_time_names = '" + CultureInfo.CurrentCulture.ToString() + "';";
            cultureInfo = cultureInfo.Replace("-", "_");
            /* WG3736 mod END Modification for Localization */
            DataSet reportData = new DataSet();
            using (var context = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;

                    string conditionScript = string.Empty;
                    string moduleName = string.IsNullOrWhiteSpace(filterData.ModuleName) ? "0" : filterData.ModuleName;
                    if (!string.IsNullOrWhiteSpace(filterData.DocumentName) && filterData.DocumentName.Split(',').Length == 1)
                    {
                        conditionScript = " I.id in (" + linkedBugs + ") ";
                    }
                    else
                        conditionScript = " (project_id in (" + moduleName + ")  or  project_id in (select id from projects WHERE parent_id in (" + moduleName + "))) ";

                    DataTable bugCountByStatus = new DataTable();

                    cmd.CommandText = "SELECT  "
                            + "	ISTAT.name as label,IFNULL(count(I.id),0) as count  "
                        + "FROM  "
                            + "	bitnami_redmine.issue_statuses ISTAT  "
                        + "left join  "
                            + "	bitnami_redmine.issues I  "
                        + "on  "
                            + "	I.status_id = ISTAT.id  "
                        + "where  "
                            + "	DATE(I.created_on) between IFNULL(@fromDate,(select min(issues.created_on) from issues)) AND IFNULL(@toDate,(select max(issues.created_on) from issues))   ";
                    if (conditionScript.Length > 0)
                    {
                        cmd.CommandText += "and  " + conditionScript;
                    }
                    cmd.CommandText += " group by  "
                            + "	ISTAT.name  "
                        + "order by  "
                            + "	ISTAT.position";

                    cmd.Parameters.AddWithValue("@fromDate", filterData.FromDate);
                    cmd.Parameters.AddWithValue("@toDate", filterData.ToDate);
                    bugCountByStatus.Load(cmd.ExecuteReader());
                    reportData.Tables.Add(bugCountByStatus);

                    DataTable bugCountByImportance = new DataTable();

                    cmd.CommandText = "SELECT CV.value as label, count(CV.value) as count FROM  "
                           + "	bitnami_redmine.custom_values CV "
                       + "inner Join "
                           + "	bitnami_redmine.issues I "
                       + "on  "
                           + "	CV.customized_id = I.id "
                       + "where  "
                           + "	CV.custom_field_id in (select id from custom_fields where name = 'Importance')  ";
                    if (conditionScript.Length > 0)
                    {
                        cmd.CommandText += " and customized_id in (select id from  bitnami_redmine.issues  where " + conditionScript + ") ";
                    }
                    cmd.CommandText +=
                        "and  "
                            + "	DATE(I.created_on) between IFNULL(@fromDate,(select min(issues.created_on) from issues)) AND IFNULL(@toDate,(select max(issues.created_on) from issues)) "
                        + "and  "
                            + "	CV.value is not null  "
                        + "group by  "
                            + "	CV.value";
                    bugCountByImportance.Load(cmd.ExecuteReader());
                    reportData.Tables.Add(bugCountByImportance);
                    string calenderTable = "(  select DATE_FORMAT(IFNULL(@toDate,(select max(issues.created_on) from issues)), '%Y-%m-%d') - interval (a.a+(10*b.a)+(100*c.a)+(1000*d.a)) day aDate from  " +
                                "(select 0 as a union all select 1 union all select 2 union all select 3   " +
                                "union all select 4 union all select 5 union all select 6 union all   " +
                                "select 7 union all select 8 union all select 9) a, /*10 day range*/  " +
                                "(select 0 as a union all select 1 union all select 2 union all select 3   " +
                                "union all select 4 union all select 5 union all select 6 union all   " +
                                "select 7 union all select 8 union all select 9) b, /*100 day range*/  " +
                                "(select 0 as a union all select 1 union all select 2 union all select 3   " +
                                "union all select 4 union all select 5 union all select 6 union all   " +
                                "select 7 union all select 8 union all select 9) c, /*1000 day range*/  " +
                                "(select 0 as a union all select 1 union all select 2 union all select 3   " +
                                "union all select 4 union all select 5 union all select 6 union all   " +
                                "select 7 union all select 8 union all select 9) d /*10000 day range*/) CALENDER ";
                    DataTable bugCountBarMonthly = new DataTable();
                    /* WG3736 mod START Modification for Localization */
                    cmd.CommandText = cultureInfo + "select DATE_FORMAT(aDate, '%Y %b') as label,IFNULL(sum(n.TOTAL),0) as count from " +
                                calenderTable +
                                "LEFT JOIN " +
                                "(	SELECT DATE_FORMAT(created_on, '%Y-%m-%d') AS MYDATE, 	COUNT(I.id) AS TOTAL,	(select YEAR(I.created_on)) as YEAR	" +
                                "FROM issues I 	WHERE DATE(I.created_on) BETWEEN IFNULL(@fromDate,(select min(issues.created_on) from issues)) AND IFNULL(@toDate,(select max(issues.created_on) from issues)) 	";
                    if (conditionScript.Length > 0)
                    {
                        cmd.CommandText += "and  " + conditionScript;
                    }
                    cmd.CommandText +=
                                "GROUP BY YEAR(I.created_on), MONTH(I.created_on), DAY(I.created_on)	" +
                                "ORDER BY I.created_on) n " +
                                "ON CALENDER.aDate = n.MYDATE " +
                                "where DATE(aDate) between DATE_FORMAT(IFNULL(@fromDate,(select min(issues.created_on) from issues)), '%Y-%m-%d') and DATE_FORMAT(IFNULL(@toDate,(select max(issues.created_on) from issues)), '%Y-%m-%d') " +
                                "group by YEAR(aDate),MONTH(aDate)";

                    bugCountBarMonthly.Load(cmd.ExecuteReader());
                    reportData.Tables.Add(bugCountBarMonthly);
                    DataTable bugCountClosedBarMonthly = new DataTable();
                    cmd.CommandText = cultureInfo + "select DATE_FORMAT(aDate, '%Y %b') as label,IFNULL(sum(n.TOTAL),0) as count from " +
                    calenderTable +
                    "LEFT JOIN " +
                    "(	SELECT DATE_FORMAT(closed_on, '%Y-%m-%d') AS MYDATE, 	COUNT(I.id) AS TOTAL,	(select YEAR(I.closed_on)) as YEAR	" +
                    "FROM issues I 	WHERE closed_on is not null and DATE(I.created_on) BETWEEN IFNULL(@fromDate,(select min(issues.created_on) from issues)) AND IFNULL(@toDate,(select max(issues.created_on) from issues)) 	";
                    if (conditionScript.Length > 0)
                    {
                        cmd.CommandText += "and  " + conditionScript;
                    }
                    cmd.CommandText +=
                        "GROUP BY YEAR(I.closed_on), MONTH(I.closed_on), DAY(I.closed_on)) n " +
                    "ON CALENDER.aDate = n.MYDATE " +
                    "where DATE(aDate) between DATE_FORMAT(IFNULL(@fromDate,(select min(issues.created_on) from issues)), '%Y-%m-%d') and DATE_FORMAT(IFNULL(@toDate,(select max(issues.created_on) from issues)), '%Y-%m-%d') " +
                    "group by YEAR(aDate),MONTH(aDate)";

                    bugCountClosedBarMonthly.Load(cmd.ExecuteReader());
                    reportData.Tables.Add(bugCountClosedBarMonthly);

                    DataTable bugCountBarWeekly = new DataTable();
                    cmd.CommandText = cultureInfo + "select YEAR(aDate) as YEAR, week(aDate) as WEEK,IFNULL(sum(n.TOTAL),0) as count from " +
                               calenderTable +
                               "LEFT JOIN " +
                               "(	SELECT DATE_FORMAT(created_on, '%Y-%m-%d') AS MYDATE, 	COUNT(I.id) AS TOTAL,	(select YEAR(I.created_on)) as YEAR	" +
                               "FROM issues I 	WHERE DATE(I.created_on) BETWEEN IFNULL(@fromDate,(select min(issues.created_on) from issues)) AND IFNULL(@toDate,(select max(issues.created_on) from issues)) 	";
                    if (conditionScript.Length > 0)
                    {
                        cmd.CommandText += "and  " + conditionScript;
                    }
                    cmd.CommandText +=
                               "GROUP BY YEAR(I.created_on), MONTH(I.created_on), DAY(I.created_on)	" +
                               "ORDER BY I.created_on) n " +
                               "ON CALENDER.aDate = n.MYDATE " +
                               "where DATE(aDate) between DATE_FORMAT(IFNULL(@fromDate,(select min(issues.created_on) from issues)), '%Y-%m-%d') and DATE_FORMAT(IFNULL(@toDate,(select max(issues.created_on) from issues)), '%Y-%m-%d') " +
                               "group by YEAR(aDate),WEEK(aDate) order by YEAR(aDate),WEEK(aDate)";
                    bugCountBarWeekly.Load(cmd.ExecuteReader());
                    reportData.Tables.Add(bugCountBarWeekly);

                    DataTable bugCountClosedBarWeekly = new DataTable();
                    cmd.CommandText = cultureInfo + "select YEAR(aDate) as YEAR, week(aDate) as WEEK,IFNULL(sum(n.TOTAL),0) as count from " +
                               calenderTable +
                               "LEFT JOIN " +
                               "(	SELECT DATE_FORMAT(closed_on, '%Y-%m-%d') AS MYDATE, 	COUNT(I.id) AS TOTAL,	(select YEAR(I.created_on)) as YEAR	" +
                               "FROM issues I 	WHERE DATE(I.created_on) BETWEEN IFNULL(@fromDate,(select min(issues.created_on) from issues)) AND IFNULL(@toDate,(select max(issues.created_on) from issues)) 	";
                    if (conditionScript.Length > 0)
                    {
                        cmd.CommandText += "and  " + conditionScript;
                    }
                    cmd.CommandText +=
                               "GROUP BY YEAR(I.closed_on), MONTH(I.closed_on), DAY(I.closed_on)	" +
                               "ORDER BY I.created_on) n " +
                               "ON CALENDER.aDate = n.MYDATE " +
                               "where DATE(aDate) between DATE_FORMAT(IFNULL(@fromDate,(select min(issues.created_on) from issues)), '%Y-%m-%d') and DATE_FORMAT(IFNULL(@toDate,(select max(issues.created_on) from issues)), '%Y-%m-%d') " +
                               "group by YEAR(aDate),WEEK(aDate) order by YEAR(aDate),WEEK(aDate)";
                    bugCountClosedBarWeekly.Load(cmd.ExecuteReader());
                    reportData.Tables.Add(bugCountClosedBarWeekly);

                    DataTable bugCountBarDaily = new DataTable();
                    cmd.CommandText = cultureInfo + "select DATE_FORMAT(aDate, '%y-%b-%d') as label,IFNULL(sum(n.TOTAL),0) as count from " +
                                 calenderTable +
                                 "LEFT JOIN " +
                                 "(	SELECT DATE_FORMAT(created_on, '%Y-%m-%d') AS MYDATE, 	COUNT(I.id) AS TOTAL,	(select YEAR(I.created_on)) as YEAR	" +
                                 "FROM issues I 	WHERE DATE(I.created_on) BETWEEN IFNULL(@fromDate,(select min(issues.created_on) from issues)) AND IFNULL(@toDate,(select max(issues.created_on) from issues)) 	";
                    if (conditionScript.Length > 0)
                    {
                        cmd.CommandText += "and  " + conditionScript;
                    }
                    cmd.CommandText +=
                                 "GROUP BY YEAR(I.created_on), MONTH(I.created_on), DAY(I.created_on)	" +
                                 "ORDER BY I.created_on) n " +
                                 "ON CALENDER.aDate = n.MYDATE " +
                                 "where DATE(aDate) between DATE_FORMAT(IFNULL(@fromDate,(select min(issues.created_on) from issues)), '%Y-%m-%d') and DATE_FORMAT(IFNULL(@toDate,(select max(issues.created_on) from issues)), '%Y-%m-%d') " +
                                 "group by YEAR(aDate),MONTH(aDate),DAY(aDate)";
                    bugCountBarDaily.Load(cmd.ExecuteReader());
                    reportData.Tables.Add(bugCountBarDaily);

                    DataTable bugCountClosedBarDaily = new DataTable();
                    cmd.CommandText = cultureInfo + "select DATE_FORMAT(aDate, '%y-%b-%d') as label,IFNULL(sum(n.TOTAL),0) as count from " +
                                calenderTable +
                                "LEFT JOIN " +
                                "(	SELECT DATE_FORMAT(closed_on, '%Y-%m-%d') AS MYDATE, 	COUNT(I.id) AS TOTAL,	(select YEAR(I.closed_on)) as YEAR	" +
                                "FROM issues I 	WHERE closed_on is not null and DATE(I.created_on) BETWEEN IFNULL(@fromDate,(select min(issues.created_on) from issues)) AND IFNULL(@toDate,(select max(issues.created_on) from issues)) 	";
                    if (conditionScript.Length > 0)
                    {
                        cmd.CommandText += "and  " + conditionScript;
                    }
                    /* WG3736 mod END Modification for Localization */
                    cmd.CommandText +=
                                "GROUP BY YEAR(I.closed_on), MONTH(I.closed_on), DAY(I.closed_on)) n " +
                                "ON CALENDER.aDate = n.MYDATE " +
                                "where DATE(aDate) between DATE_FORMAT(IFNULL(@fromDate,(select min(issues.created_on) from issues)), '%Y-%m-%d') and DATE_FORMAT(IFNULL(@toDate,(select max(issues.created_on) from issues)), '%Y-%m-%d') " +
                                "group by YEAR(aDate),MONTH(aDate),DAY(aDate)";
                    bugCountClosedBarDaily.Load(cmd.ExecuteReader());
                    reportData.Tables.Add(bugCountClosedBarDaily);

                    DataTable bugCountByEngineer = new DataTable();
                    cmd.CommandText = "SELECT U.login as ENGINEER,S.name as STATUS, count(I.id) as COUNT " +
                        "FROM bitnami_redmine.issues I " +
                        "join issue_statuses S " +
                        "on S.id = I.status_id and DATE(I.created_on) BETWEEN IFNULL(@fromDate,(select min(issues.created_on) from issues)) AND IFNULL(@toDate,(select max(issues.created_on) from issues)) ";
                    if (conditionScript.Length > 0)
                    {
                        cmd.CommandText += "and  " + conditionScript;
                    }
                    cmd.CommandText +=
                        "join users U on I.author_id = U.id " +
                        "where U.admin = 1 and U.status != 0 " +
                        "group by U.login, S.name order by S.name, U.login";
                    bugCountByEngineer.Load(cmd.ExecuteReader());
                    reportData.Tables.Add(bugCountByEngineer);
                    /* B1K017 mod START Modification for Tabular data based on “Assigned To” in bugs */
                    DataTable bugAssignedToUsers = new DataTable();
                    cmd.CommandText = "SELECT U.login as ENGINEER,S.name as STATUS, count(I.id) as COUNT " +
                        "FROM bitnami_redmine.issues I " +
                        "join issue_statuses S " +
                        "on S.id = I.status_id and DATE(I.created_on) BETWEEN IFNULL(@fromDate,(select min(issues.created_on) from issues)) AND IFNULL(@toDate,(select max(issues.created_on) from issues)) ";
                    if (conditionScript.Length > 0)
                    {
                        cmd.CommandText += "and  " + conditionScript;
                    }
                    cmd.CommandText +=
                        "join users U on I.assigned_to_id = U.id " +
                        "where U.admin = 1 and U.status != 0 " +
                        "group by U.login, S.name order by S.name, U.login";

                    bugAssignedToUsers.Load(cmd.ExecuteReader());
                    reportData.Tables.Add(bugAssignedToUsers);
                    /* B1K017 mod END Modification for Tabular data based on “Assigned To” in bugs */
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
            TMFLogger.LogMethodExit();

            return reportData;
        }
        /* WG3736 new END For Charts and reports*/

        /// <summary>
        /// Method to get bug titles
        /// </summary>
        /// <param name="bugID">collection of bugIds</param>
        /// <return>Return title.</return>
        /// 2019/07/31, Vinoth N, WG3736_Initial Version
        public ListDictionary GetBugTitle(List<string> bugId)
        {
            ListDictionary bugDetails = new ListDictionary();
            var resultBugID = String.Join(", ", bugId.ToArray());
            string query = "SELECT subject,id FROM `issues` where Id in(" + resultBugID.ToString() + ")";
            using (RedmineDBContext dbContext = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = query;
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            if (reader["subject"] != DBNull.Value && reader["id"] != DBNull.Value)
                                bugDetails.Add(reader["id"].ToString(), reader["subject"].ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
            return bugDetails;
        }

        /// <summary>
        /// Method to return recently assigned bugs 
        /// </summary>
        /// <param name="productName">product name</param>
        /// <param name="versionName">version name</param>
        /// <param name="userName">user name</param>
        /// <param name="limit">skip count</param>
        /// <returns>Return list of bugs</returns>
        /// 2020/06/19, Vinoth N, C51165_Initial Version
        public List<BugSummary> GetRecentlyAssignedBugs(string projectName, string versionName, string userName, int limit)
        {
            List<BugSummary> bugSummary = new List<BugSummary>();
            using (var context = new RedmineDBContext())
            {
                DataTable table = new DataTable();
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    bugIds.Clear();
                    subProjetcs.Clear();
                    List<int> projectIdList = IsProjectValid(cmd, projectName, versionName);
                    if (projectIdList.Count > 0)
                    {
                        var query = "select * from (select issues.id,issues.subject,issues.tracker_id,issues.description,issues.status_id,issues.created_on,issues.updated_on, " +
                            "custom_values.value, users.login,projects.name, projects.parent_id as moduleId from issues " +
                            "left join projects on issues.project_id = projects.id " +
                            "inner join users on users.id = issues.assigned_to_id " +
                            "LEFT JOIN custom_values on custom_values.customized_id = issues.id and custom_field_id = (select id from custom_fields where name = 'Importance') " +
                            "Left Join issue_relations on issue_relations.issue_from_id = issues.id or issue_relations.issue_to_id = issues.id " +
                            "WHERE project_id = @projectId or project_id in (select id from projects WHERE parent_id = @projectId) or project_id in  " +
                            "(select id from projects WHERE parent_id in (select id from projects WHERE parent_id = @projectId))";
                        query += "group by issues.id,issues.subject,issues.tracker_id,issues.description,issues.status_id,issues.created_on,issues.updated_on, " +
                            "custom_values.value, users.login,projects.name, projects.parent_id " +
                            "order by issues.updated_on desc) bugs {0} {1}";

                        if (limit > 0)
                        {
                            query = String.Format(query, "where login = @userName ", String.Concat("limit ", limit));
                        }
                        else
                            query = String.Format(query, "where login = @userName ", String.Empty);

                        cmd.CommandText = query;
                        cmd.Parameters.AddWithValue("@projectId", projectIdList[1]);
                        cmd.Parameters.AddWithValue("@userName", userName);
                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            da.SelectCommand.CommandTimeout = 1800;
                            da.Fill(table);
                        }
                        foreach (DataRow row in table.Rows)
                        {
                            string assigneeId = string.Empty;
                            int bugId = Convert.ToInt32(row["id"]);
                            if (!bugIds.Contains(bugId))
                            {
                                string status = string.Empty;
                                IssueStatuses statusId = (IssueStatuses)Convert.ToInt32(row["status_id"]);
                                status = statusId.ToString();
                                string severity = row["value"] != DBNull.Value ? row["value"].ToString() : string.Empty;
                                BugImportance bugSeverity;
                                Enum.TryParse(severity.ToString(), out bugSeverity);
                                string updatedDate = row["updated_on"].ToString();
                                string moduleId = row["moduleId"].ToString();
                                string createdDate = row["created_on"].ToString();
                                if (row[8] != DBNull.Value)
                                {
                                    assigneeId = row["login"].ToString();
                                }
                                var moduleName = row["name"].ToString();
                                BugSummary bug = new BugSummary()
                                {
                                    Id = bugId,
                                    Subject = row["subject"] != DBNull.Value ? row["subject"].ToString() : string.Empty,
                                    UpdatedDate = updatedDate.Substring(0, updatedDate.IndexOf(' ')),
                                    CreatedDate = createdDate.Substring(0, createdDate.IndexOf(' ')),
                                    Status = status,
                                    Assignee = assigneeId,
                                    Description = row["description"] != DBNull.Value ? row["description"].ToString() : string.Empty,
                                    Severity = bugSeverity,
                                    ModuleName = moduleName,
                                    ModuleId = Convert.ToInt32(moduleId)
                                };
                                bugSummary.Add(bug);
                                bugIds.Add(bugId);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        cmd.Parameters.Clear();
                        conn.Close();
                    }
                }
            }
            return bugSummary;
        }

        /// <summary>
        /// Method to get all projects of the user
        /// </summary>
        /// <param name="projectName">project name</param>
        /// <param name="versionName">version name</param>
        /// <param name="userName">user name</param>
        /// <returns>module and doc list</returns>
        public DataTable GetMemberProjectList(string projectName, string versionName, string userName)
        {
            DataTable MemberProjectList = new DataTable();
            try
            {
                using (var context = new RedmineDBContext())
                {
                    MySqlCommand cmd = new MySqlCommand();
                    MySqlConnection conn = new MySqlConnection(connString);
                    try
                    {
                        conn.Open();
                        cmd.Connection = conn;
                        cmd.CommandText = "SELECT" +
                            "    modul.id, modul.name as modName, doc.name as docName" +
                            " FROM" +
                            "    bitnami_redmine.users usr" +
                            "        JOIN" +
                            "    members mbr ON usr.id = mbr.user_id" +
                            "        JOIN" +
                            "    projects pjt ON pjt.id = mbr.project_id" +
                            "        AND pjt.status = 1" +
                            "        JOIN" +
                            "    projects ver ON pjt.id = ver.parent_id" +
                            "        AND ver.status = 1" +
                            "        JOIN" +
                            "    projects modul ON ver.id = modul.parent_id" +
                            "        AND modul.status = 1" +
                            "        JOIN" +
                            "    projects doc ON modul.id = doc.parent_id" +
                            "        AND doc.status = 1" +
                            " WHERE" +
                            "    (pjt.parent_id IS NULL" +
                            "        AND pjt.name = @projectName)" +
                            "        AND(ver.name = @versionName)" +
                            "        AND usr.login = CASE WHEN LOWER(@userName) = 'tmfadmin' THEN usr.login ELSE @userName END" +
                            " GROUP BY id , modName , docName";
                        cmd.Parameters.AddWithValue("@projectName", projectName);
                        cmd.Parameters.AddWithValue("@versionName", versionName);
                        cmd.Parameters.AddWithValue("@userName", userName);

                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            //da.SelectCommand.CommandTimeout = 1800;
                            da.Fill(MemberProjectList);
                        }
                    }
                    catch (Exception ex)
                    {
                        TMFLogger.LogException(ex);
                    }
                    finally
                    {
                        if (conn != null && conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return MemberProjectList;
        }

        /// <summary>
        /// Method to get default user
        /// </summary>
        /// <returns>return default user</returns>
        public UserModel GetDefaultUser()
        {
            UserModel usr = new UserModel();
            DataTable memberList = new DataTable();
            try
            {
                using (var context = new RedmineDBContext())
                {
                    MySqlCommand cmd = new MySqlCommand();
                    MySqlConnection conn = new MySqlConnection(connString);
                    try
                    {
                        conn.Open();
                        cmd.Connection = conn;
                        cmd.CommandText = "select * from bitnami_redmine.users where login = 'tmfadmin' and status = 1";
                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            da.Fill(memberList);
                        }
                        foreach (DataRow row in memberList.Rows)
                        {
                            usr = new UserModel()
                            {
                                Id = Convert.ToInt32(row["id"]),
                                Name = row["login"].ToString(),
                                Role = "SuperUser"
                            };
                        }
                    }
                    catch (Exception ex)
                    {
                        TMFLogger.LogException(ex);
                    }
                    finally
                    {
                        if (conn != null && conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return usr;
        }

        /// <summary>
        /// Method to get all project list
        /// </summary>
        /// <returns>module and doc list</returns>
        public List<CustomProjectModel> GetAllProjects()
        {
            DataTable proTable = new DataTable();
            List<CustomProjectModel> projects = new List<CustomProjectModel>();
            try
            {
                using (var context = new RedmineDBContext())
                {
                    MySqlCommand cmd = new MySqlCommand();
                    MySqlConnection conn = new MySqlConnection(connString);
                    try
                    {
                        conn.Open();
                        cmd.Connection = conn;
                        cmd.CommandText = "select id, name, ifnull(description, '') as description, status, ifnull(parent_id, 0) as parent_id, created_on, updated_on  from projects";
                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            da.Fill(proTable);
                        }
                        foreach (DataRow row in proTable.Rows)
                        {
                            string assigneeId = string.Empty;
                            int bugId = Convert.ToInt32(row["id"]);
                            if (!bugIds.Contains(bugId))
                            {
                                CustomProjectModel project = new CustomProjectModel()
                                {
                                    Id = Convert.ToInt32(row["id"]),
                                    Name = row["name"].ToString(),
                                    Status = Convert.ToInt32(row["status"]),
                                    Description = row["description"].ToString(),
                                    CreatedOn = Convert.ToDateTime(row["created_on"]),
                                    UpdatedOn = Convert.ToDateTime(row["updated_on"]),
                                    Parent = Convert.ToInt32(row["parent_id"])
                                };
                                projects.Add(project);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        TMFLogger.LogException(ex);
                    }
                    finally
                    {
                        if (conn != null && conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }

            return projects;
        }

        /// <summary>
        /// Method to create build settings.
        /// </summary>
        /// <param name="buildSettings">Build settings input.</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/08, Vinoth N, EL5873_Initial Version
        public bool CreateBuildSettings(BuildSettings buildSettings)
        {
            bool status;
            try
            {
                status = buildRepocitory.Create(buildSettings);
            }
            catch (Exception ex)
            {
                status = false;
                TMFLogger.LogException(ex);
            }
            return status;
        }

        /// <summary>
        /// Method to update build settings.
        /// </summary>
        /// <param name="buildSettings">Build settings input.</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/08, Vinoth N, EL5873_Initial Version
        public bool UpdateBuildSettings(BuildSettings buildSettings)
        {
            bool status;
            try
            {
                status = buildRepocitory.Update(buildSettings);
            }
            catch (Exception ex)
            {
                status = false;
                TMFLogger.LogException(ex);
            }
            return status;
        }

        /// <summary>
        /// Method to get build settings in version.
        /// </summary>
        /// <param name="productId">Product Id.</param>
        /// <param name="versionId">Version Id.</param>
        /// <returns>Returns build settings.</returns>
        /// 2021/06/09, Vinoth N, EL5873_Initial Version
        public BuildSettings GetBuildSettings(int productId, int versionId)
        {
            BuildSettings settings = new BuildSettings();
            try
            {
                object[] input = new object[] { productId , versionId};
                settings = buildRepocitory.GetAll(input);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return settings;
        }

        /// <summary>
        /// Method to create path settings.
        /// </summary>
        /// <param name="pathSettings">Path settings input.</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/09, Vinoth N, EL5873_Initial Version
        public bool CreatePathSettings(PathSettings pathSettings)
        {
            bool status;
            try
            {
                status = pathRepocitory.Create(pathSettings);
            }
            catch (Exception ex)
            {
                status = false;
                TMFLogger.LogException(ex);
            }
            return status;
        }

        /// <summary>
        /// Method to update path settings.
        /// </summary>
        /// <param name="pathSettings">Path settings input.</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/09, Vinoth N, EL5873_Initial Version
        public bool UpdatePathSettings(PathSettings pathSettings)
        {
            bool status;
            try
            {
                status = pathRepocitory.Update(pathSettings);
            }
            catch (Exception ex)
            {
                status = false;
                TMFLogger.LogException(ex);
            }
            return status;   
        }

        /// <summary>
        /// Method to get build settings in module.
        /// </summary>
        /// <param name="moduleId">Module Id.</param>
        /// <returns>Returns path settings.</returns>
        /// 2021/06/10, Vinoth N, EL5873_Initial Version
        public PathSettings GetPathSettings(int moduleId)
        {
            PathSettings settings = new PathSettings();
            try
            {
                object[] input = new object[] { moduleId };
                settings = pathRepocitory.GetAll(input);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return settings;
        }

        /// <summary>
        /// Method to get all the path settings in version
        /// </summary>
        /// <param name="versionId">Version Id.</param>
        /// <returns>Returns path settings.</returns>
        /// 2021/06/11, Vinoth N, EL5873_Initial Version
        public List<PathSettings> GetVersionPathSettings(int versionId)
        {
            List<PathSettings> output = new List<PathSettings>();
            using (var context = new RedmineDBContext())
            {
                DataTable settingsTable = new DataTable();
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT modul.id, modul.name FROM bitnami_redmine.users usr " +
                        "JOIN members mbr ON usr.id = mbr.user_id JOIN projects pjt ON pjt.id = mbr.project_id AND pjt.status = 1 " +
                        "JOIN projects ver ON pjt.id = ver.parent_id AND ver.status = 1 " +
                        "JOIN projects modul ON ver.id = modul.parent_id AND modul.status = 1 " +
                        "JOIN path_settings path ON modul.id = path.module_id " +
                        "WHERE pjt.parent_id IS NULL AND pjt.id = @projectId AND ver.id = @versionId";
                    cmd.Parameters.AddWithValue("@projectId", productId);
                    cmd.Parameters.AddWithValue("@versionId", versionId);
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(settingsTable);
                    }
                    foreach (DataRow row in settingsTable.Rows)
                    {
                        output.Add(new PathSettings()
                        {
                            Id = Convert.ToInt32(row["id"] ?? 0),
                            Name = row["name"].ToString(),   
                        });
                    }
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
            return output;
        }

        /// <summary>
        /// Method to retrive all the modules in version
        /// </summary>
        /// <param name="productId">Product Id.</param>
        /// <param name="versionId">Version Id.</param>
        /// <returns>Returns modules.</returns>
        /// 2021/06/10, Vinoth N, EL5873_Initial Version
        public List<ModuleDataModel> GetModules(int productId, int versionId)
        {
            List<ModuleDataModel> output = new List<ModuleDataModel>();
            using (var context = new RedmineDBContext())
            {
                DataTable settingsTable = new DataTable();
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT modul.id, modul.name FROM bitnami_redmine.users usr " +
                        "WHERE pjt.parent_id IS NULL AND pjt.id = @projectId AND ver.id = @versionId";
                    cmd.Parameters.AddWithValue("@projectId", productId);
                    cmd.Parameters.AddWithValue("@versionId", versionId);
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(settingsTable);
                    }
                    foreach (DataRow row in settingsTable.Rows)
                    {
                        output.Add(new ModuleDataModel()
                        {
                            Id = Convert.ToInt32(row["id"] ?? 0),
                            Name = row["name"].ToString(),   
                        });
                    }
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
            return output;
        }
        #endregion

        #region Private methods

        /// <summary>
        /// Verify a project is valid
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="projectName"></param>
        /// <param name="versionName"></param>
        /// <returns></returns>
        private List<int> IsProjectValid(MySqlCommand cmd, string projectName, string versionName)
        {
            int parentId = 0;
            List<int> returnId = new List<int>();
            using (var context = new RedmineDBContext())
            {
                cmd.CommandText = "SELECT id FROM `projects` WHERE name =@projectName";
                cmd.Parameters.AddWithValue("@projectName", projectName);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        parentId = Convert.ToInt32(reader[0]);
                    }
                }
                if (parentId > 0)
                {
                    cmd.CommandText = "SELECT name,id FROM `projects` WHERE parent_id =" + parentId + "";
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string vrName = reader[0].ToString();
                            int id = Convert.ToInt32(reader[1]);
                            if (vrName.Equals(versionName))
                            {
                                returnId.Add(parentId);
                                returnId.Add(id);
                            }
                        }
                    }
                }
            }
            return returnId;
        }


        /// <summary>
        /// Gets the subproject names of a Main project
        /// </summary>
        /// <param name="versionName">version name</param>
        /// <param name="cmd">SQL command instance</param>
        /// <param name="moduleList">module list</param>
        /// <param name="projectId">project id</param>
        private void GetSubProjects(string versionName, MySqlCommand cmd, List<BaseData> moduleList = null, int projectId = 0)
        {
            bool subProjectFound = false;
            int projetcId = 0;
            using (var context = new RedmineDBContext())
            {
                if (projectId == 0)
                {
                    cmd.CommandText = "SELECT id FROM `projects` WHERE name =@versionName";
                    cmd.Parameters.AddWithValue("@versionName", versionName);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            projetcId = Convert.ToInt32(reader[0]);
                            subProjectFound = true;
                        }
                        else
                        {
                            subProjectFound = false;
                        }
                    }
                }
                else
                {
                    projetcId = projectId;
                    subProjectFound = true;
                }

                if (subProjectFound)
                {
                    cmd.CommandText = "SELECT name,id FROM `projects` WHERE parent_id =" + projetcId + " ";
                    DataTable table = new DataTable();
                    table.Load(cmd.ExecuteReader());
                    foreach (DataRow row in table.Rows)
                    {
                        string subPro = row[0].ToString();
                        int id = Convert.ToInt32(row[1]);
                        if (moduleList != null)
                        {
                            BaseData module = (from mdl in moduleList
                                               where mdl.Id == id
                                               select mdl).FirstOrDefault();
                            if (module != null)
                            {
                                globalModuleName = module.Name;
                            }
                        }
                        subProjetcs.Add(new SubProject { SubProjectName = subPro, ModuleName = globalModuleName, Id = id });
                        GetSubProjects(subPro, cmd, moduleList, id);
                    }
                }
            }
        }

        /// <summary>
        /// Gets the subproject names of a Main project
        /// </summary>
        /// <param name="mainProjectName">Main project name</param>
        /// <param name="cmd">SQL command instance</param>
        /// <param name="parentId">project Id</param>
        /// <returns>Return base data</returns>
        private List<BaseData> GetModuleList(string mainProjectName, MySqlCommand cmd, int parentId)
        {
            List<BaseData> moduleList = new List<BaseData>();
            bool subProjectFound = false;
            int projetcId = 0;
            using (var context = new RedmineDBContext())
            {
                cmd.CommandText = "SELECT id FROM `projects` WHERE name = @mainProjectName and parent_id=@parentId";
                cmd.Parameters.AddWithValue("@mainProjectName", mainProjectName);
                cmd.Parameters.AddWithValue("@parentId", parentId);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        projetcId = Convert.ToInt32(reader[0]);
                        subProjectFound = true;
                    }
                    else
                    {
                        subProjectFound = false;
                    }
                }

                if (subProjectFound)
                {
                    cmd.CommandText = "SELECT name,id FROM `projects` WHERE parent_id =" + projetcId + " ";
                    DataTable table = new DataTable();
                    table.Load(cmd.ExecuteReader());
                    foreach (DataRow row in table.Rows)
                    {
                        string subPro = row[0].ToString();
                        int id = Convert.ToInt32(row[1]);
                        moduleList.Add(new BaseData { Id = id, Name = subPro });
                    }
                }
            }
            return moduleList;
        }

        /// <summary>
        /// Gets the bug information from database
        /// </summary>
        /// <param name="projectId">project id</param>
        /// <param name="cmd">SQL command instance</param>
        /// <param name="bugSummary">Bug summary instance</param>
        /// <param name="moduleName">module name</param>
        /// <param name="isParent">if is parent</param>
        /// <param name="token">token</param>
        /// 2020/05/15, Vinoth N, C51165_Modification for related bugs
        private void GetBugInformationById(int projectId, MySqlCommand cmd, List<BugSummary> bugSummary, string moduleName = "", bool isParent = false, string token = "")
        {
            using (var context = new RedmineDBContext())
            {
                DataTable table = new DataTable();
                /* C51165 mod START Modification for related bugs */
                cmd.CommandText = "select issues.id, GROUP_CONCAT(case when issue_relations.issue_to_id = issues.id then issue_relations.issue_from_id else issue_relations.issue_to_id end SEPARATOR ',') as relations,issues.subject,issues.tracker_id,issues.description,issues.status_id,issues.created_on,issues.updated_on, " +
                                  "custom_values.value, users.login,projects.name, projects.parent_id as moduleId from issues " +
                                  "left join projects on issues.project_id=projects.id left join users on users.id=issues.assigned_to_id " +
                                  "LEFT JOIN custom_values on custom_values.customized_id=issues.id and custom_field_id=(select id from custom_fields where name='Importance') " +
                                  "Left Join issue_relations on issue_relations.issue_from_id = issues.id or issue_relations.issue_to_id = issues.id " +
                                  "WHERE project_id = @projectId or project_id in (select id from projects WHERE parent_id = @projectId) or project_id in " +
                                  "(select id from projects WHERE parent_id in (select id from projects WHERE parent_id = @projectId)) " +
                                  "group by issues.id,issues.subject,issues.tracker_id,issues.description,issues.status_id,issues.created_on,issues.updated_on, " +
                                  "custom_values.value, users.login,projects.name, projects.parent_id;";
                cmd.Parameters.AddWithValue("@projectId", projectId);
                using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                {
                    da.SelectCommand.CommandTimeout = 1800;
                    da.Fill(table);
                }

                foreach (DataRow row in table.Rows)
                {
                    string assigneeId = string.Empty;
                    int bugId = Convert.ToInt32(row["id"]);
                    if (!bugIds.Contains(bugId))
                    {
                        string status = string.Empty;
                        IssueStatuses statusId = (IssueStatuses)Convert.ToInt32(row["status_id"]);
                        status = statusId.ToString();
                        string severity = row["value"] != DBNull.Value ? row["value"].ToString() : string.Empty; //GetSeverity(bugId, cmd);
                        BugImportance bugSeverity;
                        Enum.TryParse(severity.ToString(), out bugSeverity);
                        string updatedDate = row["updated_on"].ToString();
                        string moduleId = row["moduleId"].ToString();
                        string relations = row["relations"].ToString();
                        // 11-Sep-2018, Sujith A, V29627_Modification for Bug management
                        string createdDate = row["created_on"].ToString();
                        if (row[8] != DBNull.Value)
                        {
                            assigneeId = row["login"].ToString();
                        }
                        moduleName = row["name"].ToString();
                        BugSummary bug = new BugSummary()
                        {
                            Id = bugId,
                            Subject = row["subject"] != DBNull.Value ? row["subject"].ToString() : string.Empty,
                            UpdatedDate = updatedDate.Substring(0, updatedDate.IndexOf(' ')),
                            CreatedDate = createdDate.Substring(0, createdDate.IndexOf(' ')),
                            Status = status,
                            Assignee = assigneeId,
                            Description = row["description"] != DBNull.Value ? row["description"].ToString() : string.Empty,
                            Severity = bugSeverity,
                            ModuleName = moduleName,
                            ModuleId = Convert.ToInt32(moduleId),
                            RelationIds = relations ?? ""
                        };
                        /* C51165 mod END Modification for related bugs */
                        bugSummary.Add(bug);
                        bugIds.Add(bugId);
                    }
                }
            }
            cmd.Parameters.Clear();
        }

        /// <summary>
        /// Get related bugs from database
        /// </summary>
        /// <param name="bugId">Bug id</param>
        /// <param name="cmd">SQL command instance</param>
        /// <param name="bugSummary">Bug summary instance</param>
        /// <param name="token">token</param>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        private void GetBugInformationByBugId(int bugId, MySqlCommand cmd, List<BugSummary> bugSummary, string token = "")
        {
            using (var context = new RedmineDBContext())
            {
                DataTable table = new DataTable();
                cmd.CommandText = "select issues.id,issues.subject from issues left join projects on issues.project_id=projects.id " +
                                  "left join users on users.id = issues.assigned_to_id LEFT JOIN custom_values on custom_values.customized_id = issues.id and custom_field_id = (select id from custom_fields where name = 'Importance') " +
                                  "WHERE project_id in (select project_id from issues WHERE Id = @bugId)";
                cmd.Parameters.AddWithValue("@bugId", bugId);
                using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                {
                    da.SelectCommand.CommandTimeout = 1800;
                    da.Fill(table);
                }
                foreach (DataRow row in table.Rows)
                {
                    var Id = Convert.ToInt32(row["id"]);
                    if (Id != bugId)
                    {
                        BugSummary bug = new BugSummary()
                        {
                            Id = Id,
                            Subject = row["subject"] != DBNull.Value ? row["subject"].ToString() : string.Empty
                        };
                        bugSummary.Add(bug);
                        bugIds.Add(Id);
                    }
                }
            }
            cmd.Parameters.Clear();
        }

        /// <summary>
        /// Method to get severity pf bug
        /// </summary>
        /// <param name="issueId">bug id</param>
        /// <param name="cmd">sql command object</param>
        /// <returns></returns>
        private string GetSeverity(int issueId, MySqlCommand cmd)
        {
            string severity = string.Empty;
            if (issueId != 0)
            {
                using (var context = new RedmineDBContext())
                {
                    cmd.CommandText = "SELECT VALUE FROM `custom_values` inner JOIN custom_fields on custom_fields.id=custom_values.custom_field_id and name='Importance' AND custom_values.customized_id=" + issueId + " ";
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            severity = reader[0].ToString();
                        }
                    }
                }
            }

            return severity;
        }

        /// <summary>
        /// Gets the login name of user from the given id from users table
        /// </summary>
        /// <param name="assingeeID">Assignee id</param>
        /// <param name="cmd">CQL command instance</param>
        /// <returns>User name</returns>
        private string GetAssigneeName(int assingeeID, MySqlCommand cmd)
        {
            string userName = string.Empty;
            if (assingeeID != 0)
            {
                using (var context = new RedmineDBContext())
                {
                    cmd.CommandText = "SELECT login FROM `users` WHERE id =" + assingeeID + " ";
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userName = reader[0].ToString();
                        }
                    }
                }
            }

            return userName;
        }

        /// <summary>
        /// Gets the list of users
        /// </summary>
        /// <param name="userID">User id</param>
        /// <returns>Users List</returns>
        public List<BaseData> GetUsers(int userID = 0)
        {
            string userName = string.Empty;
            List<BaseData> list = new List<BaseData>();
            using (var context = new RedmineDBContext())
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    //cmd.Connection = context.GetConnection();
                    if (userID == 0)
                    {
                        cmd.CommandText = "SELECT * FROM `users` where login<>'' and status=1 and salt is null";
                    }
                    else
                    {
                        cmd.CommandText = "SELECT * FROM `users` WHERE id =" + userID + " and login<>''";
                    }

                    DataTable table = new DataTable();
                    table.Load(cmd.ExecuteReader());
                    foreach (DataRow row in table.Rows)
                    {
                        list.Add(new BaseData { Id = Convert.ToInt32(row[0]), Name = row[1].ToString() });
                    }
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }

            }
            return list;
        }

        #endregion
    }
}
