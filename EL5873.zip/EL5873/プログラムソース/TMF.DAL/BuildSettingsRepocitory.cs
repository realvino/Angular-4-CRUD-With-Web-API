﻿#region File Header
// ---------------------------------------------------------------------------------------
// Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved.
// File Name     : BuildSettingsRepocitory.cs
// Description   : Contains build settings CURD operations.
// Date          |    Author             |        Description
// ---------------------------------------------------------------------------------------
// 2021/06/21    |   Vinoth N            |        EL5873_Initial Version
// --------------------------------------------------------------------------------------- 
#endregion

#region Using
using MySql.Data.MySqlClient;
using System;
using System.Data;
using TMF.DAL.Objects;
#endregion

#region Namespace
namespace TMF.DAL
{
    #region Class
    /// <summary>
    /// Contains build settings CURD operations.
    /// </summary>
    /// <author>Vinoth N</author>
    /// <copyright>Copyright (C) Hitachi High-Tech Corporation 2021.</copyright>
    public class BuildSettingsRepocitory
    {
        #region Variables
        /// <summary>
        /// Connection string.
        /// </summary>
        private readonly string connString;
        #endregion

        #region Constructor
        /// <summary>
        /// Parameter constructor for redmine build settings.
        /// </summary>
        /// 2021/06/21, Vinoth N, EL5873_Initial Version
        public BuildSettingsRepocitory(string connection)
        {
            connString = connection;
        }
        #endregion

        #region Public methods
        /// <summary>
        /// Method to Create build settings.
        /// </summary>
        /// <param name="buildSettings">Build settings input.</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/21, Vinoth N, EL5873_Initial Version
        public bool Create(BuildSettings buildSettings)
        {
            bool status;
            using (var context = new RedmineDBContext())
            {
                MySqlCommand cmdInsert = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmdInsert.Connection = conn;
                    cmdInsert.CommandText = "INSERT INTO `build_settings` (`product_id`,`version_id`," +
                                            "`tas_machine`,`modules`,`build_source`,`run_ut`,`execute_senario`," +
                                            "`tas_project`,`schedule_build`,`schedule_type`,`schedule_date`," +
                                            "`schedule_time`,`created_on`)" +
                                            " VALUES(@projectId, @versionId, @tasMachine, @modules," +
                                            "@buildSource, @runUnitTest, @exeSenario, @tasProject," +
                                            "@scheduleBuild, @scheduleType, @scheduleDate, @scheduletime, NOW());";
                    cmdInsert.Parameters.AddWithValue("@projectId", buildSettings.ProductId);
                    cmdInsert.Parameters.AddWithValue("@versionId", buildSettings.VersionId);
                    cmdInsert.Parameters.AddWithValue("@tasMachine", buildSettings.TASMachine);
                    cmdInsert.Parameters.AddWithValue("@modules", buildSettings.SelectedModules);
                    cmdInsert.Parameters.AddWithValue("@buildSource", buildSettings.BuildSource);
                    cmdInsert.Parameters.AddWithValue("@runUnitTest", buildSettings.RunUnitTest);
                    cmdInsert.Parameters.AddWithValue("@exeSenario", buildSettings.ExecuteSenario);
                    cmdInsert.Parameters.AddWithValue("@scheduletime", buildSettings.ScheduleTime);
                    cmdInsert.Parameters.AddWithValue("@tasProject", buildSettings.TASProject);
                    cmdInsert.Parameters.AddWithValue("@scheduleBuild", buildSettings.ScheduleBuild);
                    cmdInsert.Parameters.AddWithValue("@scheduleType", buildSettings.ScheduleType);
                    cmdInsert.Parameters.AddWithValue("@scheduleDate", buildSettings.ScheduleDate);
                    status = cmdInsert.ExecuteNonQuery() > 0;
                }
                catch (Exception ex)
                {
                                 if (ex is ArgumentOutOfRangeException)
                {
                    exceptionMessage = "Specified Index was out of range";
                }
                else if (ex is MissingMemberException)
                {
                    if (ex.Message.Contains("has no attribute"))
                    {
                        exceptionMessage = ex.Message.Substring(ex.Message.LastIndexOf(' ')) + " is an invalid command";
                    }
                }
                else if (ex is ArgumentTypeException)
                {
                    exceptionMessage = "Invalid argument(s) found: " + ex.Message;
                }
                else if (ex is Runtime.UnboundNameException)
                {
                    exceptionMessage = ex.Message;
                }
                else if (ex is SMLParserException || ex is InvalidCommandParameterException || ex is DirectoryNotFoundException ||
                    ex is OverflowException)
                {
                    exceptionMessage = ex.Message;
                    switch (exceptionMessage.ToUpper())
                    {
                        case "U2":
                            dataType = TMFDataType.SecsII_U2;
                            break;
                        case "U4":
                            dataType = TMFDataType.SecsII_U4;
                            break;
                        case "U8":
                            dataType = TMFDataType.SecsII_U8;
                            break;
                        case "J":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "L":
                            dataType = TMFDataType.SecsII_List;
                            break;
                        case "ARRAY":
                            dataType = TMFDataType.SecsII_Array;
                            break;
                        case "A":
                            dataType = TMFDataType.SecsII_ASCII;
                            break;
                        case "B":
                            dataType = TMFDataType.SecsII_Binary;
                            break;
                        case "BOOLEAN":
                            dataType = TMFDataType.SecsII_Bool;
                            break;
                        case "F4":
                            dataType = TMFDataType.SecsII_F4;
                            break;
                        case "F8":
                            dataType = TMFDataType.SecsII_F8;
                            break;
                        case "I1":
                            dataType = TMFDataType.SecsII_I1;
                            break;
                        case "I2":
                            dataType = TMFDataType.SecsII_I2;
                            break;
                        case "I4":
                            dataType = TMFDataType.SecsII_I4;
                            break;
                        case "I8":
                            dataType = TMFDataType.SecsII_I8;
                            break;
                        case "JIS8":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "LCS":
                            dataType = TMFDataType.SecsII_LCS;
                            break;
                        case "U1":
                            dataType = TMFDataType.SecsII_U1;
                            break;
                        case "U2":
                            dataType = TMFDataType.SecsII_U2;
                            break;
                        case "U4":
                            dataType = TMFDataType.SecsII_U4;
                            break;
                        case "U8":
                            dataType = TMFDataType.SecsII_U8;
                            break;
                        case "J":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "L":
                            dataType = TMFDataType.SecsII_List;
                            break;
                        default:
                            throw new SMLParserException("Invalid data type '" + msgType + "' found");
                    }
                }
                throw(ex);
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        cmdInsert.Parameters.Clear();
                        conn.Close();
                    }
                }
            }
            return status;
        }

        /// <summary>
        /// Method to update build settings.
        /// </summary>
        /// <param name="buildSettings">Build settings input.</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/22, Vinoth N, EL5873_Initial Version
        public bool Update(BuildSettings buildSettings)
        {
            bool status;
            using (var context = new RedmineDBContext())
            {
                DataTable table = new DataTable();
                MySqlCommand cmdUpdate = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmdUpdate.Connection = conn;
                    cmdUpdate.CommandText = "UPDATE `bitnami_redmine`.`build_settings` SET " +
                                            "`tas_machine` = @tasMachine,`modules` = @modules," +
                                            "`build_source` = @buildSource,`run_ut` = @runUnitTest," +
                                            "`execute_senario` = @exeSenario,`tas_project` = @tasProject," +
                                            "`schedule_build` = @scheduleBuild,`schedule_type` = @scheduleType," +
                                            "`schedule_date` = @scheduleDate,`schedule_time` = @scheduletime," +
                                            "`updated_on` = NOW() WHERE `id` = @id";
                    cmdUpdate.Parameters.AddWithValue("@id", buildSettings.Id);
                    cmdUpdate.Parameters.AddWithValue("@tasMachine", buildSettings.TASMachine);
                    cmdUpdate.Parameters.AddWithValue("@modules", buildSettings.SelectedModules);
                    cmdUpdate.Parameters.AddWithValue("@buildSource", buildSettings.BuildSource);
                    cmdUpdate.Parameters.AddWithValue("@runUnitTest", buildSettings.RunUnitTest);
                    cmdUpdate.Parameters.AddWithValue("@exeSenario", buildSettings.ExecuteSenario);
                    cmdUpdate.Parameters.AddWithValue("@scheduletime", buildSettings.ScheduleTime);
                    cmdUpdate.Parameters.AddWithValue("@tasProject", buildSettings.TASProject);
                    cmdUpdate.Parameters.AddWithValue("@scheduleBuild", buildSettings.ScheduleBuild);
                    cmdUpdate.Parameters.AddWithValue("@scheduleType", buildSettings.ScheduleType);
                    cmdUpdate.Parameters.AddWithValue("@scheduleDate", buildSettings.ScheduleDate);
                    status = cmdUpdate.ExecuteNonQuery() > 0;
                }
                catch (Exception ex)
                {
                    status = false;
                                 if (ex is ArgumentOutOfRangeException)
                {
                    exceptionMessage = "Specified Index was out of range";
                }
                else if (ex is MissingMemberException)
                {
                    if (ex.Message.Contains("has no attribute"))
                    {
                        exceptionMessage = ex.Message.Substring(ex.Message.LastIndexOf(' ')) + " is an invalid command";
                    }
                }
                else if (ex is ArgumentTypeException)
                {
                    exceptionMessage = "Invalid argument(s) found: " + ex.Message;
                }
                else if (ex is Runtime.UnboundNameException)
                {
                    exceptionMessage = ex.Message;
                }
                else if (ex is SMLParserException || ex is InvalidCommandParameterException || ex is DirectoryNotFoundException ||
                    ex is OverflowException)
                {
                    exceptionMessage = ex.Message;
                    switch (exceptionMessage.ToUpper())
                    {
                        case "ARRAY":
                            dataType = TMFDataType.SecsII_Array;
                            break;
                        case "A":
                            dataType = TMFDataType.SecsII_ASCII;
                            break;
                        case "B":
                            dataType = TMFDataType.SecsII_Binary;
                            break;
                        case "BOOLEAN":
                            dataType = TMFDataType.SecsII_Bool;
                            break;
                        case "F4":
                            dataType = TMFDataType.SecsII_F4;
                            break;
                        case "F8":
                            dataType = TMFDataType.SecsII_F8;
                            break;
                        case "I1":
                            dataType = TMFDataType.SecsII_I1;
                            break;
                        case "I2":
                            dataType = TMFDataType.SecsII_I2;
                            break;
                        case "I4":
                            dataType = TMFDataType.SecsII_I4;
                            break;
                        case "I8":
                            dataType = TMFDataType.SecsII_I8;
                            break;
                        case "JIS8":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "LCS":
                            dataType = TMFDataType.SecsII_LCS;
                            break;
                        case "U1":
                            dataType = TMFDataType.SecsII_U1;
                            break;
                        default:
                            throw new SMLParserException("Invalid data type '" + msgType + "' found");
                    }
                }
                throw(ex);
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        cmdUpdate.Parameters.Clear();
                        conn.Close();
                    }
                }
            }
            return status;
        }

        /// <summary>
        /// Method to get build settings.
        /// </summary>
        /// <param name="input">Collection of general inputs.</param>
        /// <returns>Returns build settings.</returns>
        /// 2021/06/22, Vinoth N, EL5873_Initial Version
        public BuildSettings GetAll(object[] input)
        {
            BuildSettings settings = new BuildSettings();
            using (var context = new RedmineDBContext())
            {
                DataTable settingsTable = new DataTable();
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection conn = new MySqlConnection(connString);
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.CommandText = "select * from `build_settings` where `product_id` = @productId and `version_id` = @versionId  limit 1";
                    cmd.Parameters.AddWithValue("@productId", input[0].ToString());
                    cmd.Parameters.AddWithValue("@versionId", input[1].ToString());
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(settingsTable);
                    }
                    foreach (DataRow row in settingsTable.Rows)
                    {
                        settings = new BuildSettings()
                        {
                            Id = Convert.ToInt32(row["id"] ?? 0),
                            VersionId = Convert.ToInt32(row["version_id"] ?? 0),
                            ProductId = Convert.ToInt32(row["product_id"] ?? 0),
                            BuildSource = Convert.ToBoolean(row["build_source"]),
                            RunUnitTest = Convert.ToBoolean(row["run_ut"]),
                            ExecuteSenario = Convert.ToBoolean(row["execute_senario"]),
                            ScheduleBuild = Convert.ToBoolean(row["schedule_build"]),
                            ScheduleDate = row["schedule_date"].ToString(),
                            ScheduleTime = row["schedule_time"].ToString(),
                            ScheduleType = Convert.ToInt32(row["schedule_type"]),
                            SelectedModules = row["modules"].ToString(),
                            TASMachine = row["tas_machine"].ToString(),
                            TASProject = row["tas_project"].ToString()
                        };
                    }
                }
                catch (Exception ex)
                {
                                 if (ex is ArgumentOutOfRangeException)
                {
                    exceptionMessage = "Specified Index was out of range";
                }
                else if (ex is MissingMemberException)
                {
                    if (ex.Message.Contains("has no attribute"))
                    {
                        exceptionMessage = ex.Message.Substring(ex.Message.LastIndexOf(' ')) + " is an invalid command";
                    }
                }
                else if (ex is ArgumentTypeException)
                {
                    exceptionMessage = "Invalid argument(s) found: " + ex.Message;
                }
                else if (ex is Runtime.UnboundNameException)
                {
                    exceptionMessage = ex.Message;
                }
                else if (ex is SMLParserException || ex is InvalidCommandParameterException || ex is DirectoryNotFoundException ||
                    ex is OverflowException)
                {
                    exceptionMessage = ex.Message;
                    switch (exceptionMessage.ToUpper())
                    {
                        case "ARRAY":
                            dataType = TMFDataType.SecsII_Array;
                            break;
                        case "A":
                            dataType = TMFDataType.SecsII_ASCII;
                            break;
                        case "B":
                            dataType = TMFDataType.SecsII_Binary;
                            break;
                        case "BOOLEAN":
                            dataType = TMFDataType.SecsII_Bool;
                            break;
                        case "F4":
                            dataType = TMFDataType.SecsII_F4;
                            break;
                        case "F8":
                            dataType = TMFDataType.SecsII_F8;
                            break;
                        case "I1":
                            dataType = TMFDataType.SecsII_I1;
                            break;
                        case "I2":
                            dataType = TMFDataType.SecsII_I2;
                            break;
                        case "I4":
                            dataType = TMFDataType.SecsII_I4;
                            break;
                        case "I8":
                            dataType = TMFDataType.SecsII_I8;
                            break;
                        case "JIS8":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "LCS":
                            dataType = TMFDataType.SecsII_LCS;
                            break;
                        case "U1":
                            dataType = TMFDataType.SecsII_U1;
                            break;
                        case "U2":
                            dataType = TMFDataType.SecsII_U2;
                            break;
                        case "U4":
                            dataType = TMFDataType.SecsII_U4;
                            break;
                        case "U8":
                            dataType = TMFDataType.SecsII_U8;
                            break;
                        case "J":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "L":
                            dataType = TMFDataType.SecsII_List;
                            break;
                        default:
                            throw new SMLParserException("Invalid data type '" + msgType + "' found");
                    }
                }
                    throw(ex);
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
            return settings;
        }
        #endregion
    }
    #endregion
}
#endregion