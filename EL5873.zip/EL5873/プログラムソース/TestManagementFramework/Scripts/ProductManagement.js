﻿// ---------------------------------------------------------------------------------------
// Copyright (C) Hitachi High-Tech Corporation, 2021, All rights reserved.
// File Name    : ProductManagement.js
// Description  : Javascript file for configuration related functions.
// Date         |   Author              |   Description
// ---------------------------------------------------------------------------------------
// 2020/06/07   |   Vinoth N            |   EL5873_Initial version
// --------------------------------------------------------------------------------------- 

/* EL5873 mod START added for global assembly */
var buildSource = false;
var executeSenario = false;
var runUnitTest = false;
var scheduleBuild = false;
var scheduleType = 1;
/* EL5873 mod END added for global assembly */

/// <summary>
/// Method to get TAS project.
/// </summary>
/// <param name="machine">Machine name.</param>
/// <returns>Returns project list.</returns>
/// 2021/06/07, Vinoth N, EL5873_Initial Version
function GetTASProject(machine) {
    var targetUrl = $("#getTASProjectUrl").val();
    return $.ajax({
        url: targetUrl,
        type: "post",
        dataType: 'json',
        data: { machineName: machine },
        success: function (item) {    
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $.LoadingOverlay("hide");
        }
    });
}

/// <summary>
/// Method to open path setting popup.
/// </summary>
/// <param name="id">Settings Id.</param>
/// 2021/06/07, Vinoth N, EL5873_Initial Version
function PathConfigPopup(id) {
    $.when(GetPathConfiguration(id)).then(function (data) {
        $("#pathConfigurationModel").iziModal({
            radius: 5,
            padding: 20,
            maxHeight: 500,
            height: 500,
            closeButton: false,
            title: 'title',
            headerColor: '#002e5b',
            bodyOverflow: true,
            closeOnEscape: false,
            history: false,
            restoreDefaultContent: false
        });
        ShowDialogBox($('#pathConfigurationModel'));
        LoadPathConfiguration(data);
    });
}

/// <summary>
/// Method to get path setting data.
/// </summary>
/// <param name="id">Settings id.</param>
/// <returns>Returns settings data.</returns>
/// 2021/06/08, Vinoth N, EL5873_Initial Version
function GetPathConfiguration(id) {
    if (id > 0) {
        var url = $("#getPathConfigWizardUrl").val();
        return $.ajax(
        {
            url: url,
            data: {
                id: id
            },
            type: "POST",
            success: function (result) { }
        });
    }
}

/// <summary>
/// Method to load path setting data.
/// </summary>
/// <param name="data">Settings data.</param>
/// 2021/06/08, Vinoth N, EL5873_Initial Version
function LoadPathConfiguration(data) {
    if (data !== null) {
        console.log(data);
        $("#txtSourcePath").val(data.RepositorySource);
        $("#txtBuildScript").val(data.BuildScript);
        $("#txtTestScript").val(data.ExecutionScript);
        $("#txtId").val(data.Id);
        if (data.Module !== null) {
            $("#txtModuleId").val(data.Module.ModuleId);
        }
    }
}

/// <summary>
/// Method to save path setting data.
/// </summary>
/// <returns>Returns save status.</returns>
/// 2021/06/09, Vinoth N, EL5873_Initial Version
function SavePathConfiguration() {
    var moduleId = parseInt($('#ddlModules option:selected').val());
    var pathData = [{
        "BuildScript": $("#txtBuildScript").val(),
        "ExecutionScript": $("#txtTestScript").val(),
        "Id": parseInt($("#txtId").val()),
        "RepositorySource": $("#txtSourcePath").val(),
        "Module": {
            "Id": moduleId, "Name": $('#ddlModules option:selected').text()
        }
    }];
    if (moduleId > 0) {
        var url = $("#savePathConfigWizardUrl").val();
        return $.ajax(
            {
                url: url,
                data: {
                    pathSettings: JSON.stringify(pathData)
                },
                type: "POST",
                success: function (result) {
                    if (result.status) {
                        NotifySuccess(result.message);
                        $('#pathConfigurationModel').iziModal('close');
                    }
                    else {
                        NotifyError(result.message);
                    }
                },
                error: function (xhr) {
                    NotifyError(Resources.Failed);
                }
            });
    }
    else {
        NotifyError("Invalid Data");
    }
}

/// <summary>
/// Method to open flow settings popup.
/// </summary>
/// <param name="data">Settings Id.</param>
/// 2021/06/10, Vinoth N, EL5873_Initial Version
function FlowSettingsPopup(id) {
    ShowOrHideDiv(0);
    $.when(GetBuildSettings()).then(function (data) {
        $("#processFlowSettingsModel").iziModal({
            radius: 5,
            padding: 20,
            maxHeight: 500,
            height: 500,
            closeButton: false,
            title: 'title',
            headerColor: '#002e5b',
            bodyOverflow: true,
            closeOnEscape: false,
            history: false,
            restoreDefaultContent: false
        });
        ShowDialogBox($('#processFlowSettingsModel'));
        ShowOrHideDiv(4);
        $('#multiselect').multipleselect({
            afterMoveUp: function (options) {
                ExtractModules();
            },
            afterMoveDown: function (options) {
                ExtractModules();
            },
            afterMoveToRight: function ($left, $right, $options) {
                ExtractModules();
            },
            afterMoveToLeft: function ($left, $right, $options) {
                ExtractModules();
            }
        });
        $('input[name=chkBuildSourceExn]').on('change', function () {
            if ($(this).is(':checked')) {
                buildSource = true;
            } else {
                buildSource = false;
            }
            SetButtonContent();
        });
        $('input[name=chkRunUnitTestExn]').on('change', function () {
            if ($(this).is(':checked')) {
                runUnitTest = true;
            } else {
                runUnitTest = false;
            }
            SetButtonContent();
        });
        $('input[name=chkExeSenarioExn]').on('change', function () {
            ShowOrHideDiv(1);
            if ($(this).is(':checked')) {
                $(".SchProjectDiv").show();
                executeSenario = true;
            } else {
                $(".SchProjectDiv").hide();
                $(".SchTASDiv").hide();
                executeSenario = false;
                scheduleBuild = false;
            }
            SetButtonContent();
        });
        $('input[name=chkScheduleBuildExn]').on('change', function () {
            ShowOrHideDiv(2);
            if ($(this).is(':checked')) {
                scheduleBuild = true;
                $(".SchTASDiv").show();
                $('#rbDaily').prop('checked', true);
                scheduleType = 1;
                $("#weeklyDivs").hide();
            } else {
                scheduleBuild = false;
                $(".SchTASDiv").hide();
            }
            SetButtonContent();
        });
        $('input[type=radio][name=rbPeriodically]').change(function () {
            ShowOrHideDiv(3);
            if (this.value === "Daily") {
                $("#weeklyDivs").hide();
                scheduleType = 1;
            }
            else if (this.value === "Weekly") {
                $("#weeklyDivs").show();
                scheduleType = 2;
            }
        });
        LoadFlowSettings(data);
    });
}

/// <summary>
/// Method to set save button content.
/// </summary>
/// 2021/06/10, Vinoth N, EL5873_Initial Version
function SetButtonContent() {
    if (executeSenario || buildSource || runUnitTest) {
        $("#ExecuteButton").show();
    }
    else {
        $("#ExecuteButton").hide();
    }
}

/// <summary>
/// Method to extract modules.
/// </summary>
/// <returns>Returns modules.</returns>
/// 2021/06/11, Vinoth N, EL5873_Initial Version
function ExtractModules() {
    var modules = [];
    $("#multiselect_from option").each(function () {
        var optionValue = $(this).val();
        modules.push(optionValue);
    });
      $("#multiselect_to option").each(function () {
        var optionValue = $(this).val();
        modules.push(optionValue);
    });
    return modules.join(',');
}

/// <summary>
/// Method to load flow settings data.
/// </summary>
/// <param name="data">Settings data.</param>
/// 2021/06/11, Vinoth N, EL5873_Initial Version
function LoadFlowSettings(data) {
    $("#txtProduct").val($('#ddlProduct option:selected').text());
    $("#txtVersion").val($('#ddlVersion option:selected').text());
    if (data !== undefined && data !== null)
    {
        $("#txtBuildId").val(data.Id);
        LoadMultiSelectModules(data);
        GetBuildMachines(data);
        LoadCheckedItems(data);
        LoadScheduledDate(data);
        SetButtonContent();
    }
}


/// <summary>
/// Method to bind check boxes.
/// </summary>
/// <param name="data">Settings data.</param>
/// 2021/06/14, Vinoth N, EL5873_Initial Version
function LoadCheckedItems(data) {
    if (data !== undefined && data !== null) {
        buildSource = data.BuildSource;
        executeSenario = data.ExecuteSenario;
        runUnitTest = data.RunUnitTest;
        scheduleBuild = data.ScheduleBuild;
        scheduleType = data.ScheduleType;
        if (data.RunUnitTest === true)
            $('#chkRunUnitTestExn').prop('checked', true);
        else
            $('#chkRunUnitTestExn').prop('checked', false);
        if (data.BuildSource === true)
            $('#chkBuildSourceExn').prop('checked', true);
        else
            $('#chkBuildSourceExn').prop('checked', false);
        if (data.ExecuteSenario === true) {
            $(".SchProjectDiv").show();
            $('#chkExeSenarioExn').prop('checked', true);
        }
        else {
            $('#chkExeSenarioExn').prop('checked', false);
            $(".SchProjectDiv").hide();
        }
        if (data.ScheduleBuild === true) {
            $('#chkScheduleBuildExn').prop('checked', true);
            $(".SchTASDiv").show();
        }
        else {
            $('#chkScheduleBuildExn').prop('checked', false);
            $(".SchTASDiv").hide();
        }
        switch (scheduleType) {
            case 1:
                $('#rbDaily').prop('checked', true);
                $("#weeklyDivs").hide();
                break;
            case 2:
                $('#rbWeekly').prop('checked', true);
                $("#weeklyDivs").show();
                break;
        }
    }
}

/// <summary>
/// Method to load scheduled data.
/// </summary>
/// <param name="data">Settings data.</param>
/// 2021/06/15, Vinoth N, EL5873_Initial Version
function LoadScheduledDate(data) {
    var item = [{ Text: Resources.Select, Value: 0 },
    { Text: Resources.Sunday, Value: 1 },
    { Text: Resources.Monday, Value: 2 },
    { Text: Resources.Tuesday, Value: 3},
    { Text: Resources.Wednesday, Value: 4 },
    { Text: Resources.Thursday, Value: 5 },
    { Text: Resources.Friday, Value: 6 },
    { Text: Resources.Saturday, Value: 7 }];
    if (data !== undefined && data !== null) {
        $("#scheduledDateId").empty();
        $.each(item, function (val, text) {
            var opt = new Option(text.Text, text.Value);
            $("#scheduledDateId").append(opt);
            if (text.Text === data.ScheduleDate) {
                opt.setAttribute("selected", "selected");
            }
        });
        $("#dailyExnTime").val(data.ScheduleTime);
    }
}

/// <summary>
/// Method to bind module data in multiselect.
/// </summary>
/// <param name="data">Settings data.</param>
/// 2021/06/16, Vinoth N, EL5873_Initial Version
function LoadMultiSelectModules(data) {
    if (data !== undefined && data !== null) {
        ShowOrHideDiv(5);
        var selected = data.SelectedModules.split(',');
        $("#multiselect").empty();
        if (data.Modules !== null) {
            if (data.SelectedModules !== null && data.SelectedModules !== "" && selected.length > 0) {
                var right = data.Modules.filter(x => selected.includes(x.Id.toString()));
                SetSelectedRight(right, selected);
                var left = data.Modules.filter(x => !selected.includes(x.Id.toString()));
                SetSelectedLeft(left);
            }
            else {
                SetSelectedLeft(data.Modules);
            }
        }
    }
}

/// <summary>
/// Method to get build settings.
/// </summary>
/// <returns>Returns bulid settings.</returns>
/// 2021/06/16, Vinoth N, EL5873_Initial Version
function GetBuildSettings() {
    var product = $('#ddlProduct option:selected').val();
    var version = $('#ddlVersion option:selected').val();
    var targetUrl = $("#getBuildSettingsUrl").val();
    return $.ajax({
        url: targetUrl,
        type: "post",
        dataType: 'json',
        data: { productId: product, versionId: version },
        success: function (data) {
        },
        error: function (xhr, ajaxOptions, thrownError) {
        }
    });
}

/// <summary>
/// Method to bindbuild machines.
/// </summary>
/// <param name="data">Settings data.</param>
/// 2021/06/16, Vinoth N, EL5873_Initial Version
function GetBuildMachines(data) {
    let selected = '';
    let flag = false;
    if (data !== null && data !== undefined && data.Machines !== null) {
        selected = data.TASMachine;
        $("#tasBuildMachines").empty();
        if (data.Machines.length > 0) {
            $("#tasBuildMachines").prepend("<option value='0'>" + Resources.Select + "</option>");
            $.each(data.Machines, function (val, mech) {
                var opt = new Option(mech.AliasName, mech.MachineName);
                $("#tasBuildMachines").append(opt);
                if (mech.MachineName === selected) {
                    opt.setAttribute("selected", "selected");
                    flag = true;
                }
            });
            if (flag === false && selected !== "" && selected !== "0") {
                opt = new Option(selected, selected);
                $("#tasBuildMachines").append(opt);
                opt.setAttribute("selected", "selected");
            }
            GetBuildProjectDetail(data.TASProject);
        }
        else {
            $("#tasBuildMachines").html("");
            $("#tasBuildMachines").prepend("<option value=''>" + Resources.Select + "</option>");
        }
    }
    else {
        $("#tasBuildMachines").html("");
    }
}

/// <summary>
/// Method to bind project data.
/// </summary>
/// <param name="data">Settings data.</param>
/// 2021/06/17, Vinoth N, EL5873_Initial Version
function GetBuildProjectDetail(selected) {
    let flag = false;
    var machine = $("#tasBuildMachines option:selected").val();
    $("#tasBuildProjects").empty();
    $("#tasBuildProjects").prepend("<option value='0'>" + Resources.Select + "</option>");
    if (machine !== "0") {
        $.when(GetTASProject(machine)).then(function (item) {
            if (item !== undefined && item !== null) {
                if (item === "Connection Failed.") {
                    NotifyWarning(Resources.TASAutoStartValidation);
                    if (selected !== "" && selected !== undefined) {
                        var opt = new Option(selected, selected);
                        $("#tasBuildProjects").append(opt);
                        opt.setAttribute("selected", "selected");
                        flag = true;
                    }
                }
                else if (item.length > 0) {
                    $.each(item, function (val, text) {
                        var opt = new Option(text.Text, text.Value);
                        $("#tasBuildProjects").append(opt);
                        if (text.Value === selected) {
                            opt.setAttribute("selected", "selected");
                            flag = true;
                        }
                    });
                    if (flag === false && selected !== "") {
                        opt = new Option(selected, selected);
                        $("#tasBuildProjects").append(opt);
                        opt.setAttribute("selected", "selected");
                    }
                }
                else {
                    $("#tasBuildProjects").html("");
                    $("#tasBuildProjects").prepend("<option value=''>" + Resources.Select + "</option>");
                }
            }
        });
    }
}

/// <summary>
/// Method to load modules.
/// </summary>
/// <param name="item">Module item.</param>
/// 2021/06/17, Vinoth N, EL5873_Initial Version
function SetSelectedLeft(item) {
    $("#multiselect").empty();
    if (item !== null) {
        for (var i in item) {
            $('#multiselect').append('<option value="' + item[i].Id + '">' + item[i].Name + '</option>');
        }
    }
}

/// <summary>
/// Method to load selected modules.
/// </summary>
/// <param name="item">Module item.</param>
/// <param name="order">Selection order.</param>
/// 2021/06/18, Vinoth N, EL5873_Initial Version
function SetSelectedRight(items, order) {
    $("#multiselect_to").empty();
    if (items !== null) {
        for (var i in order) {
            var item = items.find(x => x.Id.toString() === order[i]);
            if (item !== undefined) {
                $('#multiselect_to').append('<option value="' + item.Id + '">' + item.Name + '</option>');
            }
        }
    }
}

/// <summary>
/// Method to get selected project.
/// </summary>
/// <returns>Returns selected project.</returns>
/// 2021/06/18, Vinoth N, EL5873_Initial Version
function GetSelectedProject() {
    var selected = $('#tasBuildProjects option:selected').text();
    if (selected === Resources.Select)
        selected = "";
    return selected;
}

/// <summary>
/// Method to get selected schedule day.
/// </summary>
/// <returns>Returns selected day.</returns>
/// 2021/06/18, Vinoth N, EL5873_Initial Version
function GetSelectedDay() {
    var selected = $("#scheduledDateId option:selected").text();
    if (selected === Resources.Select)
        selected = "";
    return selected;
}

/// <summary>
/// Method to show or hide div.
/// </summary>
/// <param name="id">Type Id.</param>
/// 2021/06/21, Vinoth N, EL5873_Initial Version
function ShowOrHideDiv(id) {
    switch (id) {
        case 0:
            buildSource = false;
            executeSenario = false;
            runUnitTest = false;
            scheduleBuild = false;
            break;
        case 1:
            $("#dailyExnTime").val("");
            $('#chkScheduleBuildExn').prop('checked', false);
            $("#tasBuildProjects").val(0);
            $("#scheduledDateId").val(0);
            scheduleType = 0;
            break
        case 2:
            scheduleType = 0;
            $("#dailyExnTime").val("");
            $("#scheduledDateId").val(0);
            break;
        case 3:
            $("#dailyExnTime").val("");
            $("#scheduledDateId").val(0);
            break;
        case 4:
            $(".SchTASDiv").hide();
            $(".SchProjectDiv").hide();
            $("#weeklyDivs").hide();
            $('#rbDaily').prop('checked', true);
            break;
        case 5:
            $("#multiselect").empty();
            $("#multiselect_to").empty();
            break;
    }
}

/// <summary>
/// Method to get settings data.
/// </summary>
/// <returns>Returns settings data.</returns>
/// 2021/06/21, Vinoth N, EL5873_Initial Version
function GetSettingsData() {
    var versionId = parseInt($('#ddlVersion option:selected').val());
    var flowData = [{
        "Id": $("#txtBuildId").val(),
        "ProductId": $('#ddlProduct option:selected').val(),
        "VersionId": versionId,
        "TASMachine": $('#tasBuildMachines option:selected').val(),
        "TASProject": GetSelectedProject(),
        "RunUnitTest": runUnitTest,
        "ExecuteSenario": executeSenario,
        "BuildSource": buildSource,
        "ScheduleBuild": scheduleBuild,
        "ScheduleType": scheduleType,
        "ScheduleDate": GetSelectedDay(),
        "ScheduleTime": $("#dailyExnTime").val(),
        "SelectedModules": ExtractModules(),
        "IsBuildable": false
    }];
    return flowData;
}

/// <summary>
/// Method to save flow settings.
/// </summary>
/// <param name="id">Settings id.</param>
/// <returns>Returns save status.</returns>
/// 2021/06/22, Vinoth N, EL5873_Initial Version
function SaveFlowSettings(id) {
    var flowData = GetSettingsData();
    if (ValidateSaveSettings(flowData)) {
        var contant;
        switch (id) {
            case 0:
                contant = result.message;
                break
            case 1:
                flowData[0].IsBuildable = true;
                contant = "Save and Scheduled successfully";
                break;
            case 2:
                flowData[0].IsBuildable = true;
                contant = "Save and Run successfully";
                break;
        }
        var url = $("#saveBuildSettingsUrl").val();
        return $.ajax(
            {
                url: url,
                data: {
                    buildSettings: JSON.stringify(flowData)
                },
                type: "POST",
                success: function (result) {
                    if (result.status) {                      
                        NotifySuccess(contant);
                        $('#processFlowSettingsModel').iziModal('close');
                    }
                    else {
                        NotifyError(result.message);
                    }
                },
                error: function (xhr) {
                    NotifyError(Resources.Failed);
                }
            });
    }
}

/// <summary>
/// Method to validate save settings data.
/// </summary>
/// <param name="settings">Settings data.</param>
/// 2021/06/22, Vinoth N, EL5873_Initial Version
function ValidateSaveSettings(settings) {
    var status = false;
    if (settings !== undefined && settings !== null && settings.length > 0) {
        var  data = settings[0];
        if (data.TASMachine === "0") {
            NotifyError("TAS Machine is required.");
        }
        else if (data.SelectedModules === "") {
            NotifyError("Module is required.");
        }
        else if (data.ExecuteSenario === true && data.TASProject === "") {
            NotifyError("TAS project is required.");
        }
        else if (data.ScheduleBuild === true && data.ScheduleType === 2 && data.ScheduleDate === "") {
            NotifyError("Day is required.");
        }
        else if (data.ScheduleBuild === true && data.ScheduleTime === "") {
            NotifyError("Time is required.");
        }      
        else {
            status = true;
        }
    }
    return status;
}

/// <summary>
/// Method to build flow settings data.
/// </summary>
/// 2021/06/22, Vinoth N, EL5873_Initial Version
function FlowSettingsSaveAndRun() {
    var settings = GetSettingsData();
    if (settings !== undefined && settings !== null && settings.length > 0) {
        var data = settings[0];
        if (data.ScheduleBuild) {
            SaveFlowSettings(1);
        }
        else if (executeSenario || buildSource || runUnitTest) {
             SaveFlowSettings(2);
        }     
    }
}