﻿#region File Header
// ---------------------------------------------------------------------------------------
// Copyright (C) Hitachi High-Tech Corporation, 2018-2021. All rights reserved.
// File Name     : ProductController.cs
// Description   : Controller for Product Page
// Date         |    Author             |        Description
// ---------------------------------------------------------------------------------------
// 2018/05/28   |   Praveen MP          |         Created
// 2019/01/28   |   Sujith A            |         Modification for F2T operation cancel
// 2019/02/21   |   Sharon Thankachan   |         VJP192_Modification for Deleted Products
// 2019/08/07   |   Vinoth N            |         A0N259_Modification for Replace F2T Document
// 2020/01/15   |   Vinoth N            |         B1K017_Modification for get member profile picture url
// 2020/05/15   |   Vinoth N            |         C51165_Modification for product creation wizard
// 2020/10/19   |   Vinoth N            |         CRC207_Modification for mapping TAS script
// 2021/02/22   |   Vinoth N            |         DMG213_Modification for email enhancement
// 2021/06/11   |   Vinoth N            |         EL5873_Modification for build and path settings
// --------------------------------------------------------------------------------------- 
#endregion

#region Using
using AutoMapper;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Xml.Serialization;
using TestManagementFramework.Helper;
using TMF.Business;
using TMF.Common;
using TMF.Logger;
using TMF.ViewModels;
#endregion

#region NameSpace
namespace TestManagementFramework.Controllers
{
    [Authorize]
    public class ProductController : Controller
    {
        #region Private Variables
        /// <summary>
        /// Variable to display  log after import\export
        /// </summary>
        private List<StatusLogViewModel> logs = new List<StatusLogViewModel>();

        /// <summary>
        /// Represents the instance of Products class
        /// </summary>
        Products productInfo = null;
        #endregion

        #region Public Methods
        /// <summary>
        /// Initialization method
        /// </summary>
        /// <returns>Product page</returns>
        /// 2019/02/08, Sujith A ,VJP192- Modified
        [AuthorizePermissions()]
        public ActionResult Index()
        {
            string testProjectName = string.Empty;
            string testSuiteName = string.Empty;
            try
            {
                // 2019/02/08, Sujith A ,VJP192
                HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
                string token = cookie.Value;
                DeserializeProductDetails(token);
                GetProjectAndSuiteFromCookie(ref testProjectName, ref testSuiteName);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return View(GetViewDetails(testProjectName, testSuiteName));
        }

        /// <summary>
        /// Product management page load
        /// </summary>
        /// <returns>Returns product management UI</returns>
        /// 2019/01/30, Sujith A ,VJP192- Product management changes
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        public ActionResult ProductManagement()
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            /*VJP192_Modification for Deleted Product items START*/
            var pdts = manager.GetAllProducts(token, IsDeletePermission());
            List<SelectListItemHelper> lstSelect = new List<SelectListItemHelper>();
            lstSelect.Add(new SelectListItemHelper { Value = "0", Text = Resources.Resource.Select });
            Products products = new Products() { ProductsList = pdts.OrderByDescending(x => x.IsActive).ThenBy(x => x.ProductName).ToList(), VersionList = lstSelect, ModuleList = lstSelect, DocList = lstSelect };
            /*VJP192_Modification for Deleted Product items END*/
            return View(products);
        }

        /// <summary>
        /// Method to retrieve product details
        /// </summary>
        /// <param name="productId">Unique id of the product</param>
        /// <returns>Returns product details</returns>
        /// 2019/01/30, Sujith A ,VJP192- Product management changes
        /// 2020/01/15, Vinoth N, B1K017_Modification for get member profile picture url
        [HttpPost]
        public ActionResult GetProductDetails(int productId)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var product = manager.GetProductDetails(productId, token, IsDeletePermission());
            /* B1K017 mod START Modification for get member profile picrure url */
            if (product != null)
            {
                foreach (var user in product.Members)
                {
                    user.ProfileURL = GenerateProfileURL(user.Name);
                }
            }
            /* B1K017 mod END Modification for get member profile picrure url */
            return PartialView("EditProduct", product);
        }

        /// <summary>
        /// Method to get product wizard details
        /// </summary>
        /// <param name="productId">product Id</param>
        /// <param name="versionId">version Id</param>
        /// <param name="moduleId">version Id</param>
        /// <param name="typeId">version Id</param>
        /// <returns>Returns</returns>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        [HttpPost]
        public ActionResult GetProductWizard(int productId, int versionId, int moduleId, int typeId)
        {
            List<ProductDataModel> productData = new List<ProductDataModel>();
            List<OtherDataModel> versionData = new List<OtherDataModel>();
            List<OtherDataModel> moduleData = new List<OtherDataModel>();
            List<DocumentDataModel> documentData = new List<DocumentDataModel>();
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            if (productId > 0)
            {
                var product = manager.GetProductDetails(productId, token);
                productData.Add(new ProductDataModel { Id = product.Id, Name = product.ProductName, Description = product.Description, Members = product.Members, ParentId = productId });
                var customVersion = product.Versions.ToList();
                if (versionId > 0)
                    customVersion = customVersion.Where(p => p.Id == versionId).ToList();
                foreach (var version in customVersion.Where(p => p.IsActive == true))
                {
                    versionData.Add(new OtherDataModel { Id = version.Id, Name = version.VersionName, Description = version.Description, Members = version.Members, ParentId = productId, RootId = productId });
                    var customModule = version.Modules.ToList();
                    if (moduleId > 0)
                        customModule = customModule.Where(p => p.Id == moduleId).ToList();
                    foreach (var module in customModule.Where(p => p.IsActive == true))
                    {
                        moduleData.Add(new OtherDataModel { Id = module.Id, Name = module.ModuleName, Description = module.Description, Members = module.Members, ParentId = version.Id, RootId = version.Id });
                        foreach (var doc in module.DocModels)
                        {
                            documentData.Add(new DocumentDataModel { Id = doc.Id, Name = Path.GetFileName(doc.DocumentPath), Contant = doc.DocumentPath, ParentId = module.Id, RootId = module.Id });
                        }
                    }
                }
            }
            ProductGroupModel productGroup = new ProductGroupModel
            {
                ProductData = productData,
                VersionData = versionData,
                ModuleData = moduleData,
                DocumentData = documentData
            };
            return Json(productGroup, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Method to add product
        /// </summary>
        /// <param name="product">Product details</param>
        /// <returns>Returns add product status</returns>
        /// 2019/01/30, Sujith A ,VJP192- Product management changes
        [HttpPost]
        [AuthorizePermissions(MyPermissions.ADD_EDIT_DELETE_PROD_VER)]
        public ActionResult AddProduct(ProductModel product)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var status = manager.AddProduct(product, token);
            return Json(status);
        }

        /// <summary>
        /// Method to update product details
        /// </summary>
        /// <param name="product">Product details</param>
        /// <returns>Returns product update status</returns>
        /// 2019/01/30, Sujith A ,VJP192- Product management changes
        /// 2020/06/19, Vinoth N, C51165_Modification for update F2T path
        [HttpPost]
        [AuthorizePermissions(MyPermissions.ADD_EDIT_DELETE_PROD_VER)]
        public ActionResult UpdateProduct(ProductModel product)
        {
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            IProductManager manager = new ProductManager();
            GeneralResultModel result = new GeneralResultModel { status = true };
            /* C51165 mod START Modification for update F2T path */
            result = UpdateF2TFolder(product.Id, product.ProductName, String.Empty, String.Empty, 1, token);
            if (result.status)
                result = manager.UpdateProduct(product, token, true);
            if (result.status)
                RenameF2TDocument(product.Id, 0, 0, token);
            /* C51165 mod END Modification for update F2T path */
            return Json(result);
        }

        /// <summary>
        /// Method to delete product
        /// </summary>
        /// <param name="productId">Unique id of the product</param>
        /// <returns>Returns delete product status</returns>
        /// 2019/01/30, Sujith A ,VJP192- Product management changes
        [HttpPost]
        [AuthorizePermissions(MyPermissions.ADD_EDIT_DELETE_PROD_VER)]
        public ActionResult DeleteProduct(int productId)
        {

            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var result = manager.DeleteProduct(productId, token, IsDeletePermission());
            return Json(result);
        }

        /// <summary>
        /// Method to restore deleted product
        /// </summary>
        /// <param name="productId">Unique id of the product</param>
        /// <returns>Returns restore product status</returns>
        /// 2019/03/12, Sharon Thankachan ,VJP192_Initial Version
        [HttpPost]
        [AuthorizePermissions(MyPermissions.ADD_EDIT_DELETE_PROD_VER)]
        public ActionResult RestoreProduct(int productId)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var result = manager.RestoreProduct(productId, token, IsDeletePermission());
            return Json(result);
        }

        /// <summary>
        /// Method to retrieve version details
        /// </summary>
        /// <param name="versionId">Unique id of the version</param>
        /// <returns>Returns version details</returns>
        /// 2019/01/31, Sujith A ,VJP192- Product management changes
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        /// 2020/01/15, Vinoth N, B1K017_Modification for get member profile picture url
        [HttpPost]
        public ActionResult GetVersionDetails(int versionId)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            /*VJP192_Modification for Deleted Product items START*/
            var version = manager.GetVersionDetails(versionId, token, IsDeletePermission());
            /* B1K017 mod START Modification for get member profile picrure url */
            if (version != null)
            {
                foreach (var user in version.Members)
                {
                    user.ProfileURL = GenerateProfileURL(user.Name);
                }
            }
            /* B1K017 mod END Modification for get member profile picrure url */
            /*VJP192_Modification for Deleted Product items END*/
            return PartialView("EditVersion", version);
        }

        /// <summary>
        /// Method to add version
        /// </summary>
        /// <param name="version">Version details</param>
        /// <returns>Returns add version status</returns>
        /// 2019/01/31, Sujith A ,VJP192- Product management changes
        [HttpPost]
        [AuthorizePermissions(MyPermissions.ADD_EDIT_DELETE_PROD_VER)]
        public ActionResult AddVersion(VersionModel version)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var status = manager.AddVersion(version, token, true);
            return Json(status);
        }

        /// <summary>
        /// Method to update version details
        /// </summary>
        /// <param name="version">Version details</param>
        /// <param name="productName">product name</param>
        /// <returns>Returns update status</returns>
        /// 2019/01/31, Sujith A ,VJP192- Product management changes
        /// 2020/06/19, Vinoth N, C51165_Modification for update F2T path
        [AuthorizePermissions(MyPermissions.ADD_EDIT_DELETE_PROD_VER)]
        public ActionResult UpdateVersion(VersionModel version, string productName)
        {
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            GeneralResultModel result = new GeneralResultModel { status = true };
            IProductManager manager = new ProductManager();
            /* C51165 mod START Modification for update F2T path */
            result = UpdateF2TFolder(version.Id, productName, version.VersionName, String.Empty, 2, token);
            if (result.status)
                result = manager.UpdateVersion(version, token, true);
            if (result.status)
                RenameF2TDocument(version.ProductId, version.Id, 0, token);
            /* C51165 mod END Modification for update F2T path */
            return Json(result);
        }

        /// <summary>
        /// Method to delete version
        /// </summary>
        /// <param name="versionId">Unique id of the version</param>
        /// <returns>Returns delete status</returns>
        /// 2019/01/31, Sujith A ,VJP192- Product management changes
        [AuthorizePermissions(MyPermissions.ADD_EDIT_DELETE_PROD_VER)]
        public ActionResult DeleteVersion(int versionId)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var result = manager.DeleteVersion(versionId, token, IsDeletePermission());
            return Json(result);
        }

        /// <summary>
        /// Method to restore deleted version
        /// </summary>
        /// <param name="versionId">Unique id of the version</param>
        /// <returns>Returns restore status</returns>
        /// 2019/03/12, Sharon Thankachan ,VJP192- Product management changes
        [AuthorizePermissions(MyPermissions.ADD_EDIT_DELETE_PROD_VER)]
        public ActionResult RestoreVersion(int versionId)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var result = manager.RestoreVersion(versionId, token, IsDeletePermission());
            return Json(result);
        }

        /// <summary>
        /// Method to retrieve module details
        /// </summary>
        /// <param name="moduleId">Unique id of the module</param>
        /// <returns>Returns module details</returns>
        /// 2019/02/05, Sujith A ,VJP192
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        /// 2020/01/15, Vinoth N, B1K017_Modification for get member profile picture url
        public ActionResult GetModuleDetails(int moduleId)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            /*VJP192_Modification for Deleted Product items START*/
            var module = manager.GetModuleDetails(moduleId, token, IsDeletePermission());
            /* B1K017 mod START Modification for get member profile picrure url */
            if (module != null)
            {
                foreach (var user in module.Members)
                {
                    user.ProfileURL = GenerateProfileURL(user.Name);
                }
            }
            /* B1K017 mod END Modification for get member profile picrure url */
            /*VJP192_Modification for Deleted Product items END*/
            return PartialView("EditModule", module);
        }

        /// <summary>
        /// Method to add module
        /// </summary>
        /// <param name="module">Module details</param>
        /// <returns>Returns add module status</returns>
        /// 2019/02/05, Sujith A ,VJP192
        [AuthorizePermissions("Any", MyPermissions.ADD_EDIT_DELETE_PROD_VER, MyPermissions.ADD_EDIT_DELETE_MODULE)]
        public ActionResult AddModule(ModuleModel module)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var status = manager.AddModule(module, token, true);
            return Json(status);
        }

        /// <summary>
        /// Method to update module
        /// </summary>
        /// <param name="module">Module details</param>
        /// <param name="productName">product name</param>
        /// <param name="versionName">version name</param>
        /// <returns>Returns update module status</returns>
        /// 2019/02/05, Sujith A ,VJP192
        /// 2020/06/19, Vinoth N, C51165_Modification for update F2T path
        [AuthorizePermissions("Any", MyPermissions.ADD_EDIT_DELETE_PROD_VER, MyPermissions.ADD_EDIT_DELETE_MODULE)]
        public ActionResult UpdateModule(ModuleModel module, string productName, string versionName)
        {
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            GeneralResultModel result = new GeneralResultModel { status = true };
            IProductManager manager = new ProductManager();
            /* C51165 mod START Modification for update F2T path */
            result = UpdateF2TFolder(module.Id, productName, versionName, module.ModuleName, 3, token);
            if (result.status)
                result = manager.UpdateModule(module, token, true);
            if (result.status)
                RenameF2TDocument(module.ProductId, module.VersionId, module.Id, token);
            /* C51165 mod END Modification for update F2T path */
            return Json(result);
        }

        /// <summary>
        /// Method to delete module
        /// </summary>
        /// <param name="moduleId">Unique id of the Module</param>
        /// <returns>Returns delete module status</returns>
        /// 2019/02/05, Sujith A ,VJP192
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        [AuthorizePermissions("Any", MyPermissions.ADD_EDIT_DELETE_PROD_VER, MyPermissions.ADD_EDIT_DELETE_MODULE)]
        public ActionResult DeleteModule(int moduleId)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            /*VJP192_Modification for Deleted Product items START*/
            var result = manager.DeleteModule(moduleId, token, IsDeletePermission());
            /*VJP192_Modification for Deleted Product items END*/
            return Json(result);
        }

        /// <summary>
        /// Method to restore deleted module
        /// </summary>
        /// <param name="moduleId">Unique id of the Module</param>
        /// <returns>Returns restore module status</returns>
        /// 2019/03/12, Sharon Thankachan, VJP192_Modification for restore module
        [AuthorizePermissions(MyPermissions.ADD_EDIT_DELETE_PROD_VER, MyPermissions.ADD_EDIT_DELETE_MODULE)]
        public ActionResult RestoreModule(int moduleId)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var result = manager.RestoreModule(moduleId, token, IsDeletePermission());
            return Json(result);
        }

        /// <summary>
        /// Method to create product wizard details
        /// </summary>
        /// <param name="productData">product details</param>
        /// <param name="versionData">version details</param>
        /// <param name="moduleData">module details</param>
        /// <param name="documentData">document details</param>
        /// <param name="removeData">Unique id of the product data</param>
        /// <param name="typeId">Unique id of the creation type</param>
        /// <param name="isNew">flag for creation type</param>
        /// <returns>Returns</returns>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        [HttpPost]
        public ActionResult SaveProductWizard(string productData, string versionData, string moduleData, string documentData, string removeData, int typeId, bool isNew)
        {
            try
            {
                var input = new ProductGroupModel();
                IEnumerable<ProductDataModel> product = JsonConvert.DeserializeObject<IEnumerable<ProductDataModel>>(productData);
                IEnumerable<OtherDataModel> version = JsonConvert.DeserializeObject<IEnumerable<OtherDataModel>>(versionData);
                IEnumerable<OtherDataModel> module = JsonConvert.DeserializeObject<IEnumerable<OtherDataModel>>(moduleData);
                IEnumerable<DocumentDataModel> document = JsonConvert.DeserializeObject<IEnumerable<DocumentDataModel>>(documentData);
                input.ProductData = Mapper.Map<List<ProductDataModel>>(product);
                input.VersionData = Mapper.Map<List<OtherDataModel>>(version);
                input.ModuleData = Mapper.Map<List<OtherDataModel>>(module);
                input.DocumentData = Mapper.Map<List<DocumentDataModel>>(document);
                HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
                string token = cookie.Value;
                string uName = User.Identity.Name;
                CultureInfo currentCulture = System.Globalization.CultureInfo.CurrentCulture;
                TMFLogger.LogInformation("In create pdt wiz");
                string str = Resources.Resource.ResourceManager.GetString("CreateWizardCompleted", CultureInfo.GetCultureInfo(currentCulture.Name));
                Task tsk1 = Task.Run(() => CreateProductGroup(input, typeId, uName, token, currentCulture));
                tsk1.ContinueWith(t => Task.Run(() => DeleteProductGroup(removeData, token, uName, currentCulture)));
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return Json("", JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Method to map document
        /// </summary>
        /// <param name="moduleId">Unique id of the module</param>
        /// <param name="documentPath">Document path to map</param>
        /// <param name="productName">product name</param>
        /// <param name="versionName">version name</param>
        /// <param name="moduleName">module name</param>
        /// <returns>Returns the document mapping status</returns>
        /// 2019/02/05, Sujith A, VJP192_Initial Version
        /// 2020/01/15, Vinoth N, B1K017_Modification for upload multiple document
        /// 2020/06/19, Vinoth N, C51165_Modification for create F2T document when upload from server
        [HttpPost]
        public ActionResult MapDocument(string productName, string versionName, string moduleName, int moduleId, string documentPath)
        {
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            GeneralResultModel result = new GeneralResultModel();
            result.message = "Failed to map document";
            IProductManager manager = new ProductManager();
            bool isUpload = false;
            /* B1K017 mod START Modification for upload multiple document */
            HttpPostedFileBase file = null;
            var dirPath = ConfigurationManager.AppSettings["F2TDocPath"].ToString();
            if (!Directory.Exists(Path.Combine(dirPath, productName)))
            {
                Directory.CreateDirectory(Path.Combine(dirPath, productName));
            }
            if (!Directory.Exists(Path.Combine(dirPath, productName, versionName)))
            {
                Directory.CreateDirectory(Path.Combine(dirPath, productName, versionName));
            }
            if (!Directory.Exists(Path.Combine(dirPath, productName, versionName, moduleName)))
            {
                Directory.CreateDirectory(Path.Combine(dirPath, productName, versionName, moduleName));
            }
            if (Request.Files.Count > 0)
            {
                isUpload = true;
                for (int i = 0; i < Request.Files.Count; i++)
                {
                    file = Request.Files[i];
                    var fileName = file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1);
                    documentPath = Path.Combine(dirPath, productName, versionName, moduleName, fileName);
                    if (!string.IsNullOrEmpty(documentPath))
                    {
                        result = manager.MapDocument(moduleId, documentPath, token);
                    }
                    if (result.status && isUpload && file != null)
                    {
                        file.SaveAs(documentPath);
                    }
                }
            }
            else if (!string.IsNullOrEmpty(documentPath))
            {
                /* C51165 mod START Modification for create F2T document when upload from server */
                var docs = documentPath.Split('|');
                foreach (string doc in docs.Where(p => p != String.Empty))
                {
                    var fileName = System.IO.Path.GetFileName(doc);
                    var destFile = System.IO.Path.Combine(Path.Combine(dirPath, productName, versionName, moduleName), fileName);
                    if (doc.Replace("\\", "").Trim() != destFile.Replace("\\", "").Trim())
                        System.IO.File.Copy(doc, destFile, true);
                    result = manager.MapDocument(moduleId, destFile, token);
                }
                /* C51165 mod END Modification for create F2T document when upload from server */
            }
            /* B1K017 mod END Modification for upload multiple document */
            return Json(result);
        }

        /// <summary>
        /// Method to replace document
        /// </summary>
        /// <param name="productName">Product name.</param>
        /// <param name="versionName">Version name.</param>
        /// <param name="moduleName">Module name.</param>
        /// <param name="moduleId">Unique id of the module.</param>
        /// <param name="docPath">Document path to map.</param>
        /// <returns>Returns the document mapping status</returns>
        /// 2019/08/06, Vinoth N, A0N259_Initial version
        [HttpPost]
        public ActionResult ReplaceDocument(string productName, string versionName, string moduleName, int moduleId, string docPath)
        {
            IProductManager manager = new ProductManager();
            GeneralResultModel result = new GeneralResultModel();
            HttpPostedFileBase file = null;
            if (Request.Files.Count > 0)
            {
                file = Request.Files[0];
                result = manager.ReplaceDocument(productName, versionName, moduleName, moduleId, docPath, file);
            }
            return Json(result);
        }

        /// <summary>
        /// Method to remove document mapping
        /// </summary>
        /// <param name="documentId">Unique id of the document</param>
        /// <returns>Returns remove status</returns>
        /// 2019/02/05, Sujith A, VJP192_Initial version
        /// 2019/02/21, Sharon Thankachan, VJP192_Modification for Deleted Product items
        [HttpPost]
        public ActionResult RemoveDocument(int documentId)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            /*VJP192_Modification for Deleted Product items START*/
            var result = manager.RemoveDocument(documentId, token, IsDeletePermission());
            /*VJP192_Modification for Deleted Product items END*/
            return Json(result);
        }

        /// <summary>
        /// Method to restore document mapping
        /// </summary>
        /// <param name="documentId">Unique id of the document</param>
        /// <returns>Returns restore status</returns>
        /// 2019/03/12, Sharon Thankachan, VJP192_Modification for restore Doc
        [HttpPost]
        public ActionResult RestoreDocument(int documentId)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var result = manager.RestoreDocument(documentId, token, IsDeletePermission());
            return Json(result);
        }

        /// <summary>
        /// Method to download file
        /// </summary>
        /// <param name="filePath">File path</param>
        /// <returns>Returns file content</returns>
        /// 2019/02/05, Sujith A ,VJP192_Initial version
        /// 2020/05/15, Vinoth N, C51165_Modification for encode document name
        public ActionResult DownloadFile(string filePath)
        {
            Response.Clear();
            filePath = filePath.Trim();
            TMFLogger.LogInformation("DownloadFilePath: " + filePath);
            if (System.IO.File.Exists(filePath))
            {
                byte[] fileContent = System.IO.File.ReadAllBytes(filePath);
                FileInfo file = new FileInfo(filePath);
                /* C51165 mod START Modification for encode document name */
                string fileName = filePath.Substring(filePath.LastIndexOf("\\") + 1);
                fileName = Uri.EscapeUriString(fileName);
                Response.AddHeader("content-disposition", String.Format("attachment;filename=\"{0}\"", fileName));
                Response.AddHeader("Content-Length", file.Length.ToString(System.Globalization.CultureInfo.InvariantCulture));
                /* C51165 mod END Modification for encode document name */
                Response.ContentType = "application/octet-stream";
                Response.TransmitFile(file.FullName);
                Response.Flush();
                Response.End();
                Session["fileName"] = string.Empty;
                return File(fileContent, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
            }
            else
            {
                TMFLogger.LogInformation("DownloadFilePath: " + filePath + " not found!");
                return Redirect(Request.UrlReferrer.ToString());
            }
        }

        /// <summary>
        /// Method to validate download file
        /// </summary>
        /// <param name="filePath">File path</param>
        /// <returns>Returns file status</returns>
        /// 2020/10/28, Vinoth N, CRC207_Initial Version
        public ActionResult ValidateDownloadFile(string filePath)
        {
            Response.Clear();
            filePath = filePath.Trim();
            GeneralResultModel result = new GeneralResultModel();
            TMFLogger.LogInformation("DownloadFilePath: " + filePath);
            if (System.IO.File.Exists(filePath))
            {
                try
                {
                    byte[] fileContent = System.IO.File.ReadAllBytes(filePath);
                    result.status = true;
                }
                catch (Exception ex)
                {
                    TMFLogger.LogException(ex);
                    result.status = false;
                    result.message = Resources.Resource.DocumentBusy;
                }

            }
            else
            {
                TMFLogger.LogInformation("DownloadFilePath: " + filePath + " not found!");
                result.status = false;
                result.message = Resources.Resource.DocumentNotFound;
            }

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Method to add members to product/version/module.
        /// </summary>
        /// <param name="id">Unique id of the project.</param>
        /// <param name="members">List of members to be added.</param>
        /// <param name="type">Type id.</param>
        /// <returns>Returns add  members status.</returns>
        /// 2019/02/05, Sujith A, VJP192_Initial version
        [HttpPost]
        public ActionResult AddMembers(int id, List<UserModel> members, string type)
        {
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var result = manager.AddMembers(id, members, type, token);
            return Json(result);
        }

        /// <summary>
        /// Method to render partial view
        /// </summary>
        /// <param name="key">Partial view type</param>
        /// <param name="value">value of folder path</param>
        /// <param name="onlyFolder">flag for folder path</param>
        /// <returns>Returns partial view</returns>
        /// 2019/08/07, Vinoth N, A0N259_Modification for replace F2T document 
        /// 2020/10/19, Vinoth N, CRC207_Modification for static backup path
        [HttpPost]
        public ActionResult RenderPartialView(string key, string value, string onlyFolder)
        {
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            DeserializeProductDetails(token);
            var values = value.Split(',');
            switch (key)
            {
                case "EditProduct":
                    return PartialView("EditProduct", productInfo.ProductsList.Where(x => x.ProductName == values[0]).FirstOrDefault());
                case "EditVersion":
                    return PartialView("EditVersion", productInfo.ProductsList.Where(x => x.ProductName == values[0]).First().Versions.Where(x => x.ProdVersion == values[1]).FirstOrDefault());
                case "EditModule":
                    return PartialView("EditModule",
                        productInfo.ProductsList.Where(x => x.ProductName == values[0]).First()
                        .Versions.Where(x => x.ProdVersion == values[1]).First().Modules.Where(x => x.ModuleName == values[2]).FirstOrDefault());
                case "NewDocument":
                    {
                        F2TViewModel f2tviewmodel = new F2TViewModel();
                        try
                        {
                            ViewResult result = (ViewResult)GetFileExplorer(string.Empty, 1);
                            f2tviewmodel = (F2TViewModel)result.ViewData.Model;
                        }
                        catch (Exception ex)
                        {
                            TMFLogger.LogException(ex);
                        }
                        return PartialView("FileExplorer", GetDefaultModelValues(1, f2tviewmodel.FileModelList, f2tviewmodel.DirModelList));
                    }
                case "BackupRestore":
                    {
                        F2TViewModel f2tviewmodel = new F2TViewModel();
                        try
                        {
                            /* CRC207 mod START Modification for static backup path*/
                            int type;
                            if (!Directory.Exists(Constants.BACKUP_PATH))
                            {
                                Directory.CreateDirectory(Constants.BACKUP_PATH);
                            }
                            ViewResult result = (ViewResult)GetFileExplorer(Constants.BACKUP_PATH, 1, onlyFolder);
                            f2tviewmodel = (F2TViewModel)result.ViewData.Model;
                            /* CRC207 mod END Modification for static backup path*/
                        }
                        catch (Exception ex)
                        {
                            TMFLogger.LogException(ex);
                        }
                        var mm = GetDefaultModelValues(1, f2tviewmodel.FileModelList, f2tviewmodel.DirModelList);
                        mm.Drives = f2tviewmodel.Drives;
                        mm.DirPath = f2tviewmodel.DirPath;
                        if (onlyFolder == "true")
                        {
                            mm.DirPath = mm.Drives[0]?.Text;
                        }
                        return PartialView("FileExplorer", mm);
                    }
                /* A0N259 mod START Modification for File replace */
                case "FileReplace":
                    {
                        F2TViewModel f2tviewmodel = new F2TViewModel();
                        try
                        {
                            ViewResult result = (ViewResult)GetFileExplorer(string.Empty, 1);
                            List<FileModel> files = new List<FileModel>();
                            f2tviewmodel = (F2TViewModel)result.ViewData.Model;
                            files.Add(new FileModel { FileName = values[0], Id = 0 });
                            f2tviewmodel.FileModelList = files;
                        }
                        catch (Exception ex)
                        {
                            TMFLogger.LogException(ex);
                        }
                        return PartialView("FileReplace", f2tviewmodel);
                    }
                /* A0N259 mod END Modification for File replace */
                default:
                    return View();
            }
        }

        /// <summary>
        /// Method to get default model values
        /// </summary>
        /// <returns>product</returns>
        private ProductViewModel GetDefaultModelValues()
        {
            ProductViewModel productModel = new ProductViewModel();
            try
            {
                productModel.ProductList = GetProductList();
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return productModel;
        }

        /// <summary>
        /// Post action
        /// </summary>
        /// <param name="productViewModel">view model</param>
        /// <param name="documentName">name of the document</param>
        /// <param name="versionName">version name</param>
        /// <param name="ModuleName">module name</param>
        /// <param name="productName">product name</param>
        /// <param name="type">process type </param>
        /// <param name="clean">flag for delete testcases in TMF</param>
        /// <returns>Returns product page</returns>
        /// 2018/11/07, Praveen Mp, V29627_Modification for getting import status
        /// 2019/08/07, Vinoth N, A0N259_Modification for email notification
        /// 2020/01/16, Vinoth N, B1K017_Modification for validate document status
        /// 2020/06/19, Vinoth N, C51165_Modification for clean tetscases
        [HttpPost]
        [AuthorizePermissions()]
        public ActionResult Index(ProductViewModel productViewModel, string documentName, string versionName, string ModuleName, string productName, int type, bool clean)
        {
            try
            {
                /* A0N259 mod START Modification for localization */
                string opn = String.Empty;
                string message = String.Empty;
                string funStatus = Resources.Resource.UnableTo;
                GeneralResultModel resultModel = new GeneralResultModel();
                if (type == 1) opn = Resources.Resource.Import;
                else if (type == 2) opn = Resources.Resource.Export;
                else opn = Resources.Resource.GenerateReport;
                funStatus = funStatus.Replace("{0}", opn);
                var accountManger = new AccountManager();
                var f2tManager = new F2TManager(System.Globalization.CultureInfo.CurrentCulture);
                /* A0N259 mod END Modification for localization */
                HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
                string token = cookie.Value;
                string docName = documentName;
                docName = documentName.Substring(documentName.LastIndexOf('\\') + 1);
                if (docName.LastIndexOf('.') > 0)
                    docName = docName.Remove(docName.LastIndexOf('.'));
                string status = f2tManager.GetOperationStatus(token, productName, versionName, ModuleName, docName.Trim());
                var details = status.Split(':');
                /*V29627_Modification for Getting current status of import START*/
                ClearDocfromSession(status, documentName, true);
                if (details.Length > 1)
                {   
                    if (User.Identity.Name.ToLower() == details[0].ToLower())
                    {
                        /* B1K017 mod START Modification for validate document status */
                        if (System.Globalization.CultureInfo.CurrentCulture.Name == "ja-JP")
                        {
                            if (details[1].ToLower() == "import")
                                details[1] = Resources.Resource.Import;
                            else if (details[1].ToLower() == "export")
                                details[1] = Resources.Resource.Export;
                        }
                        /* B1K017 mod END Modification for validate document status */
                        if (string.IsNullOrEmpty(GetImportingDocumentStatusFileName(documentName.Trim())))
                        {
                            Session["docname"] = string.Format("{0}{1}|", Session["docname"], details[2]);
                        }
                        /* A0N259 mod START Modification for localization */
                        if (!opn.Contains(details[1]))
                        {
                            ClearDocfromSession(status, documentName, false);
                            message = Resources.Resource.FileAlreadyUsingLater;
                            message = string.Format(message, details[1]);
                            resultModel.status = false;
                            resultModel.message = string.Empty + ";" + funStatus + ";" + DocumentStatus.Failed.ToString() + ";" + message + ";" + type + ";" + (Session["fileName"] != null ? Session["fileName"].ToString() : string.Empty);
                            return Json(resultModel);
                        }
                        Session["StatusLogin"] = details[0];
                        return View();
                    }
                    else
                    {
                        message = Resources.Resource.FilealreadyUsingUserLater;
                        message = string.Format(message, details[1], details[0]);
                        resultModel.status = false;
                        resultModel.message = string.Empty + ";" + funStatus + ";" + DocumentStatus.Failed.ToString() + ";" + message + ";" + type + ";" + (Session["fileName"] != null ? Session["fileName"].ToString() : string.Empty);
                        return Json(resultModel);
                    }
                }
                if (!System.IO.File.Exists(documentName.Trim()))
                {
                    resultModel.status = false;
                    resultModel.message = string.Empty + ";" + funStatus + ";" + DocumentStatus.Failed.ToString() + ";" + Resources.Resource.DocumentNotFound + ";" + type + ";" + (Session["fileName"] != null ? Session["fileName"].ToString() : string.Empty);
                    return Json(resultModel);
                }
                FileStream stream = null;
                try
                {
                    stream = System.IO.File.OpenWrite(documentName.Trim());
                }
                catch (Exception)
                {
                    /* CRC207 mod START Modification for show progress of import or export */
                    OnResultUpdate(0, funStatus, DocumentStatus.Failed, Resources.Resource.ValidateImportorExport, type, 0);
                    /* CRC207 mod END Modification for show progress of import or export */
                    return View();
                }
                finally
                {
                    if (stream != null)
                        stream.Close();
                }
                /* A0N259 mod END Modification for localization */
                Session["fileName"] = documentName;
                string fileName = documentName.Trim();
                documentName = fileName.Substring(fileName.LastIndexOf('\\') + 1);
                documentName = documentName.Remove(documentName.LastIndexOf('.'));
                string backupFileName = fileName.Remove(fileName.LastIndexOf('.')) + "_Backup" + DateTime.Now.ToString("yyyyMMddHHmmssFFF") + fileName.Substring(fileName.LastIndexOf('.'));
                Response.Cookies["F2TOperation"].Value = "true";
                var dat = DateTime.Now;
                Session["docname"] = string.Format("{0}{1}_{2}.txt|", Session["docname"], documentName.Trim(), token);
                /*V29627_Modification for Getting current status of import END*/
                /*VJP192_Modification for Import Options START*/
                var tokenSource = new CancellationTokenSource();
                var cancToken = tokenSource.Token;
                if (type == 1)
                {
                    f2tManager.OnStatusUpdate += new F2TManager.StatusUpdate(OnResultUpdate);
                    System.IO.File.Copy(fileName, backupFileName);
                    /*VJP192_Modification for Import Options START*/
                    /* A0N259 mod START Modification for email notification */
                    /* C51165 mod START Modification for clean tetscases */
                    System.Threading.Tasks.Task.Run(() => f2tManager.ImportF2TTestcases(token, fileName, productName,
                        versionName, ModuleName, documentName.TrimStart().TrimEnd(), ImportType.Full, "", cancToken, User.Identity.Name, clean)).ContinueWith(delegate
                        {
                            f2tManager.SendStatusNotificationEmail(token, productName, versionName, ModuleName, fileName, true);
                        });
                    /* C51165 mod END Modification for clean tetscases */
                }
                else
                {
                    f2tManager.OnStatusUpdate += new F2TManager.StatusUpdate(OnResultUpdate);
                    System.IO.File.Copy(fileName, backupFileName);
                    System.Threading.Tasks.Task.Run(() => f2tManager.ExportTestCasesasF2T(token, productName,
                        versionName, ModuleName, documentName.TrimStart().TrimEnd(), fileName, new int[0], cancToken, dat)).ContinueWith(delegate
                        {
                            f2tManager.SendStatusNotificationEmail(token, productName, versionName, ModuleName, fileName, false);
                        });
                    /* A0N259 mod END Modification for email notification */
                }
                // VJP192_Modification for Import Options 
                /* B1K017 mod START Modification for set valid application name */
                var appName = GetImportingDocumentStatusFileName(documentName).Replace("|", "").Replace(".txt", "");
                System.Web.HttpContext.Current.Application[appName] = tokenSource;
                /* B1K017 mod END Modification for set valid application name */
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                GeneralResultModel resultModel = new GeneralResultModel();
                resultModel.status = false;
                resultModel.message = string.Empty + ";" + Resources.Resource.DocumentNotFound + ";" + DocumentStatus.Failed.ToString() + ";" + "" + ";" + 1 + ";" + (Session["fileName"] != null ? Session["fileName"].ToString() : string.Empty);
                return Json(resultModel);
            }
            return View();
        }


        /// <summary>
        /// Method to retrieve importing document status
        /// </summary>
        /// <param name="documentName">Name of the document where user clicked</param>
        /// <param name="productName">Name of product</param>
        /// <param name="versionName">Name of version</param>
        /// <param name="ModuleName">Name of module</param>
        /// <returns>Returns status of the document operation</returns>
        [HttpGet]
        [AuthorizePermissions()]
        public ActionResult GetProgressStatus(string documentName, string productName, string versionName, string ModuleName)
        {
            string data = string.Empty;
            List<string> lines = new List<string>();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var f2tManager = new F2TManager(System.Globalization.CultureInfo.CurrentCulture);
            string docName = documentName;
            string statusLogin = String.Empty;
            docName = documentName.Substring(documentName.LastIndexOf('\\') + 1);
            if (docName.LastIndexOf('.') > 0)
                docName = docName.Remove(docName.LastIndexOf('.'));
            string status = f2tManager.GetOperationStatus(token, productName, versionName, ModuleName, docName.Trim());
            if (String.IsNullOrEmpty(status))
            {
                docName = GetImportingDocumentStatusFileName(documentName).Replace("|", "");
            }
            else
            {
                string[] docPath = status.Split(':');
                if (docPath.Count() > 2)
                {
                    Session["StatusLogin"] = docPath[0];
                    docName = docPath[2];
                }
                else
                    docName = GetImportingDocumentStatusFileName(documentName).Replace("|", "");
            }

            try
            {
                var accountManger = new AccountManager();
                statusLogin = Session["StatusLogin"] != null ? Session["StatusLogin"].ToString() : User.Identity.Name;
                if (Session["docname"] != null && (!string.IsNullOrEmpty(Session["docname"].ToString())) && (User.Identity.Name.ToLower() == statusLogin.ToLower()))
                {
                    string path = Constants.APP_DATA_LOG_PATH + "" + docName;
                    lines = System.IO.File.ReadAllLines(path).ToList();
                    if (lines.Count() > 0 && (lines[lines.Count() - 1] == "Completed" || lines[lines.Count() - 1] == "Cancelled"))
                    {
                        // VJP192_Modification for F2T operation cancel 
                        var appName = docName.Remove(docName.IndexOf('.'));
                        System.Web.HttpContext.Current.Application[appName] = null;
                        Session["docname"] = Session["docname"].ToString().Replace(docName + "|", "");
                        Session["StatusLogin"] = null;
                    }

                }
                data = string.Join(" ", lines);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return Content(data);
        }

        /// <summary>
        /// Method to retrieve report generation document status
        /// </summary>
        /// <param name="documentName">Name of the document where user clicked</param>
        /// <param name="productName">Name of product</param>
        /// <param name="versionName">Name of version</param>
        /// <param name="ModuleName">Name of module</param>
        /// <returns>Returns status of the document operation</returns>
        [HttpGet]
        [AuthorizePermissions()]
        public ActionResult GetReportProgressStatus(string documentName, string productName, string versionName, string ModuleName)
        {
            List<string> lines = new List<string>();
            var f2tManager = new F2TManager();
            string statusLogin = Session["StatusLogin"] != null ? Session["StatusLogin"].ToString() : User.Identity.Name;

            if (Session["docname"] != null && !string.IsNullOrEmpty(Session["docname"].ToString()) && (User.Identity.Name.ToLower() == statusLogin.ToLower()))
            {
                var docName = GetImportingDocumentStatusFileName(documentName).Replace("|", "");
                string path = Constants.APP_DATA_LOG_PATH + "" + docName;
                if (System.IO.File.Exists(path))
                    lines = System.IO.File.ReadAllLines(path).ToList();
                if (lines.Count > 0)
                {
                    var lll = lines.Find(m => m.StartsWith("FileName="));
                    if (lines[lines.Count() - 1].StartsWith("FileName="))
                    {
                        lines.RemoveAt(lines.Count() - 1);
                        using (FileStream stream = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.Read))
                        {
                            using (var fw = new StreamWriter(stream))
                            {
                                fw.WriteLine("Generated");
                            }
                        }
                        lines.Add(@"<tr><td></td><td><label>" + Resources.Resource.DownloadFile + "</label>/td></tr>");
                        return Content(string.Join(" ", lines));
                    }
                    if (lines[lines.Count() - 1] == "Cancelled")
                    {
                        lines.RemoveAt(lines.Count() - 1);
                        using (FileStream stream = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.Read))
                        {
                            using (var fw = new StreamWriter(stream))
                            {
                                fw.WriteLine("Generated");
                            }
                        }
                        return Content(string.Join(" ", lines));
                    }
                    if (lll != null)
                    {
                        // VJP192_Modification for F2T operation cancel 
                        var appName = docName.Remove(docName.IndexOf('.'));
                        System.Web.HttpContext.Current.Application[appName] = null;
                        Session["docname"] = Session["docname"].ToString().Replace(docName + "|", "");
                        return Content(lll);
                    }
                }
            }
            return Content(string.Join(" ", lines));
        }

        /// <summary>
        /// Load modules based on product and version
        /// </summary>
        /// <param name="versionName">version name</param>
        /// <param name="productName">product name</param>
        /// <returns></returns>
        /// 2019/02/11, Sujith A ,VJP192- Modified
        [HttpGet]
        [AuthorizePermissions()]
        public ActionResult RefreshModules(string versionName, string productName)
        {
            // 2019/02/11, Sujith A ,VJP192
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            DeserializeProductDetails(token);
            Session["TestSuite"] = versionName;
            return PartialView("ModuleList", GetViewDetails(productName, versionName));
        }

        /// <summary>
        /// fill versions
        /// </summary>
        /// <param name="productName">name of the product</param>
        /// <returns>returns json result</returns>
        /// 2019/02/11, Sujith A ,VJP192- Modified
        [AuthorizePermissions()]
        public ActionResult FillProductVersions(string productName)
        {
            // 2019/02/11, Sujith A ,VJP192- Modified
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            DeserializeProductDetails(token);
            List<SelectListItemHelper> listts = new List<SelectListItemHelper>();
            try
            {
                listts = GetVersionList(productName);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            Session["TestProject"] = productName;
            Session["TestSuite"] = null;
            return Json(listts, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Method to set default product and version
        /// </summary>
        /// <param name="context">context</param>
        [HttpPost]
        [AuthorizePermissions()]
        public void SetDefaultProductandVersion(RequestContext context)
        {
            string productName = string.Empty;
            try
            {
                // 2019/02/08, Sujith A ,VJP192- Product management - Initial version
                HttpCookie cookie = context.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
                string token = cookie.Value;
                if (context.HttpContext.Session["TestProject"] == null)
                {
                    DeserializeProductDetails(token);
                    var prodct = GetProductList().FirstOrDefault();
                    context.HttpContext.Session["TestProject"] = prodct != null ? prodct.Text : string.Empty;
                    context.HttpContext.Session["TestSuite"] = null;
                }
                if (context.HttpContext.Session["TestSuite"] == null)
                {
                    var versions = GetVersionList(context.HttpContext.Session["TestProject"].ToString()).ToList();
                    if (versions.Count() > 1)
                    {
                        var version = versions.Skip(1).FirstOrDefault();
                        context.HttpContext.Session["TestSuite"] = version != null ? version.Text : string.Empty;
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
        }

        /// <summary>
        /// Method to retrieve all members in the project
        /// </summary>
        /// <param name="id">Unique id of the project</param>
        /// <param name="isTCId">Is test case id</param>
        /// <returns>Returns users</returns>
        /// 2019/02/26, Sujith, VJP192_Initial Version
        public JsonResult GetAllProjectMembers(int id, string isTCId)
        {
            List<UserModel> users = new List<UserModel>();
            ProductManager manger = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            bool tt = false;
            bool.TryParse(isTCId, out tt);
            users = manger.GetAllProjectMembers(id, token, tt);
            List<SelectListItemHelper> list = new List<SelectListItemHelper>();
            IAccountManager manager = new AccountManager();
            users = users.Distinct().ToList();
            foreach (var user in users)
            {
                if (list.Find(m => m.Text == user.Name) != null) continue;
                list.Add(new SelectListItemHelper { Value = user.Id.ToString(), Text = user.Name });
            }
            return Json(list.OrderBy(m => m.Text).ToList(), JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Method to retrieve all members in the project
        /// </summary>
        /// <param name="id">Unique id of the project</param>
        /// <param name="isBugId">Is bug id</param>
        /// <returns>Returns users</returns>
        /// 2019/02/26, Sujith, VJP192_Initial Version
        public JsonResult GetAllBugProjectMembers(int id, string isBugId)
        {
            List<UserModel> users = new List<UserModel>();
            ProductManager manger = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            bool tt = false;
            bool.TryParse(isBugId, out tt);
            users = manger.GetAllBugProjectMembers(id, token, tt);
            List<SelectListItemHelper> list = new List<SelectListItemHelper>();
            IAccountManager manager = new AccountManager();
            users = users.Distinct().ToList();
            foreach (var user in users)
            {
                if (list.Find(m => m.Text == user.Name) != null) continue;
                list.Add(new SelectListItemHelper { Value = user.Id.ToString(), Text = user.Name });
            }
            return Json(list.OrderBy(m => m.Text).ToList(), JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Save map script details
        /// </summary>
        /// <param name="projectId">Project Id</param>
        /// <param name="mapScript">Data for map script</param>
        /// <returns>Result of updation</returns>
        /// 2020/10/20, Vinoth N, CRC207_Initial version
        [HttpPost]
        public JsonResult SaveTasScriptDetail(int projectId, string mapScript)
        {
            GeneralResultModel result = new GeneralResultModel();
            IProductManager manager = new ProductManager();
            try
            {
                mapScript = System.Uri.UnescapeDataString(mapScript);
                StringBuilder script = new StringBuilder();
                script.Append(mapScript);
                result = manager.SaveTasScriptDetail(script, projectId);
            }
            catch (Exception ex)
            {
                result.status = false;
                result.message = Resources.Resource.Failed;
                TMFLogger.LogException(ex);
            }
            return Json(result);
        }

        /// <summary>
        /// Get Map Script
        /// </summary>
        /// <param name="projectId">Project Id</param>
        /// <returns>return map Script</returns>
        /// 2020/10/20, Vinoth N, CRC207_Initial version
        public JsonResult GetTasScriptDetail(int projectId)
        {
            IProductManager manager = new ProductManager();
            StringBuilder script = new StringBuilder();
            try
            {
                script = manager.GetTasScriptDetail(projectId);
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            return Json(script.ToString());
        }

        /// <summary>
        /// Method to save build settings
        /// </summary>
        /// <param name="buildSettings">Build settings input.</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/15, Vinoth N, EL5873_Initial Version
        [HttpPost]
        public ActionResult SaveBuildSettings(string buildSettings)
        {
            GeneralResultModel result = new GeneralResultModel();
            try
            {
                IProductManager productManager = new ProductManager();
                IEnumerable<BuildSettingsModel> pathSettingsInput = JsonConvert.DeserializeObject<IEnumerable<BuildSettingsModel>>(buildSettings);
                var value = Request.Cookies["autologin"].Value;
                if (pathSettingsInput.Count() > 0)
                {
                    var inputData = pathSettingsInput.FirstOrDefault();
                    result = productManager.SaveBuildSettings(inputData, value);
                }
            }
            catch (Exception ex)
            {
                result.status = false;
                result.message = Resources.Resource.Failed;
                             if (ex is ArgumentOutOfRangeException)
                {
                    exceptionMessage = "Specified Index was out of range";
                }
                else if (ex is MissingMemberException)
                {
                    if (ex.Message.Contains("has no attribute"))
                    {
                        exceptionMessage = ex.Message.Substring(ex.Message.LastIndexOf(' ')) + " is an invalid command";
                    }
                }
                else if (ex is ArgumentTypeException)
                {
                    exceptionMessage = "Invalid argument(s) found: " + ex.Message;
                }
                else if (ex is Runtime.UnboundNameException)
                {
                    exceptionMessage = ex.Message;
                }
                else if (ex is SMLParserException || ex is InvalidCommandParameterException || ex is DirectoryNotFoundException ||
                    ex is OverflowException)
                {
                    exceptionMessage = ex.Message;
                    switch (exceptionMessage.ToUpper())
                    {
                        case "ARRAY":
                            dataType = TMFDataType.SecsII_Array;
                            break;
                        case "A":
                            dataType = TMFDataType.SecsII_ASCII;
                            break;
                        case "B":
                            dataType = TMFDataType.SecsII_Binary;
                            break;
                        case "BOOLEAN":
                            dataType = TMFDataType.SecsII_Bool;
                            break;
                        case "F4":
                            dataType = TMFDataType.SecsII_F4;
                            break;
                        case "F8":
                            dataType = TMFDataType.SecsII_F8;
                            break;
                        case "I1":
                            dataType = TMFDataType.SecsII_I1;
                            break;
                        case "I2":
                            dataType = TMFDataType.SecsII_I2;
                            break;
                        case "I4":
                            dataType = TMFDataType.SecsII_I4;
                            break;
                        case "I8":
                            dataType = TMFDataType.SecsII_I8;
                            break;
                        case "JIS8":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "LCS":
                            dataType = TMFDataType.SecsII_LCS;
                            break;
                        case "U1":
                            dataType = TMFDataType.SecsII_U1;
                            break;
                        case "U2":
                            dataType = TMFDataType.SecsII_U2;
                            break;
                        case "U4":
                            dataType = TMFDataType.SecsII_U4;
                            break;
                        case "U8":
                            dataType = TMFDataType.SecsII_U8;
                            break;
                        case "J":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "L":
                            dataType = TMFDataType.SecsII_List;
                            break;
                        default:
                            throw new SMLParserException("Invalid data type '" + msgType + "' found");
                    }
                }
                TMFLogger.LogException(ex);
            }
            return Json(result);
        }

        /// <summary>
        /// Method to get build settings
        /// </summary>
        /// <param name="productId">Product Id.</param>
        /// <param name="versionId">Version Id.</param>
        /// <returns>Returns build settings.</returns>
        /// 2021/06/16, Vinoth N, EL5873_Initial Version
        public ActionResult GetBuildSettings(int productId, int versionId)
        {
            IProductManager productManager = new ProductManager();
            BuildSettingsModel output = productManager.GetBuildSettings(productId, versionId);
            return Json(output, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Method to get path settings
        /// </summary>
        /// <param name="Id">Settings Id.</param>
        /// <returns>Returns path settings.</returns>
        /// 2021/06/17, Vinoth N, EL5873_Initial Version
        public ActionResult GetPathConfiguration(int id)
        {
            IProductManager productManager = new ProductManager();
            PathSettingsModel output = productManager.GetPathConfiguration(id);
            return Json(output, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Method to save path settings
        /// </summary>
        /// <param name="pathSettings">Path settings input.</param>
        /// <returns>Returns TRUE | FALSE</returns>
        /// 2021/06/18, Vinoth N, EL5873_Initial Version
        [HttpPost]
        public ActionResult SavePathConfiguration(string pathSettings)
        {
            GeneralResultModel result = new GeneralResultModel();
            try
            {
                IProductManager productManager = new ProductManager();
                IEnumerable<PathSettingsModel> pathSettingsInput = JsonConvert.DeserializeObject<IEnumerable<PathSettingsModel>>(pathSettings);
                if(pathSettingsInput.Count() > 0)
                {
                    var inputData = pathSettingsInput.FirstOrDefault();
                    result = productManager.SavePathConfiguration(inputData);
                }
            }
            catch (Exception ex)
            {
                result.status = false;
                result.message = Resources.Resource.Failed;
                             if (ex is ArgumentOutOfRangeException)
                {
                    exceptionMessage = "Specified Index was out of range";
                }
                else if (ex is MissingMemberException)
                {
                    if (ex.Message.Contains("has no attribute"))
                    {
                        exceptionMessage = ex.Message.Substring(ex.Message.LastIndexOf(' ')) + " is an invalid command";
                    }
                }
                else if (ex is ArgumentTypeException)
                {
                    exceptionMessage = "Invalid argument(s) found: " + ex.Message;
                }
                else if (ex is Runtime.UnboundNameException)
                {
                    exceptionMessage = ex.Message;
                }
                else if (ex is SMLParserException || ex is InvalidCommandParameterException || ex is DirectoryNotFoundException ||
                    ex is OverflowException)
                {
                    exceptionMessage = ex.Message;
                    switch (exceptionMessage.ToUpper())
                    {
                        case "ARRAY":
                            dataType = TMFDataType.SecsII_Array;
                            break;
                        case "A":
                            dataType = TMFDataType.SecsII_ASCII;
                            break;
                        case "B":
                            dataType = TMFDataType.SecsII_Binary;
                            break;
                        case "BOOLEAN":
                            dataType = TMFDataType.SecsII_Bool;
                            break;
                        case "F4":
                            dataType = TMFDataType.SecsII_F4;
                            break;
                        case "F8":
                            dataType = TMFDataType.SecsII_F8;
                            break;
                        case "I1":
                            dataType = TMFDataType.SecsII_I1;
                            break;
                        case "I2":
                            dataType = TMFDataType.SecsII_I2;
                            break;
                        case "I4":
                            dataType = TMFDataType.SecsII_I4;
                            break;
                        case "I8":
                            dataType = TMFDataType.SecsII_I8;
                            break;
                        case "JIS8":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "LCS":
                            dataType = TMFDataType.SecsII_LCS;
                            break;
                        case "U1":
                            dataType = TMFDataType.SecsII_U1;
                            break;
                        case "U2":
                            dataType = TMFDataType.SecsII_U2;
                            break;
                        case "U4":
                            dataType = TMFDataType.SecsII_U4;
                            break;
                        case "U8":
                            dataType = TMFDataType.SecsII_U8;
                            break;
                        case "J":
                            dataType = TMFDataType.SecsII_JIS8;
                            break;
                        case "L":
                            dataType = TMFDataType.SecsII_List;
                            break;
                        default:
                            throw new SMLParserException("Invalid data type '" + msgType + "' found");
                    }
                }
                TMFLogger.LogException(ex);
            }          
            return Json(result);
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Executes on page load
        /// </summary>
        /// <param name="callback"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        protected override IAsyncResult BeginExecuteCore(AsyncCallback callback, object state)
        {
            string lang = null;
            HttpCookie langCookie = Request.Cookies["culture"];
            if (langCookie != null)
            {
                lang = langCookie.Value;
            }
            else
            {
                var userLanguage = Request.UserLanguages;
                var userLang = userLanguage != null ? userLanguage[0] : "";
                if (userLang != "")
                {
                    lang = userLang;
                }
                else
                {
                    lang = LanguageManager.GetDefaultLanguage();
                }
            }
            new LanguageManager().SetLanguage(lang);
            return base.BeginExecuteCore(callback, state);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Method to retrieve importing document file name
        /// </summary>
        /// <param name="documentName">Name of the document where user clicked</param>
        /// <returns>Returns status file name of the document operation</returns>
        /// 2020/10/21, Vinoth N, CRC207_Modification for get document status
        private string GetImportingDocumentStatusFileName(string documentName)
        {
            string statusFileName = string.Empty;
            /* CRC207 mod START Modification for get document status */
            if (!String.IsNullOrEmpty(documentName))
            {
                documentName = documentName.Trim();
                if (documentName.LastIndexOf('\\') > 0 && documentName.LastIndexOf('.') > 0)
                {
                    documentName = documentName.Substring(documentName.LastIndexOf('\\') + 1);
                    documentName = documentName.Remove(documentName.LastIndexOf('.'));
                }
                if (Session["docname"] != null)
                {
                    var sessionNames = Session["docname"].ToString().Split('|').
                        Where(m => m.Contains(documentName)).ToList();
                    string docName = Session["docname"].ToString();
                    foreach (var doc in sessionNames)
                    {
                        var nn = doc;
                        nn = nn.Remove(nn.LastIndexOf('_'));
                        if (nn == documentName)
                        {
                            statusFileName = doc;
                            break;
                        }
                    }
                }
            }
            /* CRC207 mod END Modification for get document status */
            return statusFileName;
        }

        /// <summary>
        /// Method to initialize view details
        /// </summary>
        /// <param name="productName">product name</param>
        /// <param name="versionName">version name</param>
        /// <returns></returns>
        private ProductViewModel GetViewDetails(string productName, string versionName)
        {
            TMFLogger.LogMethodEntry();
            TMFLogger.LogInformation("PRODUCT:- " + productName + " VERSION:- " + versionName);
            ProductViewModel productViewModel = new ProductViewModel();
            try
            {
                productViewModel.ProductList = GetProductList();
                if (productName == string.Empty)
                {
                    if (productViewModel.ProductList.Count == 1)
                    {
                        productName = (productViewModel.ProductList.Count == 1) ? productViewModel.ProductList[0].Value : string.Empty;
                        productViewModel.SelectedProductId = productName;
                    }
                }
                if (productViewModel.SelectedProductId != String.Empty)
                {
                    productViewModel.VersionList = GetVersionList(productName);
                    if (versionName == string.Empty)
                    {
                        if (productViewModel.VersionList.Count == 1)
                        {
                            versionName = (productViewModel.VersionList.Count == 1) ? productViewModel.VersionList[0].Value : string.Empty;
                            productViewModel.SelectedVersionId = versionName;
                        }
                    }
                    productViewModel.SelectedProductId = productName;
                    productViewModel.SelectedVersionId = versionName;
                    productViewModel.ModuleList = GetModuleList(productName, versionName);
                }
                else
                {
                    List<SelectListItemHelper> lst = new List<SelectListItemHelper>
                    {
                        new SelectListItemHelper { Value = "", Text = Resources.Resource.Select }
                    };
                    productViewModel.VersionList = lst;
                }

            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
            TMFLogger.LogMethodExit();
            return productViewModel;
        }

        /// <summary>
        /// Gets project name and test suite name from cookies
        /// </summary>
        /// <param name="testProjectName">Project name</param>
        /// <param name="testSuiteName">Test suite name</param>
        private void GetProjectAndSuiteFromCookie(ref string testProjectName, ref string testSuiteName)
        {
            SetDefaultProductandVersion(this.Request.RequestContext);
            if (Session["TestProject"] != null && Session["TestSuite"] != null)
            {
                testProjectName = Session["TestProject"].ToString();
                testSuiteName = Session["TestSuite"].ToString();
            }
        }

        /// <summary>
        /// Method to retrieve products
        /// </summary>
        /// <returns>Returns list of products</returns>
        private List<SelectListItemHelper> GetProductList()
        {
            TMFLogger.LogMethodEntry();
            List<SelectListItemHelper> list = new List<SelectListItemHelper>();
            if (productInfo != null)
            {
                for (int i = 0; i < productInfo.ProductsList.Count; i++)
                {
                    list.Add(new SelectListItemHelper { Value = productInfo.ProductsList[i].ProductName, Text = productInfo.ProductsList[i].ProductName });
                }
            }
            TMFLogger.LogMethodExit();
            return list;
        }

        /// <summary>
        /// Method to retrieve versions
        /// </summary
        /// <param name="productName">product name</param>
        /// <returns>Returns list of products</returns>
        private List<SelectListItemHelper> GetVersionList(string productName = "")
        {
            TMFLogger.LogMethodEntry();
            List<SelectListItemHelper> list = new List<SelectListItemHelper>();

            if (productInfo != null)
            {
                list.Add(new SelectListItemHelper { Value = "", Text = Resources.Resource.Select });
                foreach (ProductModel product in productInfo.ProductsList)
                {
                    if (product.ProductName.Equals(productName))
                    {
                        for (int i = 0; i < product.Versions.Count; i++)
                        {
                            list.Add(new SelectListItemHelper { Value = product.Versions[i].VersionName, Text = product.Versions[i].VersionName });
                        }

                    }
                }
            }
            TMFLogger.LogMethodExit();

            return list;
        }

        /// <summary>
        /// Method to get the module list
        /// </summary>
        /// <param name="productname">Product name</param>
        /// <param name="versioname">version name</param>
        /// <returns></returns>
        /// 2019/02/08, Sujith A, VJP192- Product management - Initial version
        /// 2020/10/21, Vinoth N, CRC207_Modification for get operation type
        private List<ModuleModel> GetModuleList(string productname, string versioname)
        {
            TMFLogger.LogMethodEntry();
            List<ModuleModel> modules = new List<ModuleModel>();
            ProductModel product = (from products in productInfo.ProductsList
                                    where products.ProductName.Equals(productname)
                                    select products).FirstOrDefault();
            VersionModel version = (from versions in product.Versions
                                    where versions.VersionName.Equals(versioname)
                                    select versions).FirstOrDefault();
            TestCaseManager manager = new TestCaseManager();
            int i = 0;
            foreach (ModuleModel module in version.Modules)
            {

                var ss = manager.GetDocumentDetails(productname, versioname, module.ModuleName);
                if (ss.Count > 0)
                {
                    ss.RemoveAll(m => module.DocModels.Find(n => n.Name == m.Name) == null);
                }
                /* CRC207 mod START Modification for get operation type */
                foreach (var s in ss)
                {
                    var controller = DependencyResolver.Current.GetService<TestCaseController>();
                    controller.ControllerContext = new ControllerContext(this.Request.RequestContext, controller);
                    dynamic data = controller.ValidateDocumentStatus(productname, versioname, module.ModuleName, s.Name);
                    if (data != null)
                    {
                        s.ActionUser = data.Name;
                        string status = data.Type;
                        if (data.Type == "Import")
                        {
                            status = Resources.Resource.Importing;
                        }
                        else if (data.Type == "Export")
                        {
                            status = Resources.Resource.Exporting;
                        }
                        s.TypeId = status;
                    }
                }
                /* CRC207 mod END Modification for operation type */
                foreach (var doc in module.DocModels)
                {
                    var docName = doc.DocumentPath.Trim();
                    var fileInfo = new System.IO.FileInfo(docName);
                    DocumentModel mod = null;
                    string planName = string.Empty;
                    if (doc.TestPlanName == null)
                    {
                        planName = versioname + "_" + module.ModuleName + "_" + docName;
                    }
                    if (docName.LastIndexOf('.') >= 0 && docName.LastIndexOf('\\') >= 0)
                    {
                        docName = docName.Substring(0, docName.LastIndexOf('.'));
                        docName = docName.Remove(0, docName.LastIndexOf('\\') + 1);
                        if (doc.TestPlanName == null)
                        {
                            planName = module.ModuleName + "_" + doc.Name;
                        }
                        mod = ss.FirstOrDefault(m => m.Name == doc.Name);
                        if (mod != null)
                        {
                            mod.Name = doc.Name;
                            mod.DocumentPath = doc.DocumentPath;
                            int compVal = String.Compare(fileInfo.LastWriteTime.ToString("yyyyMMddhhmmss"), mod.LastUpdateTime.ToString("yyyyMMddhhmmss"));
                            if (compVal == 0)
                            {
                                mod.SysncStatus = SyncStatus.InSync;
                            }
                            else if (compVal < 0)
                            {
                                mod.SysncStatus = SyncStatus.TMFLatest;
                            }
                            else
                            {

                                mod.SysncStatus = SyncStatus.DocumentLatest;
                            }
                            if (mod.TestPlanName == null)
                            {
                                mod.TestPlanName = planName;
                            }

                        }
                    }
                    if (mod == null && ss.Find(m => m.Name == docName) == null)
                    {
                        ss.Add(new DocumentModel()
                        {
                            // 2019/02/18, Sujith A ,VJP192- modified
                            Id = doc.Id,
                            TestPlanName = planName,
                            Name = doc.DocumentPath,
                            SysncStatus = SyncStatus.DocumentLatest
                        });
                    }

                    i++;
                }
                modules.Add(new ModuleModel { ModuleName = module.ModuleName, SyncStatus = module.SyncStatus, Docs = module.Docs, DocModels = ss, DocCount = module.DocModels.Count });
            }
            TMFLogger.LogMethodExit();
            return modules;
        }

        /// <summary>
        /// Gets the product details after de-serialization
        /// </summary>
        /// <param name="token">token</param>
        /// 2019/02/08, Sujith A ,VJP192- Product management - Initial version
        private void DeserializeProductDetails(string token)
        {
            var manager = new ProductManager();
            productInfo = new Products();
            productInfo.ProductsList = manager.GetAllProducts(token);

        }

        /// <summary>
        /// Method to show import\export status on UI
        /// </summary>
        /// <param name="id">Id of the test case</param>
        /// <param name="tcName">Name of the test case</param>
        /// <param name="status">Status of test case</param>
        /// <param name="error">Error message for test case parsing</param>
        /// <param name="type">message type</param>
        /// <param name="count"> total number of testcases</param>
        /// <param name="message">message</param>
        /// 2020/02/25, Vinoth N, B1K017_Modification for notify parallel operation
        /// 2020/10/22, Vinoth N, CRC207_Modification for operation status
        private void OnResultUpdate(int id, string tcName, DocumentStatus status, string error, int type, int count, string message = "")
        {
            try
            {
                /* B1K017 mod START Modification for notify parallel operation */
                if (type > 2)
                {
                    /* CRC207 mod START Modification for notify parallel operation */
                    var statusMsg = type == 3 ? Resources.Resource.Importing : Resources.Resource.Exporting;
                    statusMsg = "Status:" + message + ":" + statusMsg + ":" + count + ":" + status.ToString();
                    /* CRC207 mod END Modification for notify parallel operation */
                    switch (status.ToString())
                    {
                        case "Completed":
                            Task.Run(() => ProgressHub.SendMessage(statusMsg, null));
                            break;
                        case "Cancelled":
                            Task.Run(() => ProgressHub.SendMessage(statusMsg, null));
                            break;
                        case "Exported":
                            Task.Run(() => ProgressHub.SendMessage(statusMsg, null));
                            break;
                        case "Imported":
                            Task.Run(() => ProgressHub.SendMessage(statusMsg, null));
                            break;
                    }
                }
                else
                {
                    string fileName = Session["fileName"] != null ? Session["fileName"].ToString() : string.Empty;
                    logs.Add(new StatusLogViewModel { Id = logs.Count + 1, Error = error, Status = status, TcName = tcName, Type = type });
                    string idd = id == 0 ? "" : id.ToString();
                    var msg = idd + ";" + tcName + ";" + status + ";" + error + ";" + type + ";" + fileName;
                    Task.Run(() => ProgressHub.SendMessage(msg, User.Identity.Name));
                    if (status == DocumentStatus.Completed)
                    {
                        Response.Cookies["F2TOperation"].Value = "false";
                        Request.Cookies["F2TOperation"].Value = "false";
                    }
                }
                /* B1K017 mod END Modification for notify parallel operation  */
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
        }
        /// <summary>
        /// Method to remove uncleared session values
        /// </summary>
        /// <param name="status">Status</param>
        /// <param name="documentName">document name</param>
        /// <param name="matchOperation">type of operation</param>
        /// 2018/11/21, Praveen M P , V29627_Initial version
        private void ClearDocfromSession(string status, string documentName, bool matchOperation)
        {
            documentName = documentName.Substring(documentName.LastIndexOf('\\') + 1);
            if (documentName.LastIndexOf('.') > 0)
                documentName = documentName.Remove(documentName.LastIndexOf('.')).Trim();
            if (matchOperation)
            {
                if (string.IsNullOrEmpty(status) && Session["docname"] != null)
                {
                    var sessionNames = Session["docname"].ToString().Split('|');
                    foreach (var ses in sessionNames)
                    {
                        if (ses.StartsWith(documentName))
                            Session["docname"] = Session["docname"].ToString().Replace(ses + "|", "");
                    }
                }
            }
            else
            {
                var sessionNames = Session["docname"].ToString().Split('|');
                foreach (var ses in sessionNames)
                {
                    if (ses.StartsWith(documentName))
                        Session["docname"] = Session["docname"].ToString().Replace(ses + "|", "");
                }
            }
        }

        /// <summary>
        /// Get file explorer details
        /// </summary>
        /// <param name="link">link value</param>
        /// <param name="viewModelType">view type</param>
        /// <param name="onlyFolder">flag object</param>
        /// <returns>View</returns>
        private ActionResult GetFileExplorer(string link, int viewModelType, string onlyFolder = "false")
        {
            object model = null;
            string realPath = string.Empty;
            List<SelectListItemHelper> drives = new List<SelectListItemHelper>();
            if (string.IsNullOrEmpty(link))
            {
                realPath = Constants.SERVER_PATH;
            }
            else
            {
                realPath = link.Replace("\n", "").Trim();
            }
            if (onlyFolder == "true" || viewModelType == -1)
            {
                foreach (DriveInfo drive in System.IO.DriveInfo.GetDrives())
                {
                    drives.Add(new SelectListItemHelper()
                    {
                        Text = drive.Name,
                        Value = drive.Name,
                        Selected = (link + "\\").StartsWith(drive.Name)
                    }
                    );

                }
                realPath = string.IsNullOrEmpty(link) ? drives.FirstOrDefault()?.Text : link;
            }
            List<DirModel> dirListModel = new List<DirModel>();
            List<FileModel> fileListModel = new List<FileModel>();
            if (System.IO.File.Exists(realPath))
            {
                return base.File(realPath, "application/octet-stream");
            }
            else if (System.IO.Directory.Exists(realPath))
            {
                Uri url = Request.Url;
                if (url.ToString().EndsWith("/"))
                {
                    Response.Redirect(Constants.SERVER_PATH + link + "/");
                }
                dirListModel = GetDirList(realPath);
                if (string.IsNullOrEmpty(onlyFolder) || onlyFolder == "false")
                {
                    fileListModel = GetFileList(realPath);
                }
            }
            else
            {
                throw new DirectoryNotFoundException("Path not exist or you have no permission to access this path.");
            }
            switch (viewModelType)
            {
                case 1:
                    model = new F2TViewModel(dirListModel, fileListModel, link, drives);
                    break;
                case -1:
                    model = new F2TViewModel(dirListModel, fileListModel, realPath, drives);
                    break;
            }

            return View(model);
        }

        /// <summary>
        /// Get the list of directory
        /// </summary>
        /// <param name="path">base directory path</param>
        /// <returns>Directory list</returns>
        private List<DirModel> GetDirList(string path)
        {
            List<DirModel> dirListModel = new List<DirModel>();

            if (path.EndsWith(":"))
            {
                DriveInfo hDrive = new DriveInfo(path.Trim().TrimEnd(':'));
                foreach (DirectoryInfo folder in hDrive.RootDirectory.EnumerateDirectories())
                {
                    DirModel dirModel = new DirModel();
                    dirModel.DirName = folder.Name;
                    dirModel.DirAccessed = folder.LastAccessTime;

                    dirListModel.Add(dirModel);
                }

            }
            else if (Directory.Exists(path))
            {
                IEnumerable<string> dirList = Directory.EnumerateDirectories(path);
                foreach (string dir in dirList)
                {
                    DirectoryInfo d = new DirectoryInfo(dir);

                    DirModel dirModel = new DirModel();

                    dirModel.DirName = Path.GetFileName(dir);
                    dirModel.DirAccessed = d.LastAccessTime;

                    dirListModel.Add(dirModel);
                }
            }

            return dirListModel;
        }

        /// <summary>
        /// get the list of files in directory
        /// </summary>
        /// <param name="path">base directory path</param>
        /// <returns>File list</returns>
        private List<FileModel> GetFileList(string path)
        {
            List<FileModel> fileListModel = new List<FileModel>();
            IEnumerable<string> fileList = Directory.EnumerateFiles(path);
            int i = 0;
            foreach (string file in fileList)
            {
                FileInfo f = new FileInfo(file);
                FileModel fileModel = new FileModel();

                if (f.Extension.ToLower() == ".doc" || f.Extension.ToLower() == ".docx" || f.Extension.ToLower() == ".docm" || f.Extension.ToLower() == ".zip")
                {
                    if (!Path.GetFileNameWithoutExtension(file).ToLower().Contains("backup") && !f.Attributes.HasFlag(FileAttributes.Hidden))
                    {
                        fileModel.Id = i++;
                        fileModel.FileName = Path.GetFileName(file);
                        fileModel.FileAccessed = f.LastAccessTime;
                        fileModel.FileSizeText = (f.Length < 1024) ? f.Length.ToString() + " B" : f.Length / 1024 + " KB";
                        fileModel.IsSelected = false;

                        fileListModel.Add(fileModel);
                    }
                }
            }

            return fileListModel;
        }

        /// <summary>
        /// get model default values
        /// </summary>
        /// <param name="viewModelType">model type</param>
        /// <param name="fileList">collection of files</param>
        /// <param name="dirList">collection of directories</param>
        /// <returns>View model as object</returns>
        private F2TViewModel GetDefaultModelValues(int viewModelType, List<FileModel> fileList, List<DirModel> dirList)
        {
            F2TViewModel model = null;
            List<SelectListItemHelper> listDefault = new List<SelectListItemHelper>();
            listDefault.Add(new SelectListItemHelper { Value = "0", Text = Resources.Resource.Select });
            if (viewModelType == 1)
            {
                model = new F2TViewModel()
                {
                    FileModelList = fileList,
                    DirModelList = dirList,
                    TestSuiteList = listDefault,
                    IsUploadFromServer = false,
                    FieldsEditable = false,
                    IsOpenDialog = false,
                    DirPath = Constants.SERVER_PATH
                };
            }
            return model;
        }

        /// <summary>
        /// For navigating directory
        /// </summary>
        /// <param name="text">name of the directory</param>
        /// <param name="isBack">type id</param>
        /// <param name="vModel">model value</param>
        /// <param name="onlyFolder">name of the folder</param>
        /// <returns>File explorer page</returns>
        [HttpGet]
        public ActionResult NavigateDir(string text, int isBack, int vModel, string onlyFolder)
        {
            object model = null;
            string realPath;
            string modelPath = string.Empty;
            text = text.Replace("\n", "").Trim();
            text = text.Replace(":\\\\", ":\\").Trim();
            if (isBack == 0)
            {
                realPath = text;
                modelPath = text;
            }
            else
            {
                if (!(text.Equals(Constants.SERVER_PATH) || text.Equals(Constants.BACKUP_PATH)))
                {
                    string temp = text;
                    int index = text.LastIndexOf("\\");
                    if (index > 0 && !(text.StartsWith("\\") && index == 1))
                        text = text.Substring(0, index);
                    if (text.StartsWith("\\") && !Directory.Exists(text))
                        text = temp;
                }
                if (text.IndexOf(":") == text.Length - 1)
                {
                    text = text.Replace(":", ":\\");
                }
                realPath = (text);
                modelPath = text;
            }
            try
            {
                ViewResult result = (ViewResult)GetFileExplorer(realPath, vModel, onlyFolder);
                string path = text.Replace("\n", "").Trim();
                if (vModel == 1 || vModel == -1)
                {
                    model = new F2TViewModel() { DirPath = path };
                    model = (F2TViewModel)result.ViewData.Model;
                }
            }
            catch (Exception ex)
            {
                GeneralResultModel genModel = new GeneralResultModel();
                genModel.status = false;
                TMFLogger.LogException(ex);
                genModel.message = "Path not exist or you have no permission to access this path.";
                return Json(genModel, JsonRequestBehavior.AllowGet);
            }
            if (vModel == 1 || vModel == -1)
            {
                return PartialView("FileExplorer", model);
            }
            else
            {
                return PartialView("ExportFileExplorer", model);
            }
        }

        /// <summary>
        /// Method to find whether user has permanent delete privilege
        /// </summary>
        /// <returns>Returns privilege status</returns>
        /// 2019/02/18, Sujith A ,VJP192- Initial version -Product management
        private bool IsDeletePermission()
        {
            var LoggedInUserPermissions = (List<PermissionModel>)Session["UserPermissions"];
            var isPerDelete = LoggedInUserPermissions.Any(y => y.PermissionID == Convert.ToInt32(MyPermissions.PERMANENT_DELETE));
            return isPerDelete;
        }

        /// <summary>
        /// Method to generate profile picture URL
        /// </summary>
        /// <param name="userName">User name</param>
        /// <returns>Returns profile url</returns>
        /// 2020/01/08, Vinoth N, B1K017_Inital Version
        private string GenerateProfileURL(string userName)
        {
            var path = Server.MapPath(Constants.APP_DATA_PROFILE_PATH);
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            string fileName = userName + ".png";
            string filePath = path + "\\" + fileName;
            if (System.IO.File.Exists(filePath))
            {
                path = "../Uploads/profilePicture/" + fileName;
            }
            else
            {
                path = Constants.APP_DATA_PROFILE_PATH_DEFAULT;
            }

            return path;
        }

        /// <summary>
        /// Method to create product wizard
        /// </summary>
        /// <param name="groupData">product group details</param>
        /// <param name="typeId">unique id of the creation type</param>
        /// <param name="user">login username</param>
        /// <param name="token">user token</param>
        /// <param name="currentCulture">name of culture</param>
        /// <returns>Returns</returns>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        /// 2021/02/22, Vinoth N, DMG213_Modification for send mail 
        /// 2021/06/11, Vinoth N, EL5873_Modification for build settings
        private async Task CreateProductGroup(ProductGroupModel groupData, int typeId, string user, string token, CultureInfo currentCulture)
        {
            TMFLogger.LogMethodEntry();
            GeneralResultModel status = new GeneralResultModel();
            bool isSuccess = true;
            /* EL5873 mod START Modification for build settings */
            /* DMG213 mod START Modification for send mail */
            List<MailGroupModel> mailList = new List<MailGroupModel>();
            MailGroupDataModel data = new MailGroupDataModel();
            List<string> users = new List<string>();
            /* DMG213 mod END Modification for send mail */
            await Task.Run(() =>
            {
                TMFLogger.LogInformation("In CreateProductGroup TASK");
                SetCulture(currentCulture);
                try
                {
                    IProductManager manager = new ProductManager();
                    int loop = typeId;
                    while (loop < 5)
                    {
                        switch (loop)
                        {
                            case 1:
                                foreach (var productData in groupData.ProductData)
                                {
                                    ProductModel product = new ProductModel
                                    {
                                        ProductName = productData.Name,
                                        Members = productData.Members,
                                        Description = productData.Description
                                    };
                                    /* DMG213 mod START Modification for send mail */
                                    data = new MailGroupDataModel
                                    {
                                        ProductName = product.ProductName
                                    };
                                    if (productData.IsModified)
                                    {
                                        product.Id = productData.Id;
                                        users = manager.GetMembers(product.Id);
                                        status = manager.UpdateProduct(product, token);
                                        status = UpdateF2TFolder(product.Id, product.ProductName, String.Empty, String.Empty, 1, token);
                                        if (status.status)
                                            status = manager.UpdateProduct(product, token);
                                        if (status.status)
                                        {
                                            RenameF2TDocument(product.Id, 0, 0, token);
                                            ExtractMailGroup(product.Id, ref mailList, data, users, 2);
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardProductEdit.Replace("{{0}}", productData.Name), user);
                                        }
                                        else
                                        {
                                            isSuccess = status.status;
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardProductError.Replace("{{0}}", productData.Name + "\"" + status.message), user);
                                        }
                                    }
                                    else if (productData.IsNew)
                                    {
                                        users = product.Members.Select(p => p.Id.ToString()).ToList();
                                        status = manager.AddProduct(product, token);
                                        if (status.status)
                                        {
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.CreateWizardProductAdd.Replace("{{0}}", productData.Name), user);
                                            productData.ParentId = status.id;
                                            ExtractMailGroup(product.Id, ref mailList, data, users, 1);
                                            foreach (var version in groupData.VersionData.Where(p => p.RootId == productData.Id))
                                            {
                                                version.ParentId = status.id;
                                            }
                                        }
                                        else
                                        {
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.CreateWizardProductError.Replace("{{0}}", productData.Name), user);
                                        }
                                    }
                                    /* DMG213 mod END Modification for send mail */
                                }
                                break;
                            case 2:
                                foreach (var versionData in groupData.VersionData)
                                {
                                    VersionModel version = new VersionModel
                                    {
                                        VersionName = versionData.Name,
                                        Description = versionData.Description,
                                        ProductId = versionData.ParentId,
                                        Members = versionData.Members
                                    };
                                    /* DMG213 mod START Modification for send mail */
                                    var parent = groupData.ProductData.Where(p => p.Id == versionData.RootId).FirstOrDefault();
                                    data = new MailGroupDataModel
                                    {
                                        ProductName = parent.Name,
                                        VersionName = version.VersionName
                                    };
                                    if (versionData.IsNew)
                                    {
                                        users = version.Members.Select(p => p.Id.ToString()).ToList();
                                        status = manager.AddVersion(version, token);
                                        if (status.status)
                                        {
                                            ExtractMailGroup(version.Id, ref mailList, data, users, 1);
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.CreateWizardVersionAdd.Replace("{{0}}", versionData.Name), user);
                                            foreach (var module in groupData.ModuleData.Where(p => p.RootId == versionData.Id))
                                            {
                                                module.ParentId = status.id;
                                            }
                                        }
                                        else
                                        {
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.CreateWizardVersionError.Replace("{{0}}", versionData.Name), user);
                                        }
                                    }
                                    else if (versionData.IsModified)
                                    {
                                        version.Id = versionData.Id;
                                        users = manager.GetMembers(version.Id);
                                        status = UpdateF2TFolder(version.Id, parent.Name, version.VersionName, String.Empty, 2, token);
                                        if (status.status)
                                            status = manager.UpdateVersion(version, token);
                                        if (status.status)
                                        {
                                            RenameF2TDocument(version.ProductId, version.Id, 0, token);
                                            ExtractMailGroup(version.Id, ref mailList, data, users, 2);
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardVersionEdit.Replace("{{0}}", versionData.Name), user);
                                        }
                                        else
                                        {
                                            isSuccess = status.status;
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardVersionError.Replace("{{0}}", versionData.Name + "\"" + status.message), user);
                                            break;
                                        }
                                    }
                                    /* DMG213 mod END Modification for send mail */
                                }
                                break;
                            case 3:
                                foreach (var moduleData in groupData.ModuleData)
                                {
                                    var versionRecord = groupData.VersionData.Where(p => p.Id == moduleData.RootId).FirstOrDefault();
                                    var productRecord = groupData.ProductData.Where(p => p.Id == versionRecord.RootId).FirstOrDefault();
                                    ModuleModel module = new ModuleModel
                                    {
                                        ModuleName = moduleData.Name,
                                        Description = moduleData.Description,
                                        VersionId = moduleData.ParentId > 0 ? moduleData.ParentId : versionRecord.Id,
                                        Members = moduleData.Members,
                                        ProductId = productRecord.ParentId
                                    };
                                    /* DMG213 mod START Modification for send mail */
                                    data = new MailGroupDataModel
                                    {
                                        ProductName = productRecord.Name,
                                        VersionName = versionRecord.Name,
                                        ModuleName = module.ModuleName
                                    };
                                    if (moduleData.IsNew)
                                    {
                                        users = module.Members.Select(p => p.Id.ToString()).ToList();
                                        status = manager.AddModule(module, token);
                                        if (status.status)
                                        {
                                            ExtractMailGroup(module.Id, ref mailList, data, users, 1);
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.CreateWizardModuleAdd.Replace("{{0}}", moduleData.Name), user);
                                            foreach (var document in groupData.DocumentData.Where(p => p.RootId == moduleData.Id))
                                            {
                                                document.ParentId = status.id;
                                            }
                                        }
                                        else
                                        {
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.CreateWizardModuleError.Replace("{{0}}", moduleData.Name), user);
                                        }
                                    }
                                    else if (moduleData.IsModified)
                                    {
                                        module.Id = moduleData.Id;
                                        status = UpdateF2TFolder(module.Id, productRecord.Name, versionRecord.Name, module.ModuleName, 3, token);
                                        users = manager.GetMembers(module.Id);
                                        if (status.status)
                                            status = manager.UpdateModule(module, token);
                                        if (status.status)
                                        {
                                            ExtractMailGroup(module.Id, ref mailList, data, users, 2);
                                            RenameF2TDocument(module.ProductId, module.VersionId, module.Id, token);
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardModuleEdit.Replace("{{0}}", moduleData.Name), user);
                                        }
                                        else
                                        {
                                            isSuccess = status.status;
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardModuleError.Replace("{{0}}", moduleData.Name + "\"" + status.message), user);
                                            break;
                                        }
                                    }
                                    /* DMG213 mod END Modification for send mail */
                                }
                                break;
                            case 4:
                                foreach (var doc in groupData.DocumentData)
                                {
                                    var moduleRecord = groupData.ModuleData.Where(p => p.Id == doc.RootId).First();
                                    var versionRecord = groupData.VersionData.Where(p => p.Id == moduleRecord.RootId).First();
                                    var productRecord = groupData.ProductData.Where(p => p.Id == versionRecord.RootId).First();
                                    if (doc.IsNew)
                                    {
                                        status = CreateDocument(productRecord.Name, versionRecord.Name, moduleRecord.Name, doc, user);
                                        if (status.status)
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.CreateWizardDocAdd.Replace("{{0}}", System.IO.Path.GetFileName(doc.Name)), user);
                                        else
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.CreateWizardDocError.Replace("{{0}}", System.IO.Path.GetFileName(doc.Name)), user);
                                    }
                                    else if (doc.IsModified)
                                    {
                                        foreach (string key in Request.Files)
                                        {
                                            string[] keySpliter = key.Split('*');
                                            if (keySpliter.Count() > 1 && keySpliter[0] == doc.RootId.ToString() && keySpliter[1] == doc.Name)
                                            {
                                                HttpPostedFileBase file = Request.Files[key];
                                                status = manager.ReplaceDocument(productRecord.Name, versionRecord.Name, moduleRecord.Name, moduleRecord.Id, String.Empty, file);
                                                if (status.status)
                                                    DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardDocEdit.Replace("{{0}}", doc.Name), user);
                                                else
                                                    DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardDocError.Replace("{{0}}", doc.Name), user);
                                                break;
                                            }
                                        }
                                    }
                                }
                                break;
                        }
                        loop++;
                    }
                    /* DMG213 mod START Modification for send mail */
                    SendGroupMail(mailList);
                    /* DMG213 mod END Modification for send mail */
                    /* EL5873 mod END Modification for build settings */
                    TMFLogger.LogMethodExit();
                }
                catch (Exception ex)
                {
                    DisplayStatus(":ProductCreateWizard:" + Resources.Resource.CreateWizardException + " " + ex.Message, user);
                    TMFLogger.LogException(ex);
                }
            });
        }

        /// <summary>
        /// Method to extract mail datas
        /// </summary>
        /// <param name="id">product Id</param
        /// <param name="mailList">email list</param>
        /// <param name="inputData">input product details</param>
        /// <param name="userIds">member ids</param>
        /// <param name="mode">mode</param>
        /// 2021/02/23, Vinoth N, DMG213_Initial Version
        private void ExtractMailGroup(int id, ref List<MailGroupModel> mailList, MailGroupDataModel inputData, List<string> userIds, int mode)
        {
            List<string> required = new List<string>();
            List<MailGroupDataModel> datas = new List<MailGroupDataModel>();
            try
            {
                switch (mode)
                {
                    case 1:
                        required = userIds;
                        break;
                    case 2:
                        IProductManager manager = new ProductManager();
                        var users = manager.GetMembers(id);
                        required = users.Except(userIds).ToList();
                        break;
                }
                foreach (string usr in required)
                {
                    var dataList = mailList.Where(p => p.UserId == usr).FirstOrDefault();
                    if (dataList != null)
                    {
                        datas = dataList.ProductData;
                        datas.Add(inputData);
                        dataList.ProductData = datas;
                    }
                    else
                    {
                        datas = new List<MailGroupDataModel>();
                        MailGroupModel model = new MailGroupModel { UserId = usr };
                        datas.Add(inputData);
                        model.ProductData = datas;
                        mailList.Add(model);
                    }
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
            }
        }

        /// <summary>
        /// Method to send mail
        /// </summary>
        /// <param name="mailList">file path</param
        /// 2021/02/23, Vinoth N, DMG213_Initial Version
        private void SendGroupMail(List<MailGroupModel> mailList)
        {
            IProductManager manager = new ProductManager();
            foreach (var mail in mailList)
            {
                manager.SendGroupNotification(mail);
            }
        }

        /// <summary>
        /// Method to update product wizard
        /// </summary>
        /// <param name="groupData">product group details</param>
        /// <param name="typeId">unique id of the creation type</param>
        /// <param name="user">login username</param>
        /// <param name="token">user token</param>
        /// <param name="deleteItems">group of items</param>
        /// <param name="currentCulture">name of culture</param>
        /// <returns>Returns</returns>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        /// 2021/06/11, Vinoth N, EL5873_Modification for build settings
        private async Task<GeneralResultModel> UpdateProductGroup(ProductGroupModel groupData, int typeId, string user, string token, string deleteItems, CultureInfo currentCulture)
        {
            TMFLogger.LogMethodEntry();
            GeneralResultModel result = new GeneralResultModel { status = true };
            await Task.Run(() =>
            {
                SetCulture(currentCulture);
                int i = 0;
                try
                {
                    /* EL5873 mod START Modification for build settings */
                    IProductManager manager = new ProductManager();
                    bool isSuccess = true;
                    foreach (var productData in groupData.ProductData.Where(p => p.IsModified == true))
                    {
                        i++;
                        ProductModel product = new ProductModel
                        {
                            Id = productData.Id,
                            ProductName = productData.Name,
                            Members = productData.Members,
                            Description = productData.Description
                        };
                        result = UpdateF2TFolder(product.Id, product.ProductName, String.Empty, String.Empty, 1, token);
                        if (result.status)
                            result = manager.UpdateProduct(product, token);
                        if (result.status)
                            RenameF2TDocument(product.Id, 0, 0, token);
                        if (result.status)
                            ProgressHub.SendMessage(":ProductCreateWizard: " + Resources.Resource.EditWizardProductEdit.Replace("{{0}}", productData.Name), user);
                        else
                        {
                            isSuccess = result.status;
                            ProgressHub.SendMessage(":ProductCreateWizard: " + Resources.Resource.EditWizardProductError.Replace("{{0}}", productData.Name + "\"" + result.message), user);
                        }
                    }
                    if (isSuccess)
                    {
                        foreach (var versionData in groupData.VersionData.Where(p => p.IsModified == true))
                        {
                            i++;
                            VersionModel version = new VersionModel
                            {
                                Id = versionData.Id,
                                VersionName = versionData.Name,
                                Description = versionData.Description,
                                ProductId = versionData.ParentId,
                                Members = versionData.Members
                            };
                            var parent = groupData.ProductData.Where(p => p.Id == versionData.RootId).FirstOrDefault();
                            result = UpdateF2TFolder(version.Id, parent.Name, version.VersionName, String.Empty, 2, token);
                            if (result.status)
                                result = manager.UpdateVersion(version, token);
                            if (result.status)
                                RenameF2TDocument(version.ProductId, version.Id, 0, token);
                            if (result.status)
                                ProgressHub.SendMessage(":ProductCreateWizard: " + Resources.Resource.EditWizardVersionEdit.Replace("{{0}}", versionData.Name), user);
                            else
                            {
                                isSuccess = result.status;
                                ProgressHub.SendMessage(":ProductCreateWizard: " + Resources.Resource.EditWizardVersionError.Replace("{{0}}", versionData.Name + "\"" + result.message), user);
                                break;
                            }
                        }
                    }
                    if (isSuccess)
                    {
                        foreach (var moduleData in groupData.ModuleData.Where(p => p.IsModified == true))
                        {
                            i++;
                            var versionRecord = groupData.VersionData.Where(p => p.Id == moduleData.RootId).FirstOrDefault();
                            var productRecord = groupData.ProductData.Where(p => p.Id == versionRecord.RootId).FirstOrDefault();
                            ModuleModel module = new ModuleModel
                            {
                                Id = moduleData.Id,
                                ModuleName = moduleData.Name,
                                Description = moduleData.Description,
                                VersionId = moduleData.ParentId,
                                Members = moduleData.Members,
                                ProductId = productRecord.ParentId
                            };
                            result = UpdateF2TFolder(module.Id, productRecord.Name, versionRecord.Name, module.ModuleName, 3, token);
                            if (result.status)
                                result = manager.UpdateModule(module, token);
                            if (result.status)
                                RenameF2TDocument(module.ProductId, module.VersionId, module.Id, token);
                            if (result.status)
                                ProgressHub.SendMessage(":ProductCreateWizard: " + Resources.Resource.EditWizardModuleEdit.Replace("{{0}}", moduleData.Name), user);
                            else
                            {
                                isSuccess = result.status;
                                ProgressHub.SendMessage(":ProductCreateWizard: " + Resources.Resource.EditWizardModuleError.Replace("{{0}}", moduleData.Name + "\"" + result.message), user);
                                break;
                            }
                        }
                    }
                    if (isSuccess)
                    {
                        foreach (var doc in groupData.DocumentData.Where(p => p.IsModified == true))
                        {
                            i++;
                            var moduleRecord = groupData.ModuleData.Where(p => p.Id == doc.RootId).FirstOrDefault();
                            var versionRecord = groupData.VersionData.Where(p => p.Id == moduleRecord.RootId).FirstOrDefault();
                            var productRecord = groupData.ProductData.Where(p => p.Id == versionRecord.RootId).FirstOrDefault();
                            foreach (string key in Request.Files)
                            {
                                string[] keySpliter = key.Split('*');
                                if (keySpliter.Count() > 1 && keySpliter[0] == doc.RootId.ToString() && keySpliter[1] == doc.Name)
                                {
                                    HttpPostedFileBase file = Request.Files[key];
                                    result = manager.ReplaceDocument(productRecord.Name, versionRecord.Name, moduleRecord.Name, moduleRecord.Id, String.Empty, file);
                                    if (result.status)
                                        ProgressHub.SendMessage(":ProductCreateWizard: " + Resources.Resource.EditWizardDocEdit.Replace("{{0}}", doc.Name), user);
                                    else
                                        ProgressHub.SendMessage(":ProductCreateWizard: " + Resources.Resource.EditWizardDocError.Replace("{{0}}", doc.Name), user);
                                    break;
                                }
                            }
                        }
                    }
                    if (i == 0 && deleteItems.Trim('.').Trim().Length == 0)
                    {
                        ProgressHub.SendMessage(":ProductCreateWizard:" + Resources.Resource.NothingToModify, user);
                    }
                }
                catch (Exception ex)
                {
                    ProgressHub.SendMessage(":ProductCreateWizard:" + Resources.Resource.EditWizardException + " " + ex.Message, user);
                    TMFLogger.LogException(ex);
                }
            });
            /* EL5873 mod END Modification for build settings */
            TMFLogger.LogMethodExit();
            return result;
        }

        /// <summary>
        /// Method to delete product wizard
        /// </summary>
        /// <param name="removeData">product group details</param>
        /// <param name="token">unique id of the creation type</param>
        /// <param name="user">login username</param>
        /// <param name="currentCulture">culture value</param>
        /// <returns>Returns</returns>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        private async Task<GeneralResultModel> DeleteProductGroup(string removeData, string token, string user, CultureInfo currentCulture)
        {
            TMFLogger.LogMethodEntry();
            GeneralResultModel result = new GeneralResultModel { status = true };
            if (!String.IsNullOrEmpty(removeData))
            {
                await Task.Run(() =>
                {
                    SetCulture(currentCulture);
                    int i = 0;
                    try
                    {
                        IProductManager manager = new ProductManager();
                        bool isSuccess = true;
                        string[] groupData = removeData.Split('.');
                        foreach (var group in groupData)
                        {
                            foreach (var id in group.Split(',').Where(p => p != String.Empty))
                            {
                                switch (i)
                                {
                                    case 0:
                                        result = manager.DeleteProduct(Convert.ToInt32(id), token);
                                        if (result.status)
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardProductDel.Replace("{{0}}", result.operation), user);
                                        else
                                        {
                                            isSuccess = result.status;
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardProductDelErr.Replace("{{0}}", result.operation), user);
                                        }
                                        break;
                                    case 1:
                                        result = manager.DeleteVersion(Convert.ToInt32(id), token);
                                        if (result.status)
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardVersionDel.Replace("{{0}}", result.operation), user);
                                        else
                                        {
                                            isSuccess = result.status;
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardVersionDelErr.Replace("{{0}}", result.operation + "\"" + result.message), user);
                                        }
                                        break;
                                    case 2:
                                        result = manager.DeleteModule(Convert.ToInt32(id), token, false);
                                        if (result.status)
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardModuleDel.Replace("{{0}}", result.operation), user);
                                        else
                                        {
                                            isSuccess = result.status;
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardModuleDelErr.Replace("{{0}}", result.operation + "\"" + result.message), user);
                                        }
                                        break;
                                    case 3:
                                        result = manager.RemoveDocument(Convert.ToInt32(id), token, false);
                                        if (result.status)
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardDocDel.Replace("{{0}}", result.operation), user);
                                        else
                                        {
                                            isSuccess = result.status;
                                            DisplayStatus(":ProductCreateWizard: " + Resources.Resource.EditWizardDocDelErr.Replace("{{0}}", result.operation + "\"" + result.message), user);
                                        }
                                        break;
                                }
                            }
                            i++;
                        }
                    }
                    catch (Exception ex)
                    {
                        DisplayStatus(":ProductCreateWizard:" + Resources.Resource.EditWizardException + " " + ex.Message, user);
                        TMFLogger.LogException(ex);
                    }
                });
            }
            DisplayStatus(":ProductCreateWizard:" + "Wizard Processing completed.", user);
            TMFLogger.LogMethodExit();
            return result;
        }

        /// <summary>
        /// method to print completion status
        /// </summary>
        /// <param name="contant">message</param>
        /// <param name="user">user name</param>
        /// 2020/10/29, Vinoth N, CRC207_Initial version
        private async void DisplayStatus(string contant, string user)
        {
            await ProgressHub.SendMessage(contant, user);
        }

        /// <summary>
        /// Method to add document
        /// </summary>
        /// <param name="productName">product nmae</param>
        /// <param name="versionName">version nem</param>
        /// <param name="moduleName">module name</param>
        /// <param name="document">document details</param>
        /// <param name="user">user name</param>
        /// <returns>Returns</returns>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        private GeneralResultModel CreateDocument(string productName, string versionName, string moduleName, DocumentDataModel document, string user)
        {
            GeneralResultModel result = new GeneralResultModel();
            IProductManager manager = new ProductManager();
            HttpCookie cookie = this.ControllerContext.HttpContext.Request.Cookies[Constants.AUTOLOGIN_COOKIE];
            string token = cookie.Value;
            var dirPath = ConfigurationManager.AppSettings["F2TDocPath"].ToString();
            if (!Directory.Exists(Path.Combine(dirPath, productName)))
            {
                Directory.CreateDirectory(Path.Combine(dirPath, productName));
            }
            if (!Directory.Exists(Path.Combine(dirPath, productName, versionName)))
            {
                Directory.CreateDirectory(Path.Combine(dirPath, productName, versionName));
            }
            if (!Directory.Exists(Path.Combine(dirPath, productName, versionName, moduleName)))
            {
                Directory.CreateDirectory(Path.Combine(dirPath, productName, versionName, moduleName));
            }
            if (document.IsPath)
            {
                var destFile = System.IO.Path.Combine(Path.Combine(dirPath, productName, versionName, moduleName), document.Name);
                System.IO.File.Copy(document.Contant, destFile, true);
                result = manager.MapDocument(document.ParentId > 0 ? document.ParentId : document.RootId, document.Contant, token);
            }
            else
            {
                foreach (string key in Request.Files)
                {
                    string[] keySpliter = key.Split('*');
                    if (keySpliter.Count() > 1)
                    {
                        if (keySpliter[0] == document.RootId.ToString() && keySpliter[1] == document.Name)
                        {
                            HttpPostedFileBase file = Request.Files[key];
                            var fileName = file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1);
                            string documentPath = Path.Combine(dirPath, productName, versionName, moduleName, fileName);
                            if (!string.IsNullOrEmpty(documentPath))
                            {
                                result = manager.MapDocument(document.ParentId > 0 ? document.ParentId : document.RootId, documentPath, token);
                            }
                            if (result.status && file != null)
                            {
                                file.SaveAs(documentPath);
                            }
                            break;
                        }
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Method to update F2T folder
        /// </summary>
        /// <param name="Id">id</param>
        /// <param name="productName">product Name</param>
        /// <param name="versionName">version Name</param>
        /// <param name="moduleName">module Name</param>
        /// <param name="typeId">type</param>
        /// <param name="token">token</param>
        /// <returns>status</returns>
        private GeneralResultModel UpdateF2TFolder(int Id, string productName, string versionName, string moduleName, int typeId, string token)
        {
            GeneralResultModel result = new GeneralResultModel { status = true };
            IProductManager manager = new ProductManager();
            switch (typeId)
            {
                case 1:
                    var project = manager.GetProductDetails(Id, token);
                    if (productName != project.ProductName)
                    {
                        var dirPath = ConfigurationManager.AppSettings["F2TDocPath"].ToString();
                        var documentPath = Path.Combine(dirPath, project.ProductName);
                        try
                        {
                            if (Directory.Exists(documentPath))
                            {
                                if (!RenameFolder(documentPath, productName))
                                {
                                    result.status = false;
                                    result.message = "The action cannot be completed because some F2T documents are open in another process.";
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            TMFLogger.LogException(ex);
                            result.status = false;
                            result.message = "The action cannot be completed.";
                        }
                    }
                    break;
                case 2:
                    var versionData = manager.GetVersionDetails(Id, token);
                    if (versionName != versionData.VersionName)
                    {
                        var dirPath = ConfigurationManager.AppSettings["F2TDocPath"].ToString();
                        var documentPath = Path.Combine(dirPath, productName, versionData.VersionName);
                        try
                        {
                            if (Directory.Exists(documentPath))
                            {
                                if (!RenameFolder(documentPath, versionName))
                                {
                                    result.status = false;
                                    result.message = "The action cannot be completed because some F2T documents are open in another process.";
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            TMFLogger.LogException(ex);
                            result.status = false;
                            result.message = "The action cannot be completed.";
                        }
                    }
                    break;

                case 3:
                    var moduleData = manager.GetModuleDetails(Id, token);
                    if (moduleName != moduleData.ModuleName)
                    {
                        var dirPath = ConfigurationManager.AppSettings["F2TDocPath"].ToString();
                        var documentPath = Path.Combine(dirPath, productName, versionName, moduleData.ModuleName);
                        try
                        {
                            if (Directory.Exists(documentPath))
                            {
                                if (!RenameFolder(documentPath, moduleName))
                                {
                                    result.status = false;
                                    result.message = "The action cannot be completed because some F2T documents are open in another process.";
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            TMFLogger.LogException(ex);
                            result.status = false;
                            result.message = "The action cannot be completed.";
                        }
                    }
                    break;
            }
            return result;
        }

        /// <summary>
        /// Method to update document to module
        /// </summary>
        /// <param name="productId">product name</param>
        /// <param name="versionId">version name</param>
        /// <param name="moduleId">module name</param>
        /// <param name="token">token</param>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        private void RenameF2TDocument(int productId, int versionId, int moduleId, string token)
        {
            IProductManager manager = new ProductManager();
            if (productId > 0)
            {
                var product = manager.GetProductDetails(productId, token);
                var customVersion = product.Versions.ToList();
                if (versionId > 0)
                    customVersion = customVersion.Where(p => p.Id == versionId).ToList();
                foreach (var version in customVersion)
                {
                    var customModule = version.Modules.ToList();
                    if (moduleId > 0)
                        customModule = customModule.Where(p => p.Id == moduleId).ToList();
                    foreach (var module in customModule)
                    {
                        var dirPath = ConfigurationManager.AppSettings["F2TDocPath"].ToString();
                        foreach (var doc in module.DocModels)
                        {
                            var documentPath = Path.Combine(dirPath, product.ProductName, version.VersionName, module.ModuleName, Path.GetFileName(doc.DocumentPath));
                            manager.UpdateDocument(module.Id, doc, documentPath, token);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Method to update document path
        /// </summary>
        /// <param name="path">path name</param>
        /// <param name="newFolderName">new folder name</param>
        /// <returns>Returns status</returns>
        /// 2020/05/15, Vinoth N, C51165_Initial Version
        private bool RenameFolder(string path, string newFolderName)
        {
            String newPath = Path.Combine(Path.GetDirectoryName(path), newFolderName);
            bool isSuccess = true;
            try
            {
                if (Directory.Exists(path))
                {
                    Directory.Move(path, newPath);
                }
            }
            catch (Exception ex)
            {
                TMFLogger.LogException(ex);
                isSuccess = false;
            }
            return isSuccess;
        }

        /// <summary>
        /// Method to set Current Culture
        /// </summary>
        /// <param name="currentCulture">current culture</param>
        private void SetCulture(CultureInfo currentCulture)
        {
            Thread.CurrentThread.CurrentUICulture = currentCulture;
            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(currentCulture.Name);
        }
        #endregion
    }
}
#endregion