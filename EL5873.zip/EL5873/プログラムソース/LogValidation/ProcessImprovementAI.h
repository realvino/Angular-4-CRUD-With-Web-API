//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME     =  ProcessImprovementAI.h
//  NOTES    =  Header file for ProcessImprovement AI Method
//  HISTORY  =  2021/06/14, Parvathy.M, EL5873_Initial creation
//  Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved.
//---------------------------------------------------------------------------------------------------------------------------------------
// EL5873 new START added for LogAnalyzer
<?xml version="1.0" encoding="UTF-8"?>
<ProcessImprovement version="4.0">
 <class>ProcessImprovementAI</class>
 <widget class="ProcessImprovement" name="ProcessImprovementAI">  
   <rect>
    <x>0</x>
    <y>0</y>
    <width>897</width>
    <height>582</height>
   </rect>
  </property>
  <property name="palette">
   <palette>
    <active>
     <colorrole role="WindowText">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Button">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>174</red>
        <green>220</green>
        <blue>231</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Light">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>255</red>
        <green>255</green>
        <blue>255</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Midlight">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>214</red>
        <green>237</green>
        <blue>243</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Dark">
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="AlternateBase">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>214</red>
        <green>237</green>
        <blue>243</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="ToolTipBase">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>255</red>
        <green>255</green>
        <blue>220</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="ToolTipText">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="PlaceholderText">
      <brush brushstyle="SolidPattern">
       <color alpha="128">
        <red>0</red>
        <green>0</green>
		<brush brushstyle="SolidPattern">
		<color alpha="255">
		 <red>0</red>
		 <green>0</green>
		 <blue>0</blue>
		 </color>
		 </brush>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
    </active>
    <inactive>
     <colorrole role="WindowText">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
	 <x>0</x>
    <y>0</y>
    <width>897</width>
    <height>582</height>
     <colorrole role="Button">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>174</red>
        <green>220</green>
        <blue>231</blue>
       </color>
      </brush>
     </colorrole>
     
       </color>
      </brush>
     </colorrole>
     <colorrole role="Text">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="BrightText">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>255</red>
        <green>255</green>
        <blue>255</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="ButtonText">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Base">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>255</red>
        <green>255</green>
        <blue>255</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Window">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>174</red>
        <green>220</green>
        <blue>231</blue>
       </color>
      </brush>
     </colorrole>
	 <x>0</x>
    <y>0</y>
    <width>897</width>
    <height>582</height>
     <colorrole role="Shadow">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="AlternateBase">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>214</red>
        <green>237</green>
        <blue>243</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="ToolTipBase">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>255</red>
        <green>255</green>
        <blue>220</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="ToolTipText">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="PlaceholderText">
      <brush brushstyle="SolidPattern">
       <color alpha="128">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
    </inactive>
    <disabled>
     <colorrole role="WindowText">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>87</red>
        <green>110</green>
        <blue>115</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Button">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>174</red>
        <green>220</green>
        <blue>231</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Light">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>255</red>
        <green>255</green>
        <blue>255</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Midlight">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>214</red>
        <green>237</green>
        <blue>243</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Dark">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>87</red>
        <green>110</green>
        <blue>115</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Mid">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>116</red>
        <green>147</green>
        <blue>154</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Text">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>87</red>
        <green>110</green>
        <blue>115</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="BrightText">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>255</red>
        <green>255</green>
        <blue>255</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="ButtonText">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>87</red>
        <green>110</green>
        <blue>115</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Base">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>174</red>
        <green>220</green>
        <blue>231</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Window">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>174</red>
        <green>220</green>
        <blue>231</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="Shadow">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="AlternateBase">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>174</red>
        <green>220</green>
        <blue>231</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="ToolTipBase">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>255</red>
        <green>255</green>
        <blue>220</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="ToolTipText">
      <brush brushstyle="SolidPattern">
       <color alpha="255">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
     <colorrole role="PlaceholderText">
      <brush brushstyle="SolidPattern">
       <color alpha="128">
        <red>0</red>
        <green>0</green>
        <blue>0</blue>
       </color>
      </brush>
     </colorrole>
    </disabled>
   </palette>
  </property>
  <property name="windowTitle">
   <string>Dialog</string>
  </property>
  <layout class="QVBoxLayout" name="verticalLayout_3">
   <item>
    <layout class="QVBoxLayout" name="verticalLayout_2">
     <item>
      <widget class="QGroupBox" name="RuleSelectionGroupBox">
       <property name="font">
        <font>
         <pointsize>-1</pointsize>
        </font>
       </property>
       <property name="styleSheet">
        <string notr="true">QGroupBox {
 
    border: 1px solid grey; 
    margin-top: 6px;
    font-size: 12px;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 4px;
    padding: 0px 5px 0px 5px;
}</string>
       </property>
       <property name="title">
        <string>Rule Selection</string>
       </property>
       <layout class="QGridLayout" name="gridLayout_2">
        <item row="0" column="0">
         <widget class="QTreeWidget" name="UnitTree">
          <column>
           <property name="text">
            <string notr="true">1</string>
           </property>
          </column>
         </widget>
        </item>
       </layout>
      </widget>
     </item>
     <item>
      <layout class="QVBoxLayout" name="verticalLayout">
       <item>
        <widget class="QGroupBox" name="ValidatedResultGroupBox">
         <property name="font">
          <font>
           <pointsize>-1</pointsize>
          </font>
         </property>
         <property name="styleSheet">
          <string notr="true">QGroupBox {
 
    border: 1px solid grey; 
    margin-top: 6px;
    font-size: 12px;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 4px;
    padding: 0px 5px 0px 5px;
}</string>
         </property>
         <property name="title">
          <string>Validated Result</string>
         </property>
         <layout class="QGridLayout" name="gridLayout">
          <item row="0" column="0">
           <layout class="QHBoxLayout" name="horizontalLayout">
            <item>
             <widget class="QLabel" name="OutputFileLabel">
              <property name="font">
               <font>
                <pointsize>10</pointsize>
               </font>
              </property>
              <property name="text">
               <string>Output File</string>
              </property>
             </widget>
            </item>
            <item>
             <widget class="QLineEdit" name="OutputFilelineEdit"/>
            </item>
            <item>
             <widget class="QPushButton" name="BrowseBtn">
              <property name="palette">
               <palette>
                <active>
                 <colorrole role="WindowText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Button">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>174</red>
                    <green>220</green>
                    <blue>231</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Light">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>255</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Midlight">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>214</red>
                    <green>237</green>
                    <blue>243</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Dark">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>87</red>
                    <green>110</green>
                    <blue>115</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Mid">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>116</red>
                    <green>147</green>
                    <blue>154</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Text">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="BrightText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>255</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="ButtonText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Base">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>255</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Window">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>174</red>
                    <green>220</green>
                    <blue>231</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Shadow">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="AlternateBase">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>214</red>
                    <green>237</green>
                    <blue>243</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="ToolTipBase">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>220</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="ToolTipText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="PlaceholderText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="128">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                </active>
                <inactive>
                 <colorrole role="WindowText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Button">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>174</red>
                    <green>220</green>
                    <blue>231</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Light">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>255</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Midlight">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>214</red>
                    <green>237</green>
                    <blue>243</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Dark">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>87</red>
                    <green>110</green>
                    <blue>115</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Mid">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>116</red>
                    <green>147</green>
                    <blue>154</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Text">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="BrightText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>255</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="ButtonText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Base">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>255</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Window">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>174</red>
                    <green>220</green>
                    <blue>231</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Shadow">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="AlternateBase">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>214</red>
                    <green>237</green>
                    <blue>243</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="ToolTipBase">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>220</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="ToolTipText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="PlaceholderText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="128">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                </inactive>
                <disabled>
                 <colorrole role="WindowText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>87</red>
                    <green>110</green>
                    <blue>115</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Button">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>174</red>
                    <green>220</green>
                    <blue>231</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Light">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>255</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Midlight">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>214</red>
                    <green>237</green>
                    <blue>243</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Dark">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>87</red>
                    <green>110</green>
                    <blue>115</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Mid">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>116</red>
                    <green>147</green>
                    <blue>154</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Text">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>87</red>
                    <green>110</green>
                    <blue>115</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="BrightText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>255</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="ButtonText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>87</red>
                    <green>110</green>
                    <blue>115</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Base">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>174</red>
                    <green>220</green>
                    <blue>231</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Window">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>174</red>
                    <green>220</green>
                    <blue>231</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="Shadow">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="AlternateBase">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>174</red>
                    <green>220</green>
                    <blue>231</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="ToolTipBase">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>255</red>
                    <green>255</green>
                    <blue>220</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="ToolTipText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="255">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                 <colorrole role="PlaceholderText">
                  <brush brushstyle="SolidPattern">
                   <color alpha="128">
                    <red>0</red>
                    <green>0</green>
                    <blue>0</blue>
                   </color>
                  </brush>
                 </colorrole>
                </disabled>
               </palette>
              </property>
              <property name="font">
               <font>
                <pointsize>10</pointsize>
               </font>
              </property>
              <property name="text">
               <string>Browse...</string>
              </property>
              <property name="shortcut">
               <string>Ctrl+D</string>
              </property>
             </widget>
            </item>
           </layout>
          </item>
         </layout>
        </widget>
       </item>
       <item>
        <layout class="QHBoxLayout" name="horizontalLayout_2">
         <item>
          <spacer name="horizontalSpacer">
           <property name="orientation">
            <enum>Qt::Horizontal</enum>
           </property>
           <property name="sizeHint" stdset="0">
            <size>
             <width>198</width>
             <height>20</height>
            </size>
           </property>
          </spacer>
         </item>
         <item>
          <widget class="QPushButton" name="ClearAllBtn">
           <property name="palette">
            <palette>
             <active>
              <colorrole role="WindowText">
               <brush brushstyle="SolidPattern">
                <color alpha="255">
                 <red>0</red>
                 <green>0</green>
                 <blue>0</blue>
                </color>
               </brush>
              </colorrole>
              <colorrole role="Button">
               <brush brushstyle="SolidPattern">
                <color alpha="255">
                 <red>174</red>
                 <green>220</green>
                 <blue>231</blue>
                </color>
               </brush>
              </colorrole>
              <colorrole role="Light">
               <brush brushstyle="SolidPattern">
                <color alpha="255">
                 <red>255</red>
                 <green>255</green>
                 <blue>255</blue>
                </color>
               </brush>
              </colorrole>
              <colorrole role="Midlight">
               <brush brushstyle="SolidPattern">
                <color alpha="255">
                 <red>214</red>
                 <green>237</green>
                 <blue>243</blue>
                </color>
               </brush>
              </colorrole>
              <colorrole role="Dark">
               <brush brushstyle="SolidPattern">
                <color alpha="255">
                 <red>87</red>
                 <green>110</green>
                 <blue>115</blue>
                </color>
               </brush>
              </colorrole>
              <colorrole role="Mid">
               <brush brushstyle="SolidPattern">
                <color alpha="255">
                 <red>116</red>
                 <green>147</green>
                 <blue>154</blue>
                </color>
               </brush>
              </colorrole>
              <colorrole role="Text">
               <brush brushstyle="SolidPattern">
                <color alpha="255">
                 <red>0</red>
                 <green>0</green>
                 <blue>0</blue>
                </color>
               </brush>
              </colorrole>
              <colorrole role="BrightText">
               <brush brushstyle="SolidPattern">
                <color alpha="255">
                 <red>255</red>
                 <green>255</green>
                 <blue>255</blue>
                </color>
               </brush>
              </colorrole>
 </ProcessImprovement>
// EL5873 new END for LogAnalyzer
