#########################################################################################################################################
#  NAME     =  CommandSequenceAIValidation.py
#  NOTES    =  Implementation file of Command Sequence Validation with AI
#  HISTORY  =  2021/06/22, Gina Mathew, EL5873_Initial creation
#  Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved. 
#########################################################################################################################################
# EL5873 new START added for LogAnalyzer
import os
import re
import pandas as pd 

class Logparser:
    def __init__(self, log_format, out_dir=''):
        self.log_format = log_format
        self.out_dir = out_dir
        self.regex, self.headers = self.get_regex()

    def get_regex(self):
        headers = []; regex = ''
        splitters = re.split(r'(<[^<>]+>)', self.log_format)
        for k in range(len(splitters)):            
            if k % 2 == 0:
                splitter = re.sub(' +', '\\\s', splitters[k])
                regex += splitter
            else:
                header = splitters[k].strip('<').strip('>')
                regex += '(?P<%s>.*?)' % header
                headers.append(header)
        regex = re.compile('^' + regex + '$')
        return regex, headers
    def keyparams_splitter(slef, content):
        key_params = content.split(',')    
        print('keyparams', key_params)
        parameter = ','.join(key_params[1:]) if len(key_params) > 1 else ' '
        if parameter is ' ':
            key = ' '.join(key_params[0].split())
        else:
            space_split = key_params[0].split()
            key = ' '.join(space_split[:-1])
            sub_key = re.search('(.*:)', space_split[-1])
            sub_parms = None
            if sub_key:
                sub_parms = re.sub(sub_key.group(1), '', space_split[-1])   
            print('subkey', sub_key)
            sub_split = False
            print('fsdf', (sub_key, sub_parms))
            if sub_key and sub_parms:
                if len(sub_key.group(1)) > 1 and len(sub_parms) > 0:
                    sub_split = True
            if sub_split:
                parameter = ','.join([sub_parms, parameter])
                key = ' '.join([key, sub_key.group(1)])
            elif  re.search(r'\w', space_split[-1]):
                parameter = ','.join([space_split[-1], parameter])
            else:
                key = ' '.join([key, space_split[-1]])
        if not key[-1].isalnum():
            key = key[:-1]
        key = re.sub('^(.*):(\d+):',' '.join([key.split(':')[1][:3], key.split(':')[3], '']), key)
        return key, parameter

    def log_to_df(self, log_file):
        log_messages = []
        linecount = 0
        with open(log_file, 'r') as fin:
            for line in fin.readlines():
                print('command',line)
                tkn = [el for el in re.split('\s', line) if el not in [':',';','']]
                print('tkn',tkn)
                time_idx = [idx for idx, el in enumerate(tkn) if re.match(r'\d{2}:\d{2}:\d{2}', el)]
                if len(tkn) > 3 and time_idx :
                    content = ' '.join(tkn[time_idx[0]+1:])
                    try:
                        key, parameter = self.keyparams_splitter(content)
                        tkn[3:] = [key]
                        tokens = ' '.join(tkn)
                        match = self.regex.search(tokens)
                        message = [match.group(header) for header in self.headers]
                        print(message)
                        log_messages.append(message)
                        linecount += 1
                        print('processed {} log command'.format(linecount))
                    except:
                        print('command is skipped')
        logdf = pd.DataFrame(log_messages, columns=self.headers)
        logdf.insert(0, 'LineId', None)
        logdf['LineId'] = [i + 1 for i in range(linecount)]
        return logdf
        
    def parse(self, log_file):
        logdf = self.log_to_df(log_file)
        logdf.to_csv(os.path.join(self.out_dir, os.path.basename(log_file) + '_structured.csv'),
		index=False)
# EL5873 new END added for LogAnalyzer


#########################################################################################################################################
#  NAME        =  main
#  FUNCTION    =  Main entry function for AI validation
#  PARAMETER   =  None
#  RETURN      =  None
#  NOTES       =  None
#  HISTORY     =  2021/06/22, Gina Mathew, EL5873_Initial creation
#  Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved. 
#########################################################################################################################################
# EL5873 new START added for LogAnalyzer
def main():
    log_dir = '/mnt/EEC806B3C8067A5B/LogAnalyzer/Logs'
    
    for logName in os.listdir(log_dir):
        print(logName)
        log_file = os.path.join(log_dir, logName)
        logformat = '<Serial> <Date> <Time> <Template>'
        log_parser = Logparser(log_format=logformat, out_dir='/mnt/EEC806B3C8067A5B/LogAnalyzer/Files')
        log_parser.parse(log_file)

if __name__ == "__main__":
    main()
# EL5873 new END added for LogAnalyzer


