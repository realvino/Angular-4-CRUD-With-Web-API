#########################################################################################################################################
#  NAME     =  LogAnalyzerValidationMain.py
#  NOTES    =  Implementation file of Validation Main class
#  HISTORY  =  2021/06/22, Gina Mathew, EL5873_Initial creation
#  Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved. 
#########################################################################################################################################
# EL5873 new START added for AI Validation
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from keras.models import Sequential
from keras.layers import LSTM
from keras.layers import Bidirectional
from keras.layers import Dense
from keras.models import load_model
from keras.preprocessing.sequence import TimeseriesGenerator
import pickle
import os
import glob

test_dir = 'Test'
out_dir = 'Result/3FileResults'
window = 5

pkl_file = open(os.path.join(out_dir, 'le.pkl'), 'rb')
le_ = pickle.load(pkl_file) 
pkl_file.close()

pkl_file = open(os.path.join(out_dir,'one_hot_encoder.pkl'), 'rb')
one_hot_encoder_ = pickle.load(pkl_file) 
pkl_file.close()
# EL5873 new END added for AI Validation


#########################################################################################################################################
#  NAME        =  GetEncoderOutput
#  FUNCTION    =  Main entry function for log validation
#  PARAMETER   =  [IN] inp : input data
#  RETURN      =  [OUT] out
#  NOTES       =  None
#  HISTORY     =  2021/06/22, Gina Mathew, EL5873_Initial creation
#  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved. 
#########################################################################################################################################
# EL5873 new START added for AI Validation
def GetEncoderOutput(inp):
    try:
        out = one_hot_encoder_.transform(inp)

    except:
        out = np.zeros((1,len(le_.classes_)-1))
    return out
# EL5873 new END added for AI Validation


#########################################################################################################################################
#  NAME        =  GetResult
#  FUNCTION    =  To get result
#  PARAMETER   =  [IN] test_log : input log
#  RETURN      =  None
#  NOTES       =  None
#  HISTORY     =  2021/06/22, Gina Mathew, EL5873_Initial creation
#  Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved. 
#########################################################################################################################################
# EL5873 new START added for AI Validation
def GetResult(test_log):
    test_log['Template'] = test_log['Template'].map(lambda s: '<unknown>' if s not in le_.classes_ else s)
    le_.classes_ = np.append(le_.classes_, '<unknown>')
    test_log['Template_enc'] = le_.transform(test_log['Template'])
    test_log['Template_onehot'] = test_log.apply (lambda row: GetEncoderOutput([[row['Template_enc']]]), axis=1)
    test_log['Template_onehot'] = test_log.apply (lambda row: one_D(row['Template_onehot']), axis=1)
    test_data= np.squeeze(np.array([test_log['Template_onehot']])).astype(np.float32)
    X_test, y_test = SplitLogSequence(test_data, window)
    model = load_model(os.path.join(out_dir, 'lstm_model_all_command.h5'))
    yhat = model.predict(X_test, verbose=1)
    predicted = []; orginal = []; errorl = []
    padd = test_log.shape[0] - len(yhat)

    for i in range(padd):
        orginal.append('None')
        predicted.append('None')
        errorl.append('None')
    err = 0
    correct = 0
    for i in range(len(yhat)):

        yhat_le = np.argmax(yhat[i])
        pred = le_.inverse_transform([[yhat_le]])[0]
        predicted.append(pred)
        y_test_le = np.argmax(y_test[i])
        actual = le_.inverse_transform([[y_test_le]])[0]
        orginal.append(actual)
        error = y_test_le - yhat_le
        err += abs(error)
        if error ==0:
            correct += 1
            errorl.append('Correct')
        else:
            errorl.append('Wrong')
    print(len(yhat))
    print('correct predicction', correct)
    test_log['Actual'] = orginal
    test_log['Prediction'] = predicted
    test_log['TruePrediction'] = errorl
    test_log = test_log.drop(columns=['Template_onehot','Template_enc'])
    test_log = test_log.drop(columns=['Actual'])
    test_log.to_csv(out_dir+'/'+nme+'_result.csv')
# EL5873 new END added for AI Validation


#########################################################################################################################################
#  NAME        =  SplitLogSequence
#  FUNCTION    =  To split sequence
#  PARAMETER   =  [IN] sequence : input sequence
#              =  [IN] n_steps : no of steps
#  RETURN      =  None
#  NOTES       =  None
#  HISTORY     =  2021/06/22, Gina Mathew, EL5873_Initial creation
#  Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved. 
#########################################################################################################################################
# EL5873 new START added for LogAnalyzer
def SplitLogSequence(sequence, n_steps):
    X, y = list(), list()
    for i in range(len(sequence)):
        end_ix = i + n_steps
        if end_ix > len(sequence)-1:
            break
        seq_x, seq_y = sequence[i:end_ix], sequence[end_ix]
        X.append(seq_x)
        y.append(seq_y)
    return np.array(X), np.array(y)
test_dir = 'Test'
out_dir = 'Result/3FileResults'
log_df = []
logName = []
nme = 'SEM_comm_toSEM SET3(SEM48БL51 to)_20201019.log_structured.csv'
test_logName = os.path.join(test_dir, nme)
print(test_logName)
logName.append(test_logName)
test_log = pd.read_csv(test_logName)
result(test_log)
# EL5873 new END added for LogAnalyzer
