#########################################################################################################################################
#  NAME     =  ValidationEncoding.py
#  NOTES    =  Implementation file of Validation Encoding
#  HISTORY  =  2021/06/22, Gina Mathew, EL5873_Initial creation
#  Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved. 
#########################################################################################################################################
# EL5873 new START added for LogAnalyzer
########## Python code for creating encoding ###########
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
import pickle
import os
import glob
import logging
import matplotlib.pyplot as plt

train_dir =  'Train'
test_dir = 'Test'
val_dir = 'Val'
log_dir= 'Files'
out_dir  = 'Encoded'
log_df = []
for file_dir in [log_dir,test_dir]:
    for logName in os.listdir(file_dir):
        print(logName)
        log_df.append(pd.read_csv(os.path.join(file_dir, logName)))
    

print('Total number of log file',len(log_df))
train_df = pd.concat(log_df)
print('Total Number of lines in log file',len(train_df))

le = LabelEncoder()
train_df['Template_enc'] = le.fit_transform(train_df['Template'])

output = open(os.path.join(out_dir, 'le.pkl'), 'wb')
pickle.dump(le, output)
output.close()
len(train_df['Template_enc'].unique())

from sklearn.preprocessing import OneHotEncoder
one_hot_encoder = OneHotEncoder(sparse=False)

train_data = one_hot_encoder.fit_transform(train_df['Template_enc'].values.reshape(-1,1)).astype(np.float32)
output = open(os.path.join(out_dir,'one_hot_encoder.pkl'), 'wb')
pickle.dump(one_hot_encoder, output)
output.close()
# EL5873 new END added for LogAnalyzer
