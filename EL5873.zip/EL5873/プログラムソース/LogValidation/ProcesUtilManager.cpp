﻿//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME     =  ProcesUtilManager.cpp
//  NOTES    =  Implementation file of utility class for Process Improvement
//  HISTORY  =  2021/02/18, Parvathy.M, DMG213_Initial Creation for Process Improvement
//			 =  2021/06/18, Parvathy.M, EL5873_Modified for TPF Support
//  Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
#include "ProcesUtilManager.h"

//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  ProcesUtilManager
//  FUNCTION    =  Constructor
//  PARAMETER   =  None
//  RETURN      =  None
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//  Copyright (C) Hitachi High-Tech Corporation, 2021. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
ProcesUtilManager::ProcesUtilManager()
{
    m_nMicomIndex = 0;       // Start from the first element of MicomList
    m_nLevel = -1;       // Start Iteration without considering Nested commands.
    m_nVRTIndex = 0;       // Start from the top of LogList
    m_nEvacLevel = 0;       // Nested level of evac log.
    m_nStageLevel = 0;    // Nested level of stage log.
    m_strCommandName = "";
    m_strCommandNotFound = "";    
    m_nStageSystemType = SYSTEM_TYPE_UNKNOWN;
    m_nEvacSystemType = SYSTEM_TYPE_UNKNOWN;    
    nReplyRow = -1;
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  FillMapArray
//  FUNCTION    =  Function is used to fill the vector with send and receive commands
//  PARAMETER   =  [IN] strSendReceiveTxt : send receive text path
//  RETURN      =  [OUT] nRet : LG_SUCCESS if success, else return LG_ERROR
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//              =  2020/06/24, Sheikh Mohammed Subhan, EL5873_Modified TPF Support
//  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
int ProcesUtilManager::FillMapArray(QString strSendReceiveTxt)
{
    // EL5873 mod START TPF Support
    // Enum to locally track ZIPC/TPF sections when parsing sendrecv.txt
    enum
    {
        ZIPC,
        TPF,
        NONE
    };
    int nSystemType = NONE;
    // EL5873 mod END TPF Support
    int nRet = LG_SUCCESS;
    LogAnalyzerFileParser logFile;
    QStringList strStringLines;
    QString strLine;
    // if file is open then the return value will be zero
    int nReturnValue = logFile.FileOpen(strSendReceiveTxt);
    if (nReturnValue == LG_SUCCESS)
    {
        logFile.GetFileLines(strStringLines);
        if (0 != strStringLines.size())// if list size not equal to 0
        {
            int nStringListSize = strStringLines.size();
            _LogAnlyzCmdMap CmdMapTemp_t;
            QStringList strCmdList;
            for (int i = 0; i < nStringListSize; i++)
            {
                // EL5873 mod START TPF Support
                strLine = strStringLines[i].trimmed();

                // Identify and set the current parsed block to either ZIPC, TPF or NONE
                if (strLine == "# ZIPC send receive log numbers start")
                {
                    nSystemType = ZIPC;
                    continue;
                }
                else if (strLine == "# TPF send receive log numbers start")
                {
                    nSystemType = TPF;
                    continue;
                }
                else if (strLine == "# ZIPC send receive log numbers end" ||
                         strLine == "# TPF send receive log numbers end")
                {
                    nSystemType = NONE;
                    continue;
                }
                else if (strLine == "" || strLine[0] == '#')
                {
                    continue;
                }

                strCmdList = strLine.split("#")[0].trimmed().split(',');
                if (nSystemType != NONE && strCmdList.size() == 3)
                {
                    // EL5873 mod END TPF Support
                    CmdMapTemp_t.strCmdName = strCmdList[0]; // filling command name
                    CmdMapTemp_t.strSend    = strCmdList[1]; // send number
                    CmdMapTemp_t.strReceive = strCmdList[2]; // recv number
                    // EL5873 mod START TPF Support
                    switch(nSystemType)
                    {
                    case ZIPC:
                        MapArray.push_back(CmdMapTemp_t);
                        break;
                    case TPF:
                        MapArray_TPF.push_back(CmdMapTemp_t);
                        break;
                    }
                }
                // EL5873 mod END TPF Support
            }
        }
    }
    else
    {
        nRet = LG_ERROR;
    }
    return nRet;
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  FillMap
//  FUNCTION    =  Function is used to fill the send and reply commands
//  PARAMETER   =  None
//  RETURN      =  None
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//              =  2020/06/22, Akshai K.B, EL5873_Modified TPF Support
//  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
void ProcesUtilManager::FillMap()
{
    // EL5873 mod START Compiler warning removal
    quint64 nIndex = 0;
    // Iterate the array
    quint64 nSize = MapArray.size();
    // EL5873 mod END Compiler warning removal
    while (nIndex < nSize)
    {
        // Fill the values in global map
        gMicomCmdMap.insert(MapArray[nIndex].strSend, MapArray[nIndex]);
        gMapArray.insert(MapArray[nIndex].strCmdName, MapArray[nIndex]);
        gMicomSendRecvMap.insert(MapArray[nIndex].strSend, MapArray[nIndex].strReceive);
        gMicomRecvCmdMap.insert(MapArray[nIndex].strReceive, MapArray[nIndex]);
        nIndex++;
    }
    gVRTSendRecvMap["STGQ"] = "STGE";
    gVRTSendRecvMap["STGR"] = "STGT";
    gVRTSendRecvMap["STGW"] = "STGT";
    gVRTSendRecvMap["EVCQ"] = "EVCE";
    gVRTSendRecvMap["EVCR"] = "EVCT";
    gVRTSendRecvMap["EVCW"] = "EVCT";

    // EL5873 mod START TPF Support
    nSize = MapArray_TPF.size();
    nIndex = 0;
    // EL5873 mod END TPF Support
    while (nIndex < nSize)
    {
        // Fill the values in global map
        // EL5873 mod START TPF Support
        gMicomCmdMap_tpf.insert(MapArray_TPF[nIndex].strSend, MapArray_TPF[nIndex]);
        gMapArray_tpf.insert(MapArray_TPF[nIndex].strCmdName, MapArray_TPF[nIndex]);
        gMicomSendRecvMap_tpf.insert(MapArray_TPF[nIndex].strSend, MapArray_TPF[nIndex].strReceive);
        gMicomRecvCmdMap_tpf.insert(MapArray_TPF[nIndex].strReceive, MapArray_TPF[nIndex]);
        // EL5873 mod END TPF Support
        nIndex++;
    }
    // EL5873 mod START TPF Support
    gVRTSendRecvMap_tpf["STGQ"] = "STGE";
    gVRTSendRecvMap_tpf["STGR"] = "STGT";
    gVRTSendRecvMap_tpf["STGW"] = "STGT";
    gVRTSendRecvMap_tpf["EVCQ"] = "EVCE";
    gVRTSendRecvMap_tpf["EVCR"] = "EVCT";
    gVRTSendRecvMap_tpf["EVCW"] = "EVCT";
    // EL5873 mod END TPF Support
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  CalculateProcessingTime
//  FUNCTION    =  Function is used to get the processing time
//  PARAMETER   =  [IN] SendDateTime : represent the send data time
//              =  [IN] RecvDateTime : represent the receive data time
//  RETURN      =  [OUT] strPrcTime : Return processing time
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//              =  2020/07/29, Sheikh Mohammed Subhan, EL5873_Modified
//  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
QString ProcesUtilManager::CalculateProcessingTime(QDateTime SendDateTime, QDateTime RecvDateTime)
{
    qint64 millisec = SendDateTime.msecsTo(RecvDateTime); // difference of two time
    qint64 temp;
    QString strPrcTime = "";
    int nMsec = millisec%1000;
    temp = millisec/1000;
    int nSec = temp%60;
    temp = temp/60;
    int nMinute = temp%60;
    int nHour = int(temp/60); // EL5873 mod Compiler warning removal
    strPrcTime.sprintf("%02d:%02d:%02d.%03d", nHour, nMinute, nSec, nMsec);
    return strPrcTime;
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  FindSTGRWCommandReply
//  FUNCTION    =  Function is used to search R/W commands in the LogTable
//  PARAMETER   =  [IN] *pstData : Send data of Sem Log
//              =  [IN] nRowIndex : Send data index
//              =  [IN] *LogList : Represent Log List
//  RETURN      =  [OUT] nRet : LG_SUCCESS if success; else LG_ERROR
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
int ProcesUtilManager ::FindSTGRWCommandReply(LOG_ANLYZ_DATA *pstData, int nRowIndex, QList<LOG_ANLYZ_DATA> *LogList)
{
    int nRet =LG_SUCCESS;
    int nSendDataIndex = nRowIndex;
    LOG_ANLYZ_DATA stNextLogData;
    int nSize = LogList->size();
    QString strCommandkey = pstData->cmdInfo.CmdName + "/" + pstData->cmdInfo.CmdNameParam;
    _LogAnlyzCmdMap stCmdMap = gMapArray[strCommandkey];
    if (stCmdMap.strCmdName.isEmpty())
    {
        m_strCommandName = strCommandkey;
        nRet = LG_CMD_MIS;
        return nRet;
    }
    else
    {
        // iterate main list to find the reply command
        for (int i = nRowIndex; i < nSize; i++)
        {
            stNextLogData =  (*LogList)[i];
            QString deviceId = (stNextLogData.SectionId);
            if (SEC_ID_ETH == deviceId)
            {
                // finding in the reply log with same CmdNameParam,CtrlID
                if (STAGE_TTYPE == stNextLogData.cmdInfo.CmdName &&
                        pstData->cmdInfo.CmdNameParam == stNextLogData.cmdInfo.CmdNameParam &&
                        pstData->cmdInfo.CtrlID == stNextLogData.cmdInfo.CtrlID)
                {
                    // calculating the processing time
                    pstData->prcTime = CalculateProcessingTime(pstData->LogDateTime, stNextLogData.LogDateTime); // filling prctime to Logstructure
                    (*LogList)[nSendDataIndex] = *pstData;
                    break;
                }

            }
        }
    }
    return  nRet;
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  CalculateProcessingTimeForMicoms
//  FUNCTION    =  Function is used to calculate the processing time for micom logs
//  PARAMETER   =  [IN] *LogList : Represent Log List
//  RETURN      =  None
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//              =  2020/06/24, Sheikh Mohammed Subhan, EL5873_Modified TPF Support
//  Copyright (C) Hitachi High-Tech Corporation, 2020,2021. All rights reserved.
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
void ProcesUtilManager::CalculateProcessingTimeForMicoms(QList<LOG_ANLYZ_DATA> *LogList)
{
    int nIndex = 0;
    int nReplyIndex = 0;
    LOG_ANLYZ_DATA SendData;
    int nSendIndex = 0;
    LOG_ANLYZ_DATA RecvData;
    QString strKeyValue = " ";
    for (nIndex = 0; nIndex < LogList->size(); nIndex++)// iterating the complete list
    {
        SendData = (*LogList)[nIndex];
        // EL5873 mod START Unify send receive identification
        //        if(SendData.cmdInfo.TaskNo == "02")
        if (IsSendType(SendData) == LOG_TYPE_SEND && SendData.SectionId == SEC_ID_ETH_STAGE_MICOM)
            // EL5873 mod END Unify send receive identification
        {
            strKeyValue = SendData.cmdInfo.LogNo;
            nSendIndex = nIndex;
            for (nReplyIndex = nIndex + 1; nReplyIndex < LogList->size(); nReplyIndex++)
            {
                RecvData = (*LogList)[nReplyIndex];
                // EL5873 mod START Unify send receive identification
                //                if ((RecvData.cmdInfo.TaskNo == "03") &&
                if ((IsSendType(RecvData) == LOG_TYPE_RECV && RecvData.SectionId == SEC_ID_ETH_STAGE_MICOM) &&
                        // EL5873 mod END Unify send receive identification
                        (RecvData.cmdInfo.LogNo == gMicomSendRecvMap[strKeyValue]))
                {
                    SendData.prcTime = CalculateProcessingTime(SendData.LogDateTime, RecvData.LogDateTime); // filling prctime to Logstructure
                    (*LogList)[nSendIndex] = SendData;
                    gMicomSendReceiveMap.insert(nIndex,nReplyIndex); // DMG213 add for LogAnalyzer
                    break;
                }
                else
                {
                    continue;
                }
            }
        }

        // EL5873 mod START Unify send receive identification
        if (IsSendType(SendData) == LOG_TYPE_SEND && SendData.SectionId == SEC_ID_ETH_EVAC_MICOM)
            // EL5873 mod END Unify send receive identification
        {
            strKeyValue = SendData.cmdInfo.LogNo;
            nSendIndex = nIndex;
            // EL5873 mod START bug fix on Evac-micom processing time issue
            if (strKeyValue == "0161") // DMG213 mod for ITLV request type for EVAC Micom logs
            {
                bool bCheckPrcTime = false;
                for (nReplyIndex = nIndex + 1; nReplyIndex < LogList->size(); nReplyIndex++) // DMG213 mod for ITLV request type for EVAC Micom logs
                {
                    RecvData = (*LogList)[nReplyIndex];
                    if ((EVAC_QTYPE == RecvData.cmdInfo.CmdName) && (RecvData.cmdInfo.CmdNameParam == "ITLV"))
                    {
                        SendData.prcTime = "-";
                        (*LogList)[nSendIndex] = SendData;
                        bCheckPrcTime = true;
                        break;
                    }
                    else
                    {
                        if ((IsSendType(RecvData) == LOG_TYPE_RECV && RecvData.SectionId == SEC_ID_ETH_EVAC_MICOM) && (RecvData.cmdInfo.LogNo == "0133")) // DMG213 mod for ITLV request type for EVAC Micom logs
                        {
                            SendData.prcTime = CalculateProcessingTime(SendData.LogDateTime, RecvData.LogDateTime); // DMG213 mod for ITLV request type for EVAC Micom logs
                            (*LogList)[nSendIndex] = SendData;
                            bCheckPrcTime = true;
                            gMicomSendReceiveMap.insert(nIndex,nReplyIndex); // DMG213 add for LogAnalyzer
                            break;
                        }
                    }

                }
                if (false == bCheckPrcTime)
                {
                    SendData.prcTime = "-";
                    (*LogList)[nSendIndex] = SendData;
                }
            }
            // EL5873 mod END bug fix on Evac-micom processing time issue
            else
            {
                for (nReplyIndex = nIndex + 1; nReplyIndex < LogList->size(); nReplyIndex++)
                {
                    RecvData = (*LogList)[nReplyIndex];
                    // EL5873 mod START Unify send receive identification
                    QString strSendRecvLogNo = "";
                    if (m_nEvacSystemType == SYSTEM_TYPE_ZIPC)
                        strSendRecvLogNo = gMicomSendRecvMap[strKeyValue];
                    else if (m_nEvacSystemType == SYSTEM_TYPE_TPF)
                        strSendRecvLogNo = gMicomSendRecvMap_tpf[strKeyValue];
                    // EL5873 mod END Unify send receive identification
                    // EL5873 mod START Unify send receive identification
                    if ((IsSendType(RecvData) == LOG_TYPE_RECV && RecvData.SectionId == SEC_ID_ETH_EVAC_MICOM) &&
                            (RecvData.cmdInfo.LogNo == strSendRecvLogNo))
                        // EL5873 mod END Unify send receive identification
                    {
                        SendData.prcTime = CalculateProcessingTime(SendData.LogDateTime, RecvData.LogDateTime); // filling prctime to Logstructure
                        (*LogList)[nSendIndex] = SendData;
                        gMicomSendReceiveMap.insert(nIndex,nReplyIndex); // DMG213 add for LogAnalyzer
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
            }
        }
        else
        {
            continue;
        }
    }
}
// DMG213 new End added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME            =  MergeEvacMicomLogs
//  FUNCTION        =  Function used to merge Evac Micom to the main loglist
//  PARAMETER       =  [IN] evacList : Represent evacMicom Data List
//                  =  [IN] evacTempList : Represent evac Data List
//                  =  [IN] *LogList : Log data list
//  RETURN          =  [OUT] nRet : indicating merge status
//  NOTES           =  None
//  HISTORY         =  2021/02/18, Parvathy.M, DMG213_Initial creation
//                  =  2020/06/22, Akshai K.B, EL5873_Modified TPF Support
//  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
int ProcesUtilManager::MergeEvacMicomLogs(QList<LOG_ANLYZ_DATA> &evacList, QList<LOG_ANLYZ_DATA> &evacTempList, QList<LOG_ANLYZ_DATA> *LogList)
{
    int nRet = LG_SUCCESS;
    LogAnalyzerCommonErrorLogger* ErrLogger = LogAnalyzerCommonErrorLogger::GetInstance();
    LOG_ANLYZ_DATA data;
    QList<LOG_ANLYZ_DATA>tempList;
    m_nVRTIndex = 0;
    // Iterate till the evac micom list is empty
    m_nLevel = -1;
    m_nEvacLevel = m_nLevel;
    QDateTime fp1;
    QDateTime fp2;
    QDateTime fpMicom;
    bool bRet = true;
    int nCount = evacTempList.size();
    QDateTime s1;
    QDateTime s2;
    fp1 = evacTempList.at(0).LogDateTime;
    fp2 = evacTempList.at(nCount - 1).LogDateTime;
    bool bIteratonCompleted = false;
    while (!evacList.isEmpty())
    {
        bRet = true;
        data = evacList.at(m_nMicomIndex);
        SetReqCode(data);
        fpMicom = data.LogDateTime; // Get the filetime
        bRet = CompareTime(fp1, fp2, fpMicom);
        if (false == bRet)
        {
            tempList.append(data);
            evacList.removeAt(0);
            continue;
        }
        if (false == bIteratonCompleted && 0 != tempList.size())
        {
            // Add Outside time micoms above the STAGE log.
            AddStartingMicomLogs(tempList, LogList);
        }
        bIteratonCompleted = true;
        if (data.cmdInfo.LogNo == "0133" ||
                data.cmdInfo.LogNo == "0161" || data.cmdInfo.LogNo == "11050")
        {
            nRet = MergeEvacITLVLogs(m_nLevel, data, evacList, tempList, LogList);
            if (LG_DATA_MISMATCH == nRet)
            {
                // EL5873 mod START Send incorrect logs to error log
                // Before exiting the iteration loop send all unmatched logs to error log
                while (!evacList.isEmpty())
                {
                    if (evacList.at(0).LogEntry != "")
                    {
                        ErrLogger->WriteToFile(ERRLOG_LOG, "Cannot match Evac Micom Log with mainlist -> " + evacList.at(0).LogEntry);
                    }
                    evacList.removeAt(0);
                }
                // EL5873 mod END Send incorrect logs to error log
                break;
            }
        }
        else
        {
            // EL5873 mod START TPF Support
            // Identifying if a log is send type or receive type is done depending on the system type (ZIPC/TPF)
            int nLogType = IsSendType(data);
            // EL5873 mod END TPF Support
            if (nLogType == LOG_TYPE_SEND)  // EL5873 mod TPF Support
            {
                // EL5873 mod START TPF Support
                // Get send command name from Log number for the correct system (ZIPC/TPF)
                QString strSendCmdName = "";
                if (m_nEvacSystemType == SYSTEM_TYPE_ZIPC)
                    strSendCmdName = gMicomCmdMap[data.cmdInfo.LogNo].strCmdName;
                else if (m_nEvacSystemType == SYSTEM_TYPE_TPF)
                    strSendCmdName = gMicomCmdMap_tpf[data.cmdInfo.LogNo].strCmdName;
                // EL5873 mod END TPF Support
                if ("" == strSendCmdName)       // EL5873 mod TPF Support
                {
                    AddItermediateLogs(m_nLevel, data, evacList, tempList, LogList);
                }
                else
                {
                    // Find Matching evac command.
                    int nRetIndex = FindMatchingVRTIndex(data.cmdInfo.LogNo, &data, LogList, m_nEvacSystemType);  // EL5873 mod TPF Support
                    if (-1 != nRetIndex)
                    {
                        m_nVRTIndex = nRetIndex;
                        if (m_nEvacLevel != m_nLevel || -1 == m_nLevel)
                        {
                            // Add Outside time micoms above the STAGE log.
                            AddOutsideTimeEvacMicoms (tempList, m_nVRTIndex, LogList);
                        }
                        // Add TASK:33 below the evac log
                        m_nVRTIndex++;
                        LogList->insert( m_nVRTIndex, data);
                        evacList.removeAt(0);
                        m_nLevel++;
                        m_nEvacLevel = m_nLevel;
                        nRet = LG_SUCCESS;
                    }
                    else
                    {
                        m_strCommandNotFound = evacList.at(0).LogEntry;
                        while (!evacList.isEmpty())                  // For sending incorrect logs to error log
                        {                                           // For sending incorrect logs to error log
                            if (evacList.at(0).LogEntry != "")      // For sending incorrect logs to error log
                            {                                       // For sending incorrect logs to error log
                                ErrLogger->WriteToFile(ERRLOG_LOG, "Cannot match Evac Micom Log with mainlist -> " + evacList.at(0).LogEntry);  // For sending incorrect logs to error log
                            }                                       // For sending incorrect logs to error log
                            evacList.removeAt(0);
                        }                                           // For sending incorrect logs to error log
                        nRet = LG_DATA_MISMATCH;
                        break;
                    }
                }
            }
            else if (nLogType == LOG_TYPE_RECV) // EL5873 mod TPF Support
            {
                bool bReplyCommand = true;
                int  nVRTIndex = -1;
                // EL5873 mod START TPF Support
                // Get receive command for correct system (ZIPC/TPF)
                QString strRecvCmdName = "";
                if (m_nEvacSystemType == SYSTEM_TYPE_ZIPC)
                    strRecvCmdName = gMicomRecvCmdMap[data.cmdInfo.LogNo].strCmdName;
                else if (m_nEvacSystemType == SYSTEM_TYPE_TPF)
                    strRecvCmdName = gMicomRecvCmdMap_tpf[data.cmdInfo.LogNo].strCmdName;
                // EL5873 mod END TPF Support
                if ("" == strRecvCmdName)       // EL5873 mod TPF Support
                {
                    AddItermediateLogs(m_nLevel, data, evacList, tempList, LogList);
                }
                else
                {
                    // Find Matching evac command.
                    if (true == FindMatchingVRTReplyIndex(data.cmdInfo.LogNo, &data, bReplyCommand, nVRTIndex, LogList, m_nEvacSystemType))    // EL5873 mod TPF Support
                    {
                        if (m_nEvacLevel != m_nLevel || -1 == m_nLevel)
                        {
                            // Add Outside time micoms above the STAGE log.
                            m_nVRTIndex = nVRTIndex;
                            AddOutsideTimeEvacMicoms (tempList, m_nVRTIndex, LogList);
                            // Add above the matching STGE.
                            data = evacList.at(0);
                            LogList->insert(m_nVRTIndex, data);
                            evacList.removeAt(0);
                        }
                        else
                        {
                            m_nVRTIndex++;
                            // Add the log below the current Micom log.
                            LogList->insert(m_nVRTIndex, data);
                            evacList.removeAt(0);
                            if (0 <= m_nLevel)
                            {
                                m_nLevel--;
                            }
                            if (-1 != m_nLevel)
                            {
                                m_nVRTIndex++;
                            }
                            m_nEvacLevel = m_nLevel;
                        }
                        nRet = LG_SUCCESS;
                    }
                    else
                    {
                        // if the evac micom data is not matching with the logs in the main list
                        m_strCommandNotFound = evacList.at(0).LogEntry;
                        while (!evacList.isEmpty())                          // For sending incorrect logs to error log
                        {                                                   // For sending incorrect logs to error log
                            if (evacList.at(0).LogEntry != "")              // For sending incorrect logs to error log
                            {                                               // For sending incorrect logs to error log
                                ErrLogger->WriteToFile(ERRLOG_LOG, "Cannot match Evac Micom Log with mainlist -> " + evacList.at(0).LogEntry);  // For sending incorrect logs to error log
                            }                                               // For sending incorrect logs to error log
                            evacList.removeAt(0);                           // For sending incorrect logs to error log
                        }                                                   // For sending incorrect logs to error log
                        nRet = LG_DATA_MISMATCH;
                        break;
                    }
                }
            }
            else
            {
                AddItermediateLogs(m_nLevel, data, evacList, tempList, LogList);
            }
        }
    }
    if ( 0 != tempList.size())
    {
        // Adding remaining logs in the templist
        // For sending incorrect logs to error log
        while (!tempList.isEmpty())                 // For sending incorrect logs to error log
        {                                           // For sending incorrect logs to error log
            if (m_bStatus == true)
            {
                ErrLogger->WriteToFile(ERRLOG_LOG, "Evac micom log out of timezone -> " + tempList.at(0).LogEntry); // For sending incorrect logs to error log
            }
            tempList.removeAt(0);                   // For sending incorrect logs to error log
        }                                           // For sending incorrect logs to error log
    }
    return nRet;
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  MergeStageMicomLogs
//  FUNCTION    =  Function used to merge Stage Micom to the main loglist
//  PARAMETER   =  [IN] stageList : Represent stageMicom Data List
//              =  [IN] stageTempList : Represent stage Data List
//              =  [IN] *LogList : Represent Data List
//  RETURN      =  [OUT] nRet : indicating merge status
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//              =  2020/10/19, Parvathy.M, EL5873_Modified
//  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
int ProcesUtilManager::MergeStageMicomLogs(QList<LOG_ANLYZ_DATA> &stageList, QList<LOG_ANLYZ_DATA> &stageTempList, QList<LOG_ANLYZ_DATA> *LogList)
{
    int nRet = LG_SUCCESS;
    LogAnalyzerCommonErrorLogger* ErrLogger = LogAnalyzerCommonErrorLogger::GetInstance();
    LOG_ANLYZ_DATA data;
    QList<LOG_ANLYZ_DATA> tempList;
    m_nVRTIndex = 0;       // Start from the top of LogList
    // Iterate till the stage micom list is empty
    m_nLevel = -1;
    m_nEvacLevel = m_nLevel;
    QDateTime dateTime1;
    QDateTime dateTime2;
    QDateTime dateTimeMicom;
    bool bRet = true;
    int nCount = stageTempList.size();
    dateTime1 = stageTempList.at(0).LogDateTime;
    dateTime2 = stageTempList.at(nCount - 1).LogDateTime;
    bool bIteratonCompleted = false;
    // Iterate till the stage micom list is empty
    while (!stageList.isEmpty())
    {
        bRet = true;
        data = stageList.at(m_nMicomIndex);
        SetReqCode(data);
        dateTimeMicom = data.LogDateTime; // Get the filetime
        bRet = CompareTime(dateTime1, dateTime2, dateTimeMicom);
        if (false == bRet)
        {
            tempList.append(data);
            stageList.removeAt(0);
            continue;
        }
        if (false == bIteratonCompleted && 0 != tempList.size())
        {
            // Add Outside time micoms above the STAGE log.
            AddStartingMicomLogs(tempList, LogList);
        }
        bIteratonCompleted = true;
        // EL5873 mod START for Unify send receive identification
        int nLogType = IsSendType(data);
        if (nLogType == LOG_TYPE_SEND)

        {
            if ("" == gMicomCmdMap[data.cmdInfo.LogNo].strCmdName)
            {
                AddItermediateLogs(m_nLevel, data, stageList, tempList, LogList);
            }
            else
            {
                // Find Matching Stage command.
                int nRetIndex = FindMatchingVRTIndex(data.cmdInfo.LogNo, &data, LogList);
                if (-1 != nRetIndex)
                {
                    m_nVRTIndex = nRetIndex;
                    if (m_nStageLevel != m_nLevel || -1 == m_nLevel)
                    {
                        // Add Outside time micoms above the STAGE log.
                        AddOutsideTimeStageMicoms (tempList, m_nVRTIndex, LogList);
                    }
                    // Add TASK:02 below the STAGE log
                    m_nVRTIndex++;
                    LogList->insert(m_nVRTIndex, data);
                    stageList.removeAt(0);
                    m_nLevel++;
                    m_nStageLevel = m_nLevel;
                    nRet = LG_SUCCESS;
                }
                else
                {
                    m_strCommandNotFound = stageList.at(0).LogEntry;
                    while (!stageList.isEmpty())                     // For sending incorrect logs to error log
                    {                                               // For sending incorrect logs to error log
                        if (stageList.at(0).LogEntry != "")         // For sending incorrect logs to error log
                        {                                           // For sending incorrect logs to error log
                            ErrLogger->WriteToFile(ERRLOG_LOG, "Cannot match Stage Micom Log with mainlist -> " + stageList.at(0).LogEntry);    // For sending incorrect logs to error log
                        }                                           // For sending incorrect logs to error log
                        stageList.removeAt(0);
                    }                                               // For sending incorrect logs to error log
                    nRet = LG_DATA_MISMATCH;
					
                    break;
                }
            }
        }
        else if (nLogType == LOG_TYPE_RECV)
        {
            bool bReplyCommand = true;
            int  nVRTIndex = -1;
            if ("" == gMicomRecvCmdMap[data.cmdInfo.LogNo].strCmdName)
            {
                AddItermediateLogs(m_nLevel, data, stageList, tempList, LogList);
            }
            else
            {
                // Find Matching Stage command.
                if (true == FindMatchingVRTReplyIndex(data.cmdInfo.LogNo, &data, bReplyCommand, nVRTIndex, LogList))
                {
                    if (m_nStageLevel != m_nLevel || -1 == m_nLevel)
                    {
                        // Add Outside time micoms above the STAGE log.
                        m_nVRTIndex = nVRTIndex;
                        // Add above the matching STGE.
                        data = stageList.at(0);
                        LogList->insert(m_nVRTIndex, data);
                        stageList.removeAt(0);
                        AddOutsideTimeStageMicoms (tempList, m_nVRTIndex, LogList );
                    }
                    else
                    {
                        m_nVRTIndex++;
					// EL5873 mod END for Unify send receive identification
                        // Add the log below the current Micom log.
                        LogList->insert(m_nVRTIndex, data);
                        stageList.removeAt(0);
                        if (0 <= m_nLevel)
                        {
                            m_nLevel--;
                        }
                        if (-1 != m_nLevel)
                        {
                            m_nVRTIndex++;
                        }
                        m_nStageLevel = m_nLevel;
                    }
                    nRet = LG_SUCCESS;
                }
                else
                {
                    // if the stage micom data is not matching with the logs in the mainlist
                    m_strCommandNotFound = stageList.at(0).LogEntry;
                    while (!stageList.isEmpty())                         // For sending incorrect logs to error log
                    {                                                   // For sending incorrect logs to error log
                        if (stageList.at(0).LogEntry != "")             // For sending incorrect logs to error log
                        {                                               // For sending incorrect logs to error log
                            ErrLogger->WriteToFile(ERRLOG_LOG, "Cannot match Stage Micom Log with mainlist -> " + stageList.at(0).LogEntry);    // For sending incorrect logs to error log
                        }                                               // For sending incorrect logs to error log
                        stageList.removeAt(0);
                    }                                                   // For sending incorrect logs to error log
                    nRet = LG_DATA_MISMATCH;
                    break;
                }
            }
        }
        else
        {
            AddItermediateLogs(m_nLevel, data, stageList, tempList, LogList);
        }
    }
    if ( 0 != tempList.size())
    {
        // Adding remaining logs in the templist
        // For sending incorrect logs to error log
        while (!tempList.isEmpty())                  // For sending incorrect logs to error log
        {                                           // For sending incorrect logs to error log
            if (m_bStatus == true)
            {
                ErrLogger->WriteToFile(ERRLOG_LOG, "Stage micom log out of timezone -> " + tempList.at(0).LogEntry);   // For sending incorrect logs to error log
            }
            tempList.removeAt(0);                   // For sending incorrect logs to error log
        }                                           // For sending incorrect logs to error log
    }
    return nRet;
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  Compare
//  FUNCTION    =  Function to Compare two logdata
//  PARAMETER   =  [IN] arg1 : Represent the LOG_ANLYZ_DATA1
//              =  [IN] arg2 : Represent the LOG_ANLYZ_DATA2
//  RETURN      =  [OUT] ret : True if success, else return False
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//              =  2020/07/30, Akshai K.B, EL5873_Modified for LogAnalyzer bug fix on merged log issue
//  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved.
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
bool ProcesUtilManager::Compare(const LOG_ANLYZ_DATA& arg1, const LOG_ANLYZ_DATA& arg2)
{
    bool ret; // EL5873 mod for LogAnalyzer
    LOG_ANLYZ_DATA data1 = arg1;
    LOG_ANLYZ_DATA data2 = arg2;
    // EL5873 mod START added for LogAnalyzer
    if (data1.LogDateTime == data2.LogDateTime)
    {
        if (data1.SeqNum < data2.SeqNum)
        {
            ret = true;
        }
        else if (data1.SeqNum > data2.SeqNum)
        {
            ret = false;
        }
    }
    else
    {
        ret = data1.LogDateTime < data2.LogDateTime;
    }
	if (0 != nCount)
    {
        //To sort the outside time domain micom logs based on time
        LOG_ANLYZ_DATA data;
        LOG_ANLYZ_DATA prevData;
        LOG_ANLYZ_DATA firstMicomData;
        // Get the first data in outside time domain Micom logs
        firstMicomData = tempList.at(0);
        // Find the File time of the first outside time domain Micom log
        QDateTime ft1, ft2;
        ft1 = firstMicomData.LogDateTime;
        int returnValue ;
        int index = 0;
        // Search from the immediate top of last STGQ
        for (index = nVRTIndex-1; index >= 0; index--)
        {
            data = LogList->at( index );
            // Do not add to the list if it is a Micom Row
            if (data.SectionId != SEC_ID_ETH_STAGE_MICOM ||
                    data.SectionId != SEC_ID_ETH_EVAC_MICOM)
            {
                if ( STAGE_ETYPE == data.cmdInfo.CmdName ||
                     STAGE_TTYPE == data.cmdInfo.CmdName)
                {
                    prevData = LogList->at(index-1);
                    if (prevData.SectionId == SEC_ID_ETH_STAGE_MICOM)
                    {
                        index++;
                        break;
                    }
                }
                else if ( EVAC_ETYPE == data.cmdInfo.CmdName ||
                          EVAC_TTYPE == data.cmdInfo.CmdName)
                {
                    prevData = LogList->at(index-1);
                    if (prevData.SectionId == SEC_ID_ETH_EVAC_MICOM)
                    {
                        index++;
                        break;
                    }
                }
                ft2 = data.LogDateTime;
                returnValue = CompareFileTime(ft1, ft2);
                if (returnValue <= 0 )
                {
                    tempList.append(data);
                }
                else
                {
                    index++;
                    break;
                }
                //break;
            }
            // MICOM log reached
            else
            {
                index++;
                break;
            }
        }
        // Remove the intermediate entries (between STGE and STGQ)
        for (int i = index ; i < nVRTIndex; i++)
        {
            LogList->removeAt(index);
        }
        // Sort the temporary list
        TempListSort(tempList);
        // Insert the temporary list below STGE
        for (int i=0, j = index ; i < tempList.size(); i++,j++)
        {
            data = tempList.at(i);
            LogList->insert(j, data);
        }
        m_nVRTIndex += nCount;
        tempList.clear();
    }
    // EL5873 mod END added for LogAnalyzer
    return ret;
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  MergeEvacITLVLogs
//  FUNCTION    =  Add Micom logs at the beginning
//  PARAMETER   =  [IN] nLevel : index
//              =  [IN] data : Represent Data
//              =  [IN] evacMicomList : Represent Evac Micom Data List
//              =  [IN] tempList : Represent Data List
//              =  [IN] *LogList : Log Data list
//  RETURN      =  [OUT] nRet : send the Evac ITLV Log merge status
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//              =  2020/06/26, Sheikh Mohammed Subhan, EL5873_Modified TPF Support
//  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
int ProcesUtilManager::MergeEvacITLVLogs(int &nLevel, LOG_ANLYZ_DATA& data, QList<LOG_ANLYZ_DATA>& evacMicomList,
                                       QList<LOG_ANLYZ_DATA>& tempList, QList<LOG_ANLYZ_DATA>* LogList )
{
    m_nEvacLevel = nLevel;
    int nRet = LG_ERROR;
    // EL5873 mod START TPF Support
    int nCmdType = LOG_TYPE_NONE;
    // Identify and branch to corresponding logic
    // Identify correct log type (send/receive) depending on the system (ZIPC/TPF)
    if (m_nEvacSystemType == SYSTEM_TYPE_ZIPC)
    {
        // ITLV is client generated command, so receive has send code and send has receive code
        if (data.cmdInfo.TaskNo == "34")
        {
            nCmdType = LOG_TYPE_SEND;
        }
        else if (data.cmdInfo.TaskNo == "33")
        {
            nCmdType = LOG_TYPE_RECV;
        }
    }
    else if (m_nEvacSystemType == SYSTEM_TYPE_TPF)
    {
        nCmdType = IsSendType(data);
    }
    //For EVCQ/ITLV command task no:34 is the send.
    if (nCmdType == LOG_TYPE_SEND)  // EL5873 mod TPF Support
    {
        // Fetch correct receive command name depending on the system type (ZIPC/TPF)
        QString strRecvCmdName = "";
        if (m_nEvacSystemType == SYSTEM_TYPE_ZIPC)
            strRecvCmdName = gMicomRecvCmdMap[data.cmdInfo.LogNo].strCmdName;
        else if (m_nEvacSystemType == SYSTEM_TYPE_TPF)
            strRecvCmdName = gMicomCmdMap_tpf[data.cmdInfo.LogNo].strCmdName;   // TPF ITLV will use the send table itself
        if ("" == strRecvCmdName)
        {
            AddItermediateLogs(nLevel, data, evacMicomList, tempList, LogList);
            m_nEvacLevel = nLevel;
        }
        else
        {
            // Find Matching evac command.
            int nRetIndex = -1;
            if (m_nEvacSystemType == SYSTEM_TYPE_ZIPC)
            {
                // "0133" is the send log No for ITLV command in ZIPC system.
                nRetIndex = FindMatchingVRTIndex("0133", &data, LogList, SYSTEM_TYPE_ZIPC);
            }
            else if (m_nEvacSystemType == SYSTEM_TYPE_TPF)
            {
                // "0" is the send logNo for ITLV command in TPF system.
                nRetIndex = FindMatchingVRTIndex("0", &data, LogList, SYSTEM_TYPE_TPF);
            }
            // EL5873 mod END TPF Support
            if (-1 != nRetIndex)
            {
                m_nVRTIndex = nRetIndex;
                if (m_nEvacLevel != nLevel || -1 == nLevel)
                {
                    // Add Outside time micoms above the STAGE log.
                    AddOutsideTimeEvacMicoms (tempList, m_nVRTIndex, LogList);
                }
                m_nVRTIndex++;
                LogList->insert(m_nVRTIndex, data);
                evacMicomList.removeAt(0);
                nLevel++;
                m_nEvacLevel = nLevel;
                nRet = LG_SUCCESS;
            }
            else
            {
                // if the evac micom data is not matching with the main list
                m_strCommandNotFound = evacMicomList.at(0).LogEntry;
                evacMicomList.removeAt(0);
                nRet = LG_DATA_MISMATCH;
            }
        }
    }
    //For EVCE/ITLV command task no:33 is the receive.
    else if (nCmdType == LOG_TYPE_RECV)     // EL5873 mod TPF Support
    {
        bool bReplyCommand = true;
        int  nVRTIndex = -1;
        // EL5873 mod START TPF Support
        // Fetch correct Send command name depending on the system type (ZIPC/TPF)
        QString strSendCmdName = "";
        if (m_nEvacSystemType == SYSTEM_TYPE_ZIPC)
            strSendCmdName = gMicomCmdMap[data.cmdInfo.LogNo].strCmdName;
        else if (m_nEvacSystemType == SYSTEM_TYPE_TPF)
            strSendCmdName = gMicomRecvCmdMap_tpf[data.cmdInfo.LogNo].strCmdName;   // TPF ITLV will use the receive table itself
        if ("" == strSendCmdName)
        {
            AddItermediateLogs(nLevel, data, evacMicomList, tempList, LogList);
        }
        else
        {
            bool bVRTReplyFound = false;
            if (m_nEvacSystemType == SYSTEM_TYPE_ZIPC)
                bVRTReplyFound = FindMatchingVRTReplyIndex("0161", &data, bReplyCommand, nVRTIndex, LogList, m_nEvacSystemType);
            else if (m_nEvacSystemType == SYSTEM_TYPE_TPF)
            {
                // The reply log number of the ITLV command has to be set
                bVRTReplyFound = FindMatchingVRTReplyIndex("11050", &data, bReplyCommand, nVRTIndex, LogList, m_nEvacSystemType);
            }
            // "0161" is the receive log No for ITLV command.
            if (true == bVRTReplyFound)     // EL5873 mod TPF Support
            {
                if (m_nEvacLevel != nLevel || -1 == nLevel)
                {
                    m_nVRTIndex = nVRTIndex;
                    AddOutsideTimeEvacMicoms (tempList, m_nVRTIndex, LogList);
                    data = evacMicomList.at(0);
                    LogList->insert(m_nVRTIndex, data);
                    evacMicomList.removeAt(0);
                }
                else
                {
                    m_nVRTIndex++;
                    // Add the log below the current Micom log.
                    LogList->insert(m_nVRTIndex, data);
                    evacMicomList.removeAt(0);
                    if (0 <= nLevel)
                    {
                        nLevel--;
                    }
                    if (-1 != nLevel)
                    {
                        m_nVRTIndex++;
                    }
                    m_nEvacLevel = nLevel;
                }
                nRet = LG_SUCCESS;
            }
            else
            {
                m_strCommandNotFound = evacMicomList.at(0).LogEntry;
                evacMicomList.removeAt(0);
                nRet = LG_DATA_MISMATCH;
                //break;
            }
		// EL5873 mod END TPF Support
        }
    }
    else
    {
        AddItermediateLogs(nLevel, data, evacMicomList, tempList, LogList);
    }
    return nRet;
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  FindMatchingVRTIndex
//  FUNCTION    =  Add Micom logs at the beginning to ITLV send logs
//  PARAMETER   =  [IN] strLogNo : log Number
//              =  [IN] *pstData : pointer to structure
//              =  [IN] *LogList : Log Data list
//              =  [IN] nSystemType : System Type
//  RETURN      =  [OUT] nRetIndex : matching index
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//              =  2020/06/24, Sheikh Mohammed Subhan, EL5873_Modified TPF Support
//  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
int ProcesUtilManager::FindMatchingVRTIndex(QString strLogNo, LOG_ANLYZ_DATA* pstData, QList<LOG_ANLYZ_DATA> *LogList, int nSystemType)    // EL5873 mod TPF Support
{
    int nRetIndex = -1;
    LOG_ANLYZ_DATA VRTData;
    int returnValue = -1;
    bool bRet = false;
    // EL5873 mod START TPF Support
    // Fetch command name from log number depending on the correct system (ZIPC/TPF)
    QString strValue = "";
    if (nSystemType == SYSTEM_TYPE_TPF)
        strValue = gMicomCmdMap_tpf[strLogNo].strCmdName;
    else if (nSystemType == SYSTEM_TYPE_ZIPC)
        strValue = gMicomCmdMap[strLogNo].strCmdName;

    QString strVRTData = "";
    QDateTime fp1 ;
    QDateTime ftMicom;
    LOG_ANLYZ_DATA micomData = *pstData;
    ftMicom = micomData.LogDateTime; // Get the filetime
    for (int nIndex = m_nVRTIndex; nIndex < LogList->size(); nIndex++)
    {
        VRTData = LogList->at(nIndex);
        strVRTData = VRTData.cmdInfo.CmdName +QString("/")+ VRTData.cmdInfo.CmdNameParam;
        if (strVRTData == strValue) // Matching SEM command is found
        {
            // Check the time match
            fp1 = VRTData.LogDateTime;
            returnValue = CompareFileTime(fp1, ftMicom);
            // Get the stage micom send command
            if ((returnValue == -1)|| (returnValue == 0))
            {
                bRet = TimeRangeCheck(fp1, ftMicom);
            }
            else
            {
                bRet = TimeRangeCheck(ftMicom, fp1);
            }
            if (true == bRet)
            {
                // Update the current index in LogList.
                nRetIndex = nIndex;
                break;
            }
        }
    }
	// EL5873 mod END TPF Support
    return nRetIndex;
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        =  FindMatchingVRTReplyIndex
//  FUNCTION    =  Add Micom logs at the beginning to ITLV receive logs
//  PARAMETER   =  [IN] strLogNum : log Number
//              =  [IN] *pData : pointer to structure
//              =  [IN] bReplyCommand : status
//              =  [OUT] nVRTIndex : Send Log Data Index
//              =  [IN] *LogList : Log Data list
//              =  [IN] nSystemType : System Type
//  RETURN      =  [OUT] bRet : matching index
//  NOTES       =  None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//              =  2020/06/26, Sheikh Mohammed Subhan, EL5873_Modified TPF Support
//  Copyright (C) Hitachi High-Tech Corporation, 2020. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
bool ProcesUtilManager::FindMatchingVRTReplyIndex(QString strLogNum, LOG_ANLYZ_DATA* pData,
                                                bool &bReplyCommand, int &nVRTIndex, QList<LOG_ANLYZ_DATA> *LogList, int nSystemType)
{
    bool bRet = false;
    bReplyCommand = false;
    // Get the command name from the Send command
    QStringList cmdList;
    LOG_ANLYZ_DATA VRTData;
    QDateTime fp1;
    QDateTime ftMicom ;
    LOG_ANLYZ_DATA micomData = *pData;
    ftMicom = micomData.LogDateTime; // Get the filetime
    // EL5873 mod START TPF Support
    // Get proper receive command from log number for the correct system (ZIPC/TPF)
    if (nSystemType == SYSTEM_TYPE_ZIPC)
        cmdList = gMicomRecvCmdMap[strLogNum].strCmdName.split('/');
    else if (nSystemType == SYSTEM_TYPE_TPF)
        cmdList = gMicomRecvCmdMap_tpf[strLogNum].strCmdName.split('/');
    // EL5873 mod END TPF Support
    int nRet = cmdList.size();
    // Tokenize the command name.
    if (2 == nRet)
    {
        // EL5873 mod START TPF Support
        // Fetch correct receive command depending on the system type (ZIPC/TPF)
        QString strVRTRecvCmd = "";
        if (nSystemType == SYSTEM_TYPE_ZIPC)
            strVRTRecvCmd = gVRTSendRecvMap[cmdList[0]];
        else if (nSystemType == SYSTEM_TYPE_TPF)
            strVRTRecvCmd = gVRTSendRecvMap_tpf[cmdList[0]];        
        if ("" != strVRTRecvCmd)
        {
            bRet = false;
            bReplyCommand = true;
            for (int nIndex = m_nVRTIndex; nIndex < LogList->size(); nIndex++)
            {
                VRTData = LogList->at(nIndex);
                if (strVRTRecvCmd ==  VRTData.cmdInfo.CmdName &&
                        cmdList[1]    ==  VRTData.cmdInfo.CmdNameParam) // Matching SEM command is found
                {
                    // Check the time match
                    fp1 = VRTData.LogDateTime;

                    int returnValue = CompareFileTime(fp1, ftMicom);

                    // Get the stage micom send command
                    if ((returnValue == -1)|| (returnValue == 0))
                    {
                        bRet = TimeRangeCheck(fp1, ftMicom);
                        //bRet = true;
                    }
                    else
                    {
                        bRet = TimeRangeCheck(ftMicom, fp1);
                        //bRet = true;
                    }
                    if (true == bRet)
                    {
                        // Update the current index in LogList.
                        bRet = true;
                        nVRTIndex = nIndex;
                        break;
                    }
                }
            }
        }
        else
        {
			// EL5873 mod END TPF Support
            bRet = false;
            for (int nIndex = m_nVRTIndex; nIndex < LogList->count(); nIndex++)
            {
                VRTData = LogList->at(nIndex);

                if (cmdList[0] ==  VRTData.cmdInfo.CmdName &&
                        cmdList[1] ==  VRTData.cmdInfo.CmdNameParam) // Matching SEM command is found
                {
                    // Check the time match
                    fp1 = VRTData.LogDateTime;
                    int returnValue = CompareFileTime(fp1, ftMicom);
                    // Get the stage micom send command
                    if ((returnValue == -1)|| (returnValue == 0))
                    {
                        bRet = TimeRangeCheck(fp1, ftMicom);
                    }
                    else
                    {
                        bRet = TimeRangeCheck(ftMicom, fp1);
                    }
                    if (true == bRet)
                    {
                        // Update the current index in LogList.
                        nVRTIndex = nIndex;
                        break;
                    }
                }
            }
        }
    }
    return bRet;
}
// DMG213 new END added for LogAnalyzer


//---------------------------------------------------------------------------------------------------------------------------------------
//  NAME        = IsSendType
//  FUNCTION    = Function is used to identify that the selected log is a SendType
//  PARAMETER   = [IN] stCmdInfo : selected log data
//  RETURN      = [OUT] nSendCommandStatus : The log type (send/receive)
//  NOTES       = None
//  HISTORY     =  2021/02/18, Parvathy.M, DMG213_Initial creation
//              =  2020/06/26, Sheikh Mohammed Subhan, EL5873_Modified TPF Support
//  Copyright (C) Hitachi High-Tech Corporation, 2020,2021. All rights reserved. 
//---------------------------------------------------------------------------------------------------------------------------------------
// DMG213 new START added for LogAnalyzer
int ProcesUtilManager::IsSendType(LOG_ANLYZ_DATA stCmdInfo)
{
    int nSendCommandStatus = LOG_TYPE_NONE;         // EL5873 mod TPF Support
    QString deviceId = stCmdInfo.SectionId;
    // Sem
    if ( (ID_WFCU == deviceId)||(ID_OPTU == deviceId)||
         (ID_STGU == deviceId)||(ID_CSCU == deviceId)||
         (ID_CLMU == deviceId)||(ID_EVCU == deviceId)||
         (ID_CSEV == deviceId)||(ID_IMGU == deviceId)||
         (ID_DSEV == deviceId)||(ID_ISEV == deviceId)||
         (ID_HVCU == deviceId)||(ID_POLU == deviceId)||
         (ID_IPSU == deviceId)||(ID_MSEV == deviceId)||
         (ID_SEQUENCER == deviceId))  // DMG213 mod for LogAnalyzer
    {
        //Check if the command is Send type
        if (REQCODE_QTYPE == stCmdInfo.cmdInfo.ReqCode)
        {
            nSendCommandStatus = LOG_TYPE_SEND;     // EL5873 mod TPF Support
        }
        // EL5873 mod START Unify send receive identification
        else if (REQREPLY_ETYPE == stCmdInfo.cmdInfo.ReqCode)
        {
            nSendCommandStatus = LOG_TYPE_RECV;
        }
        // EL5873 mod END Unify send receive identification
    }
    // stage
    else if (SEC_ID_ETH == deviceId)
    {
        //Check if the command is Send type
        if (STAGE_QTYPE == stCmdInfo.cmdInfo.CmdName)
        {
            nSendCommandStatus = LOG_TYPE_SEND;     // EL5873 mod TPF Support
        }
        // EL5873 mod START Unify send receive identification
        else if (STAGE_ETYPE == stCmdInfo.cmdInfo.CmdName)
        {
            nSendCommandStatus = LOG_TYPE_RECV;
        }
        // EL5873 mod END Unify send receive identification
    }
    // EVAC
    else if (SEC_ID_ETH_EVAC     == deviceId)
    {
        //Check if the command is Send type
        if (EVAC_QTYPE == stCmdInfo.cmdInfo.CmdName)
        {
            nSendCommandStatus = LOG_TYPE_SEND;     // EL5873 mod TPF Support
        }
        // EL5873 mod START Unify send receive identification
        else if (EVAC_ETYPE == stCmdInfo.cmdInfo.CmdName)
        {
            nSendCommandStatus = LOG_TYPE_RECV;
        }
        // EL5873 mod END Unify send receive identification
    }
    //HV AND Minien
    else if (SEC_ID_RS232C == deviceId || SEC_ID_WFCU == deviceId)
    {
        //Check if the command is Send type
        if (REQCODE_QTYPE == stCmdInfo.cmdInfo.ReqCode)
        {
            nSendCommandStatus = LOG_TYPE_SEND;     // EL5873 mod TPF Support
        }
        // EL5873 mod START Unify send receive identification
        else if (REQREPLY_ETYPE == stCmdInfo.cmdInfo.ReqCode)
        {
            nSendCommandStatus = LOG_TYPE_RECV;
        }
        // EL5873 mod END Unify send receive identification
    }
    // Aligner
    else if (SEC_ID_VRT == deviceId)
    {
        //Check if the command is Send type
        int nIndex = (stCmdInfo.LogEntry).indexOf(FORWARD_ARROW);
        int nAckIndex = (stCmdInfo.LogEntry).indexOf(LOG_ACK_TEXT);
        if (nIndex > 0 && nAckIndex < 0)
        {
            nSendCommandStatus = LOG_TYPE_SEND;     // EL5873 mod TPF Support
        }
    }
    // Stage Micom
    else if (SEC_ID_ETH_STAGE_MICOM == deviceId)
    {
        //Check if the command is Send type
        if ("02" == stCmdInfo.cmdInfo.TaskNo)
        {
            nSendCommandStatus = LOG_TYPE_SEND;     // EL5873 mod TPF Support
        }
        // EL5873 mod START Unify send receive identification
        else if ("03" == stCmdInfo.cmdInfo.TaskNo)
        {
            nSendCommandStatus = LOG_TYPE_RECV;
        }
        // EL5873 mod END Unify send receive identification
    }
    // Evac Micom
    else if (SEC_ID_ETH_EVAC_MICOM == deviceId)
    {
        //Check if the command is Send type
        // EL5873 mod START TPF Support
        if (m_nEvacSystemType == SYSTEM_TYPE_TPF)
        {
            // For TPF Type
            // 1. Check the corresponding command in send recv table
            // 2. Identify if the log is send type
            nSendCommandStatus = LOG_TYPE_UNDEFINED;
            for (unsigned long long i=0; i<MapArray_TPF.size(); i++)
            {
                if (MapArray_TPF[i].strSend == stCmdInfo.cmdInfo.LogNo)
                {
                    nSendCommandStatus = LOG_TYPE_SEND;
                    break;
                }
                else if (MapArray_TPF[i].strReceive == stCmdInfo.cmdInfo.LogNo)
                {
                    nSendCommandStatus = LOG_TYPE_RECV;
                    break;
                }
            }
        }
        else if (m_nEvacSystemType == SYSTEM_TYPE_ZIPC)
        {
            if (EVC_MIC_CMD == stCmdInfo.cmdInfo.TaskNo)
            {                 
                if(stCmdInfo.cmdInfo.LogNo == "0133")
                {
                    nSendCommandStatus = LOG_TYPE_RECV;
                }
                 else
                {
                    nSendCommandStatus = LOG_TYPE_SEND;
                }
            }
            else if (EVC_MIC_ZIPC_RECV_TASKNO == stCmdInfo.cmdInfo.TaskNo)
            {
                if(stCmdInfo.cmdInfo.LogNo == "0161")
                {
                    nSendCommandStatus = LOG_TYPE_SEND;
                }
                else
                {
                    nSendCommandStatus = LOG_TYPE_RECV;
                }
            }
        }
        // EL5873 mod END Unify send receive identification
    }
    return nSendCommandStatus;
}
// DMG213 new END added for LogAnalyzer